/*
Конспект "Базовый HTML"

HTML
hypertext markup language
язык гипертекстовой разметки

Синтаксис HTML
Тег - это всё, что помещается в угловые скобки

Элемент - часть тега, которая определяет функциональную часть блока в разметке
A. Парные: <p>Hello</p>
B. Непарные (одиночные): <img>

Базовые элементы:
html - контейнер для HTML-кода
head - служебный элемент (информация для браузера, поисковиков)
body - контейнер для элементов, которые видит пользователь


Заголовок (h1-h6)
Существует 6 уровней заголовков, где h1 имеет наибольшую важность, а h6 - наименьшую
<h1>Hello world!</h1>


Параграф (p)
Используется для больших блоков текста
<p>Some text</p>


Список (ul, ol, li)
Наиболее популярны следующие виды списков:
A. Маркированный (неупорядоченный) - ul
B. Нумерованный (упорядоченный) - ol

Для добавления пунктов списка используется элемент li
<ul>
  <li>Football</li>
  <li>Cars</li>
  <li>Food</li>
</ul>


Изображение (img)
Для элемента добавляются следующие атрибуты:
A. src - путь к изображению
B. alt - позволяет получить текстовую информацию о рисунке при отсутствии загрузки изображения
C. width/height - возможность в HTML установить ширину/высоту изображения
<img src="img/html.png" width="300px" height="150px" alt="Logo HTML">


Ссылка (a)
ссылка на другую HTML-страницу
В тег добавляется атрибут href, чтобы указать путь на HTML-страницу
<a href="https://en.wikipedia.org/wiki/Main_Page">Wikipedia</a>



Элементы формы
form
контейнер для элементов 
<form></form>


input (text/passowrd)
<input type="text"> - поле для однострочного ввода обычного текста 
<input type="password"> - поле для однострочного ввода скрытого текста

Для создания подсказки внутри поля формы, используется атрибут placeholder
<input type="text" placeholder="Put your name">


textarea
поле для многострочного ввода текста 
<textarea placeholder="Put your comment"></textarea>


button
кнопка для отправки формы и для вызова действия
<button>Send me</button>


input (radio)
позволяют сделать выбор одного значения из многих
<input type="radio" name="drinks">
Важно: значение name у всех радиокнопок должно быть одинаковым


input (checkbox)
позволяют сделать выбор нескольких значений (или пропустить выбор)
<input type="checkbox" name="drinks">


label
связывает текст с определённым элементом формы
Связь создаётся с помощью одинакового значения в атрибутах id и for
<input type="radio" id="tea" name="drinks">
<label for="tea">Tea</label>


Код из лекций:
<h1>Hello world!</h1>
<p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Temporibus necessitatibus blanditiis qui, reiciendis veniam cupiditate quo doloribus dolorum deserunt delectus fuga. Commodi quis ducimus deleniti harum enim? A, eius in.</p>

<ul>
    <li>Football</li>
    <li>Food</li>
    <li>Cars</li>
</ul>
<ol>
    <li>Football</li>
    <li>Food</li>
    <li>Cars</li>
</ol>

<img src="img/html.png" width="150px" alt="Logo HTML">
<img src="https://upload.wikimedia.org/wikipedia/ru/f/f2/Ross_Geller.jpg">
<a href="https://en.wikipedia.org/wiki/Ross_Geller">Wikipedia</a>

<span>Hello</span>
<b>Hello</b>
<i>Hello</i>

<div>
    <h1>Hello</h1>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Alias pariatur vel libero similique tempore possimus. Soluta tempora obcaecati nobis. Eos blanditiis labore reiciendis quaerat quam corrupti aut odit repudiandae rerum?</p>
</div>

<form>
    <input type="text" placeholder="Put your name">
    <input type="password" placeholder="Put your password">
    <textarea placeholder="Put your comment"></textarea>

    <input type="radio" id="tea" name="drinks" checked>
    <label for="tea">Tea</label>
    <input type="radio" id="coffee" name="drinks">
    <label for="coffee">Coffee</label>

    <input type="checkbox" id="sugar" name="drinks">
    <label for="sugar">Sugar</label>
    <input type="checkbox" id="milk" name="drinks">
    <label for="milk">Milk</label>

    <button>Send me</button>
</form>



Ссылка на статью для практики:
https://en.wikipedia.org/wiki/Geography_of_Australia
*/