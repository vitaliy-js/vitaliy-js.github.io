
document.querySelector('form').addEventListener('submit', (e) => {
    const num = document.querySelectorAll('input');
    const total = document.querySelector('b');
    e.preventDefault();

});



// 4/3 => 1.333
// 6/4 => 1.5
// 9/5 => 1.8
/*
Методы по округлению чисел
A. Math.floor - в меньшую сторону
console.log(Math.floor(4.75));   => 4

B. Math.ceil - в большую сторону
console.log(Math.ceil(4.25));    => 5

C. Math.round - к ближайшему целому
console.log(Math.round(4.5));    => 5
console.log(Math.round(4.2));    => 4

D. Math.trunc - удаление дробной части без округления
console.log(Math.trunc(4.75));   => 4


Д.З.
Выведите решение в консоль:
1. Сколько полных лет Васе (25.3 лет)
----------------
2. Посчитайте результат теста (нужно получить целое число в пользу студента)
  А. 27 вопросов - 100%
  B. 25 правильных ответов - ?%
----------------
3. Какой процент людей живёт в Европе от всего населения Земли? (обычное математическое округление)
  А. 8050000000 - 100%
  B. 748178083 - ?%
*/










// Код из лекции
// const getNumber = (num1, num2) => {
// 	console.log(num1 / num2);
// 	return Math.floor(num1 / num2);
// }

// document.querySelector('form').addEventListener('submit', (e) => {
//     const num = document.querySelectorAll('input');
//     const total = document.querySelector('b');
//     e.preventDefault();

// 	if (num[0].value.length > 0 && num[1].value.length > 0) {
// 		total.textContent = getNumber(num[0].value, num[1].value);
// 	}
// });

// Math.floor(num1 / num2);
// Math.ceil(num1 / num2);
// Math.round(num1 / num2);
// Math.trunc(num1 / num2);










/*
Решение Д.З. (способы решения могут отличаться)
1. 
console.log(Math.floor(25.3));             => 25
----------------
2. 
console.log(Math.ceil(25 * 100 / 27));     => 93
----------------
3.
console.log(Math.round(748178083 * 100 / 8050000000));
=> 9
*/