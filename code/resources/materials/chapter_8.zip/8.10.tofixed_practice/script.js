const goods = [
    ['tv.svg', 'Телевизор', '59.99$', '30%'],
    ['fridge.svg', 'Холодильник', '48.49$', '25%'],
    ['phone.svg', 'Телефон', '19.99$', '10%']
];
const product = document.querySelector('.product-wrap');



















// Код из практики
// const getPrice = (price, discount) => {
//     price = parseFloat(price);
//     const newPrice = price - (price * parseFloat(discount) / 100);
//     return newPrice.toFixed(2);
// }

// for (let i = 0; i < goods.length; i++) {
//     product.insertAdjacentHTML('beforeend', `
//         <div class="product">
//             <img src="img/${goods[i][0]}">
//             <h3>${goods[i][1]}</h3>
//             <div class="price">
//                 <span>${goods[i][2]}</span>
//                 <strong>${getPrice(goods[i][2], goods[i][3])}$</strong>
//             </div>
//             <b>${goods[i][3]}</b>
//         </div>`);
// }