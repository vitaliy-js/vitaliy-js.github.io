document.querySelector('button').addEventListener('click', () => {
	const result = document.querySelectorAll('td:nth-child(2)');
	const report = [];
	for (let val of result) {
		report.push(val.textContent);
	}

	console.log(report);
});

console.log('32' + 2);



/*
Метод parseInt
преобразование значения в целое число. Если встречается символ, не являющийся цифровым, останавливается чтение значения и возвращается число до данного символа
console.log(parseInt('2USD'));      => 2
console.log(parseInt('95.5%'));     => 95


Если первый символ нельзя привести к числовому виду, вернётся NaN
console.log(parseInt('USD2'));      => NaN


Может использоваться необязательный второй параметр - система счисления (по умолчанию - десятичная)
console.log(parseInt('2USD', 10));      => 2
console.log(parseInt('1a', 2));         => 1
console.log(parseInt('ff', 16));        => 255


Метод parseFloat
тоже самое, что и parseInt, но здесь возвращается число с плавающей точкой
console.log(parseFloat('95.5%'));       => 95.5


Д.З.
Выведите решение в консоль:
1. Выведите максимально точное значение скорости болида Формулы-1 в виде числа без указания единиц измерения -  351.22 км/ч
-------------
2. Просуммируйте стоимость товаров в чеке: 5USD, 19USD
-------------
3. Сколько суммарно калорий человек потребляет в день, если:
завтрак -  558.10 ккал
обед - 652.05 ккал
ужин - 590.25 ккал
*/










// Код из лекции
// console.log('32px' - 2);
// console.log(parseInt('32px') - 2);
// console.log(parseInt('-32px'));
// console.log(parseInt('hello32px'));

// console.log(parseInt('32px', 10));
// console.log(parseInt('1dd32', 2));
// console.log(parseInt('ff', 16));

// document.querySelector('button').addEventListener('click', () => {
// 	const result = document.querySelectorAll('td:nth-child(2)');
// 	const report = [];
// 	for (let val of result) {
// 		// report.push(val.textContent);
// 		report.push(parseInt(val.textContent));
// 		report.push(parseFloat(val.textContent));
// 	}

// 	console.log(report);
// });










/*
Решение Д.З. (способы решения могут отличаться)
1. 
console.log(parseFloat('351.22 км/ч'));
=> 351.22
-------------
2.
console.log(parseInt('5USD') + parseInt('19USD'));
=> 24
-------------
3.
console.log(parseFloat('558.10 ккал') + parseFloat('652.05 ккал') + parseFloat('590.25 ккал'));
=> 1800.4
*/