const result = document.querySelector('td:last-child');
const getResult = val => val * 100 / 52;
console.log(getResult(49));

result.textContent = getResult(49);



// 49 - 94.2307
// 45 - 86.5384
/*
Метод toFixed
округляет число с добавлением указанного количества цифр после плавающей точки
const num = 25.01234;
console.log(num.toFixed(3));   => 25.012

const num = 25.888;
console.log(num.toFixed(2));   => 25.89

const num = 25;
console.log(num.toFixed(2));   => 25.00


Если значение не является числом, будет выдаваться ошибка
console.log('1'.toFixed(2));   =>   ошибка


Значение возвращается в виде строки
const fixedVal = 99.129.toFixed(2);
console.log(fixedVal + 7);
=> 99.137
*/










// Код из лекции
// const getResult = val => {
//     const result = val * 100 / 52;
//     return result.toFixed(2);
// }

// result.toFixed(2);
// result.toFixed(1);
// result.toFixed();

// result.toFixed(2) + 1;

// 'hello'.toFixed(2);
// null.toFixed(2);