const img = ['apple.svg', 'pear.svg', 'banana.svg'];
























// Код из практики
// const people = [];

// const getRandom = arr => arr[Math.floor(Math.random() * arr.length)];

// document.querySelector('.add-btn').addEventListener('click', () => {
//     document.querySelector('.modal-btn')
//     .insertAdjacentHTML('beforebegin', '<input>');
// });

// document.querySelector('.modal-btn').addEventListener('click', () => {
//     const input = document.querySelectorAll('input');
//     const peopleWrap = document.querySelector('ul');

//     for (let el of input) {
//         if (el.value.length > 0) {
//             people.push(el.value);
//             peopleWrap.innerHTML += `<li>${el.value}</li>`;
//         }
//     }

//     if (people.length > 0) {
//         document.querySelector('.overlay').remove();
//     }
// });

// document.querySelector('.result').addEventListener('click', () => {
//     document.querySelector('img').src = `img/${getRandom(img)}`;
//     document.querySelector('b').textContent = getRandom(people);
// });