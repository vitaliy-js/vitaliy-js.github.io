console.log();



//-10, -1, 9, 3
/*
A. Math.max
возвращает наибольшее число из перечня в параметрах
console.log(Math.max(-1, 5, 7, 3));    => 7

Если в параметрах не число, JS пробует преобразовать его, в противном случае возвращается NaN
console.log(Math.max(-3, null, -5, true));   => 1
console.log(Math.max(1, 'number', 5));       => NaN


B. Math.min
возвращает наименьшее число из перечня в параметрах
console.log(Math.min(-1, 5, 7, 3));          => -1
console.log(Math.min(-3, null, -5, true));   => -5


C. Math.pow
возведение числа в степень
console.log(Math.pow(2, 3));  => 8
console.log(2 ** 3);          => 8      альтернатива


D. Math.sqrt
возвращает квадратный корень числа
console.log(Math.sqrt(9));    => 3
console.log(Math.sqrt('81')); => 9


E. Number.isInteger
проверка на целое число
console.log(Number.isInteger(1));       => true
console.log(Number.isInteger(2.5));     => false

Если значение не относится к типу Number, возвращается false
console.log(Number.isInteger('1'));     => false
console.log(Number.isInteger(1 / 0));     => false
*/










// Код из лекции
// console.log(Math.max(-10, -1, 9, 3));
// console.log(Math.min(-10, -1, 9, 3));
// console.log(Math.max(-10, -1, null));
// console.log(Math.max(-10, -1, undefined));

// console.log(2 ** 3);
// console.log(Math.pow(2, 3));

// console.log(Math.sqrt(9));

// console.log(Number.isInteger(1));
// console.log(Number.isInteger(1.2));
// console.log(Number.isInteger(null));