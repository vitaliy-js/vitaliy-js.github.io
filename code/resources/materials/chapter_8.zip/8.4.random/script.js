const barrel = document.querySelector('b');
const arr = [5, 8, 12, 20, 25];
barrel.textContent = 12;



/*
Math.random 
позволяет получить случайное число от 0 (включительно) до 1 (не включая 1)
console.log(Math.random());   
=> разное значение, например, 0.1258244688957697


Чтобы получить случайное число от 0 до требуемого значения (не включительно), необходимо умножить это число на Math.random:

console.log(Math.random() * 5);
=>  3.0908592786728617   (от 0 до 4)

console.log(Math.floor(Math.random() * 5));
=>  2                    (от 0 до 4)


Часто используется в работе с массивами, когда нужно получить случайный индекс элемента
const arr = ['water', 'tea', 'coffee'];
console.log(arr[Math.floor(Math.random() * arr.length)]);
=> разное значение, например, water


Для поиска в диапозоне используется следующая функция:
const getRandom = (min, max) => {
    return Math.floor(Math.random() * (max - min) + min);
}
console.log(getRandom(2, 4));
=> 2 или 3


Д.З.
Выведите решение в консоль:
1. Нужно случайным образом выбрать того, кто пойдёт к доске решать задачу
const people = ['Вася', 'Зина', 'Люся', 'Олег'];
------------------
2. Загадайте число от 1 до 7 включительно с помощью Math.random()
*/










// Код из лекции
// console.log(Math.random());
// console.log(Math.random() * 4);
// console.log(Math.floor(Math.random() * 4));

// barrel.textContent = Math.floor(Math.random() * 4) + 1;

// console.log(Math.floor(Math.random() * arr.length));
// console.log(arr[Math.floor(Math.random() * arr.length)]);

// const getRandom = arr => arr[Math.floor(Math.random() * arr.length)];
// barrel.textContent = getRandom(arr);

// const getRandom = (min, max) => {
//     return Math.floor(Math.random() * (max - min) + min);
// }
// barrel.textContent = getRandom(2, 4);










/*
Решение Д.З. (способы решения могут отличаться)
1. 
const people = ['Вася', 'Зина', 'Люся', 'Олег'];
console.log(people[Math.floor(Math.random() * people.length)]);
=> Люся 
------------------
2. 
const getRandom = (min, max) => {
    return Math.floor(Math.random() * (max - min) + min);
}
console.log(getRandom(1, 8));
=> 5
*/