


//const num = Number.MAX_SAFE_INTEGER;
/*
Работа с числами (number)
включает в себя целые числа и числа с плавающей точкой (дробные)
console.log(typeof 25);  =>  number
console.log(typeof 99.99);  =>  number


Преобразование значения в число
1. Оператор +
console.log(typeof +'25');         =>  number

2. Объект Number()
console.log(typeof Number('25'));  =>  number
console.log(Number(true));         =>  1
console.log(Number(null));         =>  0


Тип данных BigInt
используется для хранения больших целых чисел
console.log(typeof BigInt(90071992547409952332));     => bigint
console.log(BigInt(num) + 2n)       =>  9007199254740993n


Операторы сравнения чисел:
Равно: == / ===
Больше: >
Меньше: <
Больше или равно: >=
Меньше или равно: <=
Не равно: != / !==
*/










// Код из лекции
// console.log(typeof 25);
// console.log(typeof 36.6);
// console.log(typeof +'25');
// console.log(typeof Number('25'));
// console.log(+true);
// console.log(+false);
// console.log(+null);

// const num = Number.MAX_SAFE_INTEGER;
// console.log(BigInt(num));
// console.log(BigInt(num) + 4n);