const bird = document.querySelector('div');
console.log(bird.offsetWidth, bird.offsetHeight);























// Код из практики
// document.querySelector('ul').addEventListener('click', (e) => {
// 	if (e.target.id === 'bread') {
// 		feedBird(50);
// 	} else if (e.target.id === 'slice') {
// 		feedBird(20);
// 	} if (e.target.id === 'crumbs') {
// 		feedBird(5);
// 	}
// });

// function feedBird(val) {
// 	const bird = document.querySelector('div');
// 	const birdSize = parseInt(bird.style.height);
// 	bird.style.height = `${birdSize + val}px`;
// }