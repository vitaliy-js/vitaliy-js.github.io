const getNumber = (num1, num2) => {
	console.log(num1 / num2);
	return Math.trunc(num1 / num2);
}

document.querySelector('form').addEventListener('submit', (e) => {
    const num = document.querySelectorAll('input');
    const total = document.querySelector('b');
    e.preventDefault();

	if (num[0].value.length > 0 && num[1].value.length > 0) {
		total.textContent = getNumber(num[0].value, num[1].value);
	}
});

console.log();



/*
NaN
специальное значение "не число" (Not a Number), которое обычно говорит о том, что арифметическая операция не определена
console.log(1 - 'Q');
console.log(1 * ['hello']);
=> NaN


Функция isNaN
преобразует значение в число и проверяет относится ли оно к NaN
console.log(isNaN(1 - 'Q'));  => true
console.log(isNaN(1 - 1));    => false


Infinity/-Infinity
специальное значение, представляющее бесконечность
console.log(1 * Infinity);
console.log(5 / 0);
=> Infinity

console.log(-5 / 0);
=> -Infinity


Функция isFinite
определяет, является ли переданное значение числом
console.log(isFinite(2 * 5));  => true
console.log(isFinite('hello'));    => false


isFinite возвращает false для значений NaN и Infinity
console.log(isFinite(1 / 0));
console.log(isFinite(1 - 'a'));
=> false
*/










// Код из лекции
// console.log(1 * 'hello');
// console.log(1 * undefined);

// const getNumber = (num1, num2) => {
// 	const result = Math.round(num1 / num2);
	
// 	if (isNaN(result)) {
// 		alert('В расчёте могут использоваться только цифры');
// 	} else {
// 		return result;
// 	}
// }

// console.log(1 / 0);
// console.log(-1 / 0);
// console.log(1 * 1e999);

// 	if (!isFinite(result)) {
// 		alert('В расчёте могут использоваться только цифры');
// 	} else {
// 		return result;
// 	}