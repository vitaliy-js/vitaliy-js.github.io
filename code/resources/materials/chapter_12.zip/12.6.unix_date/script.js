// const date = new Date();
// console.log(date);



/*
Время Unix
количество секунд с 1 января 1970 00:00:00 UTC
В JavaScript это время представлено в миллисекундах


Дату и время можно получить, создав объект Date с Unix-временем в виде целого числа
const date = new Date(0);
console.log(date);
=> Thu Jan 01 1970 03:00:00 GMT+0300 (Eastern European Standard Time)

console.log(new Date(969792334000));
=> Sun Sep 24 2000 13:45:34 GMT+0300 (Eastern European Summer Time)


Метод now
возвращает количество миллисекунд с 1 января 1970 00:00:00 UTC по текущий момент времени
console.log(Date.now());
=> 1695552099677


Получить выбранное Unix-время можно с помощью метода getTime
const date = new Date(2012, 2, 8);
console.log(date.getTime());
=> 1331157600000


Конвертер:
https://www.epochconverter.com/
*/










// Код из лекции
// const date = new Date(1695569696000);
// const date = new Date(0);
// const date = new Date(1000);
// const date = new Date(-1000);
// console.log(date);

// const date = Date.now();
// console.log(date + 24 * 60 * 60 * 1000);

// const date = new Date(2019, 5, 1);
// console.log(date.getTime());


// document.querySelector('input').addEventListener('input', (e) => {
//     const date = document.querySelector('p');
//     date.textContent = new Date(+e.target.value);
// });