const year = '2023';



/*
Для того, чтобы получить отдельный компонент даты или времени, используется ряд методов:
A. getFullYear() - год
B. getMonth() - месяц (от 0 до 11)
C. getDate() - число
D. getHours() - час
E. getMinutes() - минута
F. getSeconds() - секунда
G. getMilliseconds() - миллисекунда (от 0 до 999)
H. getDay() - день недели (от 0 до 6; первый день недели - воскресенье)
I. getTimezoneOffset() - разница в минутах между местным и всемирным (UTC) временем (в Восточном полушарии будет отрицательное число, в Западном - положительное)
J. getTime() - количество миллисекунд, начиная с 1 января 1970

const date = new Date();
console.log(date.getHours());
=> 10


Чтобы получить данные с привязкой к всемирному времени, используются следующие методы:
getUTCFullYear(), getUTCMonth(), getUTCDate(), getUTCHours(), getUTCMinutes(), getUTCSeconds(), getUTCMilliseconds()

console.log(date.getUTCHours());
=> 7
*/










// Код из лекции
// const date = new Date();

// console.log(date.getFullYear());
// console.log(date.getMonth());
// console.log(date.getMilliseconds());

// console.log(date.getDay());
// console.log(date.getTimezoneOffset());
// console.log(date.getTime());

// console.log(date.getHours());
// console.log(date.getUTCHours());


// const year = new Date().getFullYear();










const monuments = [
	{
		name: 'Пирамида Хеопса',
		constructed: '2570 до н.э.',
		img: 'great_pyramid.png'
	},
	{
		name: 'Стоунхендж',
		constructed: '3100 до н.э.',
		img: 'stonehenge.png'
	}
];
function getAge() {
	return parseInt(this.constructed) + Number(year);
}
for (let i = 0; i < monuments.length; i++) {
	document.querySelector('.monuments').innerHTML += `
	<div>
		<img src="img/${monuments[i].img}">
		<b>${monuments[i].name}</b>
		<i>Возраст: ${getAge.call(monuments[i])}</i>
	</div>`;
}