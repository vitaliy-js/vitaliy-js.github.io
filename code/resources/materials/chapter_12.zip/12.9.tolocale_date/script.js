const date = new Date();
console.log(date);



//'fi' 'ro' 'en-US'  'Asia/Dubai'
/*
Метод toLocaleString
позволяет установить дату и время относительно локализации пользователя (локаль и часовой пояс устройства)
const date = new Date('2012-03-08T16:12:56').toLocaleString();
console.log(date);
=> 08/03/2012, 16:12:56


Параметры:
A. locales - указание локали ('en-AU', 'no' и т.д.)
B. options - дополнительные возможности

const date = new Date('2012-03-08T16:12:56').toLocaleString('en-US');
console.log(date);
=> 3/8/2012, 4:12:56 PM

const date = new Date('2012-03-08T16:12:56').toLocaleString('en-US', {dateStyle: 'medium', timeStyle: 'short', 'hour12': false});
console.log(date);
=> Mar 8, 2012, 16:12


Метод toLocaleDateString
позволяет установить дату относительно локализации пользователя
const date = new Date('2012-03-08T16:12:56').toLocaleDateString('en-US', {dateStyle: 'long'});
console.log(date);
=> March 8, 2012


Метод toLocaleTimeString
позволяет установить время относительно локализации пользователя
const date = new Date('2012-03-08T16:12:56').toLocaleTimeString('en-US', {timeStyle: 'short'});
console.log(date);
=> 4:12 PM
*/










// Код из лекции
// const date = new Date().toLocaleString();

// const date = new Date().toLocaleString('fi');
// const date = new Date().toLocaleString('en-US');

// const date = new Date().toLocaleString('en-US', {month: 'long'});
// const date = new Date().toLocaleString('en-US', {month: 'long', year: '2-digit', day: '2-digit'});

// const date = new Date().toLocaleDateString('en-US', {'timeZone': 'Asia/Dubai'});
// const date = new Date().toLocaleTimeString('en-US', {'timeZone': 'Asia/Dubai', timeStyle: 'short'});

// console.log(date);


// document.querySelector('.wrap').addEventListener('change', () => {
//     const banner = document.querySelector('p');
//     const radio = document.querySelector('input:checked');
//     const calendar = document.querySelector('.calendar');

//     const date = new Date(calendar.value).toLocaleDateString(radio.value);
//     banner.textContent = date;
// });










document.querySelector('.wrap').addEventListener('change', () => {
    const banner = document.querySelector('p');
    const radio = document.querySelector('input:checked');
    const calendar = document.querySelector('.calendar');
});