
























// Код из практики
// const date = new Date();
// setDayTime(date.getHours());
// setSeason(date.getMonth());

// function setDayTime(hour) {
//     const title = document.querySelector('h1');
//     const img = document.querySelector('.day-time');

//     if (hour > 5 && hour < 18) {
//         title.textContent = 'Добрый день!';
//         img.src = 'img/sun.svg';
//     } else {
//         document.body.className = 'night';
//         title.textContent = 'Добрый вечер!';
//         img.src = 'img/moon.svg';
//     }
// }

// function setSeason(month) {
//     const img = document.querySelector('div img');

//     if (month > 1 && month < 5) {
//         img.src = 'img/spring.svg';
//     } else if (month > 4 && month < 8) {
//         img.src = 'img/summer.svg';
//     } else if (month > 7 && month < 11) {
//         img.src = 'img/autumn.svg';
//     } else {
//         img.src = 'img/winter.svg';
//     }
// }