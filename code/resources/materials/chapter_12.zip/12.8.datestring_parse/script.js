const date = new Date();
console.log(date);



/*
Дату и время можно получить, добавив значение в объект Date в виде строки
const date = new Date('2023-09-26T18:02:59+03:00');
console.log(date);
=> Tue Sep 26 2023 18:02:59 GMT+0300 (Eastern European Summer Time)

Формат:
A. Год: YY-MM-DD ('2023-09-26')
B. Время: HH:MM:SS ('18:02:59') 
C. Часовой пояс: +-HH:MM ('+03:00')

Данные можно добавлять частично. В таком случае для неуказанных данных устанавливается начальное значение
console.log(new Date('2023-09-26'));
=> Tue Sep 26 2023 03:00:00 GMT+0300 (Eastern European Summer Time)


Метод parse
используется для преобразования строки в дату в Unix-формате
const date = new Date('1970-01-01');
console.log(Date.parse(date));
=> 0


Д.З.
1. Сейчас 2000 год, вы находитесь в Париже, и до Нового года остаётся 1 минута. Создайте объект Date с этой датой и временем в формате ISO 8601
-------------------
2. Преобразуйте в Unix-формат следующее значение: 1996 год, 8 июня, 14:00:00
*/










// Код из лекции
// const date = new Date('2023-09-25T19:02:59+03:00');
// const date = new Date('2023-09-25');
// const date = new Date('2023-09-25').getFullYear();
// console.log(date);

// const date = new Date('2023-09-25');
// console.log(Date.parse(date));


// document.querySelector('input').addEventListener('change', (e) => {
//     const banner = document.querySelector('p');
//     const date = Date.parse(e.target.value);
//     banner.textContent = date;
// });










/*
Решение Д.З. (способы решения могут отличаться)
1. 
const date = new Date('2000-12-31T23:59:59+01:00');
console.log(date);
=> Mon Jan 01 2001 00:59:59 GMT+0200 (Eastern European Standard Time)
(время и дата может отличаться из-за тайм-зоны на устройстве)
-------------------
2.
const date = new Date('1996-06-08T14:00:00');
console.log(Date.parse(date));
=> 834231600000
*/










document.querySelector('input').addEventListener('change', (e) => {
    const banner = document.querySelector('p');
});