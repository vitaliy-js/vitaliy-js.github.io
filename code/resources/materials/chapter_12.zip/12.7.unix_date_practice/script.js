


// дн. назад   ч. назад   мин. назад





















// Код из практики
// setContent();

// function setLastVisit(lastVisit) {
//     const diff = Math.trunc((Date.now() - lastVisit) / 60000);

//     if (diff >= 1440) {
//         return `${Math.trunc(diff / 1440)} дн. назад`;
//     } else if (diff >= 60) {
//         return `${Math.trunc(diff / 60)} ч. назад`;
//     } else {
//         return `${Math.trunc(diff)} мин. назад`;
//     }
// }

// function setContent() {
//     const wrap = document.querySelector('.friends-wrap');

//     for (let i = 0; i < data.length; i++) {
//         wrap.insertAdjacentHTML('beforeend', `
//         <div class="friend">
//             <img src="img/${data[i].img}">
//             <div>
//                 <b>${data[i].name}</b>
//                 <i>В сети ${setLastVisit(data[i].lastVisit)}</i>
//             </div>
//         </div>`);
//     }
// }