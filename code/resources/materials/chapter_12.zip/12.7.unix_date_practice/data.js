const data = [
    {
        name: 'Аманда',
        img: 'amanda.svg',
        lastVisit: 1695620188000
    },
    {
        name: 'Грег',
        img: 'greg.svg',
        lastVisit: 1693545779000
    }
];