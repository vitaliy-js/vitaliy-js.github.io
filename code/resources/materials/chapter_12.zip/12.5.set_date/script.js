const date = new Date();



/*
Для того, чтобы установить отдельный компонент даты или времени, используется ряд методов:
A. setFullYear() - год
B. setMonth() - месяц (от 0 до 11)
C. setDate() - число
D. setHours() - час
E. setMinutes() - минута
F. setSeconds() - секунда
G. setMilliseconds() - миллисекунда (от 0 до 999)
H. setTime() - количество миллисекунд, начиная с 1 января 1970

const date = new Date();
date.setFullYear(1545);
console.log(date.getFullYear());
=> 1545


Чтобы установить компоненты с привязкой к всемирному времени, используются следующие методы:
setUTCFullYear(), setUTCMonth(), setUTCDate(), setUTCHours(), setUTCMinutes(), setUTCSeconds(), setUTCMilliseconds()

date.setUTCHours(12);
console.log(date);
=> Sat Sep 23 2023 15:23:28 GMT+0300 (Eastern European Summer Time)
*/










// Код из лекции
// date.setFullYear(2022);
// date.setFullYear(2022, 9);

// date.setMonth(5);
// date.setDate(31);
// date.setHours(12);

// date.setHours(date.getHours() + 3);

// date.setUTCHours(date.getHours() + 3);

// console.log(date);