const data = [
    {
        name: 'Дороти',
        img: 'dorothy.svg',
        dob: '1951-11-09'
    },
    {
        name: 'Аманда',
        img: 'amanda.svg',
        dob: '1999-08-28'
    },
    {
        name: 'Мэри',
        img: 'mary.svg',
        dob: '2017-09-29'
    },
    {
        name: 'Грег',
        img: 'greg.svg',
        dob: '1993-05-17'
    }
];