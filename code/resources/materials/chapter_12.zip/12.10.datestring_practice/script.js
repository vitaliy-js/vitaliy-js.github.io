addData();

function addData() {
    const content = document.querySelector('.relatives-wrap');
    for (let i = 0; i < data.length; i++) {
        content.insertAdjacentHTML('beforeend', `
        <div class="relatives">
            <img src="img/${data[i].img}">
            <b>${data[i].name}</b>
            <i> (лет)</i>
        </div>`);
    }
}












// Код из практики
// function setAge(dob) {
//     const date = new Date().getDate() - new Date(dob).getDate();
//     const month = new Date().getMonth() - new Date(dob).getMonth();
//     let year = new Date().getFullYear() - new Date(dob).getFullYear();

//     if (month < 0) {
//         year--;
//     } else if (month === 0 && date < 0) {
//         year--;
//     }

//     return year;
// }

// function addData() {
//     const content = document.querySelector('.relatives-wrap');
//     for (let i = 0; i < data.length; i++) {
//         content.insertAdjacentHTML('beforeend', `
//         <div class="relatives">
//             <img src="img/${data[i].img}">
//             <b>${data[i].name}</b>
//             <i>${setAge(data[i].dob)} (лет)</i>
//         </div>`);
//     }
// }