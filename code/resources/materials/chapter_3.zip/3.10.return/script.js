const numberOne = document.querySelector('#number-1');
const numberTwo = document.querySelector('#number-2');
const result = document.querySelector('b');

document.querySelector('button').addEventListener('click', () => {
   
});



/*
Оператор return
возвращает значение, которое было получено при выполнении функции
function sayHello() {
    return 'Hello';
}
const result = sayHello();
console.log(result);
=> Hello


Важно: код, расположенный после оператора return, игнорируется, так как выполнение функции на этом этапе завершается (данный приём часто используется, чтобы остановить работу функции при определённом условии)
let num = 1;
getNumber();
function getNumber() {
    if (num === 1) {
        return;
    }
    num = 2;
}
console.log(num);
=> 1


Если возвращаемое значение не указано, вместо него возвращается undefined
function sayHello() {
    return;
}
const result = sayHello();
console.log(result);
=> undefined


Д.З.
Вернуться к видео "3.6 Практика. Работа с двумя и более условиями" и переписать код так, чтобы избежать его дублирования, используя функцию и её параметры
*/










// Код из лекции
// document.querySelector('button').addEventListener('click', () => {
//     result.textContent = getSum(+numberOne.value, +numberTwo.value);
// });
 
//  function getSum(num1, num2) {
//     return num1 + num2;
// }










/*
Решение Д.З. (способы решения могут отличаться)
document.querySelector('.btn-send').addEventListener('click', () => {
    if (inputUser.value.length === 0 || inputPwd.value.length === 0) {
        showAlert('alert-success', 'alert-err', 'Все поля должны быть заполнены');
    }
    else if (inputUser.value === '1' && inputPwd.value === '1') {
        showAlert('alert-err', 'alert-success', 'Доступ разрешён');
    } 
    else {
        showAlert('alert-success', 'alert-err', 'Доступ запрещён');
    }
});

function showAlert(removeCl, addCl, text) {
    alert.classList.remove(removeCl);
    alert.classList.add(addCl);
    alertText.textContent = text;
}
*/