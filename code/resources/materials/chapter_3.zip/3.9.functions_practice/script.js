const img = document.querySelector('img');
const title = document.querySelector('b');

document.querySelector('button').addEventListener('click', () => {
    
});


/*
'img/dog.svg', 'img/cat.svg', 'img/parrot.svg'
'Dog', 'Cat', 'Parrot'
*/













// Код из практики
// const img = document.querySelector('img');
// const title = document.querySelector('b');
// let counter = 1;

// document.querySelector('button').addEventListener('click', () => {
//     counter++;
    
//     if (counter === 1) {
//         changeWord('img/dog.svg', 'Dog');
//     } else if (counter === 2) {
//         changeWord('img/cat.svg', 'Cat');
//     } else if (counter === 3) {
//         changeWord('img/parrot.svg', 'Parrot');
//         counter = 0;
//     }
// });

// function changeWord(image, word) {
//     img.src = image;
//     title.textContent = word;
// }