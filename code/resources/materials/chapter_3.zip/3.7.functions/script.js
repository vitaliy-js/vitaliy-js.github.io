const overlay = document.querySelector('.overlay');
const input = document.querySelector('input');
const textarea = document.querySelector('textarea');

document.querySelector('.modal-btn').addEventListener('click', () => {
    overlay.style.display = 'none';
    input.value = '';
    textarea.value = '';
});

document.querySelector('.btn-close').addEventListener('click', () => {
    overlay.style.display = 'none';
    input.value = '';
    textarea.value = '';
});

document.querySelector('.btn-send').addEventListener('click', () => {
    overlay.style.display = 'block';
});



/*
Функция (function)
фрагмент кода, который можно выполнить многократно

Преимущества:
1. Позволяет избежать дублирования кода
2. Структурирует код

Формула:
function имяФункции(параметры) {
    выполнение кода (тело функции)
}

function sayHello() {
    console.log('Hello');
}


Чтобы код внутри функции выполнился, её нужно вызвать следующим образом: 
имяФункции(аргументы);
sayHello();


Требования к названию функции такие же, как и у констант/переменных
Неверно: close modal(), 2closeModal(), close-Modal()
Верно:  closeModal()


Если функция выполняет какое-то действие, часто используют глагол в названии 
(showError, getData, setCounter, removeUser)
*/










// Код из лекции
// function closeModal() {
//     overlay.style.display = 'none';
//     input.value = '';
//     textarea.value = '';
// }

// document.querySelector('.modal-btn').addEventListener('click', () => {
//     closeModal();
// });

// document.querySelector('.btn-close').addEventListener('click', () => {
//     closeModal();
// });

// document.querySelector('.btn-send').addEventListener('click', () => {
//     overlay.style.display = 'block';
// });