const numberOne = document.querySelector('#number-1');
const numberTwo = document.querySelector('#number-2');
const result = document.querySelector('b');

function getSum(num1, num2) {
    const sum = num1 + num2;
    return sum;
}

document.querySelector('button').addEventListener('click', () => {

    result.textContent = getSum(+numberOne.value, +numberTwo.value);

});



/*
Стрелочная функция (arrow function) 
имеет более короткий и компактный синтаксис
const sayHello = () => {
    console.log('Hello');
}
sayHello();
=> Hello


Если функция состоит из одного выражения, которое возвращает значение, оператор return и фигурные скобки можно опустить:
const sayBye = () => 'Bye';

Для сравнения, тот же код, выполненный с использованием объявленной функции (Function declaration):
function sayBye() {
    return 'Bye';
}


Важно: Вызов функции выполняется после её объявления
const callDay = (day) => 'Сегодня ' + day;
console.log(callDay('понедельник'));
=> Сегодня понедельник


Д.З.
1. Перепишите closeModal функцию под синтаксис "Стрелочной функции"
closeModal();
function closeModal() {
    overlay.style.display = 'none';
    input.value = '';
    textarea.value = '';
}
-------------------------
2. Перепишите showAnimal функцию под синтаксис "Стрелочной функции"
showAnimal('img/tiger.svg', 'Tiger');
function showAnimal(image, text) {
    img.src = image;
    title.textContent = text;
    input.value = '';
}
-------------------------
3. Перепишите getText функцию под компактный синтаксис "Стрелочной функции"
getText();
function getText() {
    return 'Hello';
}
*/










// Код из лекции
// const getSum = (num1, num2) => {
//     const sum = num1 + num2;
//     return sum;
// }
// const getSum = (num1, num2) => num1 + num2;










/*
Решение Д.З. (способы решения могут отличаться)
1. 
const closeModal = () => {
    overlay.style.display = 'none';
    input.value = '';
    textarea.value = '';
}
closeModal();
-------------------------
2. 
const showAnimal = (image, text) => {
    img.src = image;
    title.textContent = text;
    input.value = '';
}
showAnimal('img/tiger.svg', 'Tiger');
-------------------------
3.
const getText = () => 'Hello';
getText();
*/