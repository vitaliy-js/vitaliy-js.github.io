const hello = 'hello global';

function getVar() {
    //const hello = 'hello function getVar';
    const bye = 'bye function getVar';
    console.log(hello);
}

// if (2 + 2 === 4) {
//     const hello = 'hello if';
//     console.log(hello);
// }

//getVar();

console.log(hello);


/*
Глобальные переменные (константы)
переменные, объявленные вне блока кода (функции, условного оператора if), которые доступны в любой части программы
const vacation = 'Hello vacation!';
if (season === 'summer') {
    console.log(vacation);
}
console.log(vacation);

Локальные переменные (константы)
переменные, объявленные внутри блока кода (функции, условного оператора if), и они доступны только внутри этого блока
if (season === 'summer') {
    const vacation = 'Hello vacation!';
    console.log(vacation);
}


Локальные переменные имеют приоритет над глобальными переменными с тем же именем
const language = 'I love PHP!';
if (true) {
    const language = 'I love JS!';
    console.log(language);
}
=> I love JS!


Предпочтительнее объявлять локальные переменные
*/










//Код из лекции
// const hello = 'hello global';

// function getVar() {
//     const hello = 'hello function getVar';
//     const bye = 'bye function getVar';
//     console.log(hello);
// }

// // if (2 + 2 === 4) {
// //     const hello = 'hello if';
// //     console.log(hello);
// // }

// getVar();

// console.log(hello);