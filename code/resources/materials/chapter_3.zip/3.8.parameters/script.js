const input = document.querySelector('input');
const img = document.querySelector('img');
const title = document.querySelector('h3');

document.querySelector('button').addEventListener('click', () => {
    if (input.value === 'tiger') {
        img.src = 'img/tiger.svg';
        title.textContent = input.value;
        input.value = '';
    } else if (input.value === 'wolf') {
        img.src = 'img/wolf.svg';
        title.textContent = input.value;
        input.value = '';
    } else if (input.value === 'horse') {
        img.src = 'img/horse.svg';
        title.textContent = input.value;
        input.value = '';
    } else {
        img.src = 'img/other.svg';
        title.textContent = input.value;
        input.value = '';
    }
});



// tiger
// wolf
// horse
/*
A. Аргументы
значения, которые передаются в функции при её вызове
sayHello('Hello');


B. Параметры
переменные, указанные в скобках при объявлении функции
function sayHello(word) {
    console.log(word);
}
=> Hello

Важно: параметры доступны только внутри функции
function sayHello(word) {

}
console.log(word);
=> Error: word is not defined


Тип данных undefined
переменная была объявлена, но ей не было присвоено никакого значения
let word;
console.log(word);
=> undefined


Д.З.
1. Объявите функцию showText, которая будет передавать в консоль значение элемента textarea в виде параметра
-----------------------
2. Объявите функцию showName, в которую можно передавать имя и фамилию, чтобы они выводились в консоль (например, John Smith)
*/










// Код из лекции
// function showAnimal(image, text) {
//     img.src = image;
//     title.textContent = text;
//     input.value = '';
// }

// document.querySelector('button').addEventListener('click', () => {
//     if (input.value === 'tiger') {
//         showAnimal('img/tiger.svg', input.value);
//     } else if (input.value === 'wolf') {
//         showAnimal('img/wolf.svg', input.value);
//     } else if (input.value === 'horse') {
//         showAnimal('img/horse.svg', input.value);
//     } else {
//         showAnimal('img/other.svg', input.value);
//     }
// });










/*
Решение Д.З. (способы решения могут отличаться)
1.
function showText(text) {
    console.log(text);
}
const textarea = document.querySelector('textarea');
showText(textarea.value);
-----------------------
2.
function showName(firstName, lastName) {
    console.log(firstName, lastName);
}
showName('John', 'Smith');
=>  John Smith
*/