document.querySelectorAll('.phone-wrap div').forEach(el => {
    const phone = el.children[1].textContent;
    const color = el.children[2].textContent;

});



// 'Nokia', 'Sony', 'Best'
// 'Blue', 'Pink', 'Green'
/*
Логические операторы
A. Оператор && (И) 
все условия выполняются (true)
if (firstName === 'John' && lastName === 'Smith') {
    console.log(firstName, lastName);
}
=>  John Smith


B. Оператор || (ИЛИ)
хотя бы одно условие выполняется (true)
if (firstName === 'John' || lastName === 'Smith') {
    console.log(firstName, lastName);
}
=>  John Smith
    John Doe
    Donna Smith


Примеры с 3-мя условиями:
if (phone === 'Nokia' ||
    color === 'Pink' || 
    phone === 'Best') {
    console.log(phone, color);
}
=>  Nokia Blue
    Nokia Pink
    Sony Pink
    Nokia Green
    Best Blue

if (phone === 'Nokia' &&
    model === '1100' &&
    color === 'Blue' ) {
    console.log(phone, model, color);
}
=>  Nokia 1100 Blue


Д.З.
Пропишите инструкцию if таким образом, чтобы выполнилось следующее условие:
1. Если actor = 'DiCaprio', actress = 'Winslet' => console.log('Titanic')
----------------------
2. Если actor = 'DiCaprio' или actress = 'Winslet' => console.log('The Wolf of Wall Street')
----------------------
3. Если actor = 'DiCaprio', actor2 = 'Pitt', actress = 'Robbie' => console.log('Once Upon a Time in Hollywood')
*/










// Код из лекции
// if (phone === 'Nokia' && color === 'Blue') {
//     console.log(phone, color);
// }

// if (phone === 'Nokia' || color === 'Blue') {
//     console.log(phone, color);
// }

// if (phone === 'Nokia' ||
//     color === 'Blue' ||
//     color === 'Green' ||
//     phone === 'Sony') {
//     console.log(phone, color);
// }










/*
Решение Д.З. (способы решения могут отличаться)
1.
const actor = 'DiCaprio';
const actress = 'Winslet';
if (actor === 'DiCaprio' &&
    actress === 'Winslet') {
    console.log('Titanic');
}
=> Titanic
----------------------
2.
const actor = 'DiCaprio';
const actress = 'Winslet';
if (actor === 'DiCaprio' || 
    actress === 'Winslet') {
    console.log('The Wolf of Wall Street');
}
=> The Wolf of Wall Street
----------------------
3.
const actor = 'DiCaprio';
const actor2 = 'Pitt';
const actress = 'Robbie';
if (actor === 'DiCaprio' &&
    actor2 === 'Pitt' &&
    actress === 'Robbie') {
    console.log('Once Upon a Time in Hollywood');
}
=> Once Upon a Time in Hollywood
*/