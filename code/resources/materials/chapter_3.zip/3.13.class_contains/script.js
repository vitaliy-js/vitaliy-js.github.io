const cat = document.querySelector('.cat');



/*
Метод contains
проверяет наличие класса в элементе и возвращает true или false
<h1 class="hello">Hello world!</h1>
const title = document.querySelector('h1');


Часто используется с инструкцией if:
if (title.classList.contains('hello')) {
    console.log('Hello');
}
=> Hello


Чтобы выполнить код при отсутствии класса, можно использовать следующий подход:
if (!title.classList.contains('hi')) {
    console.log('Hello');
}
=> Hello
*/










//Код из лекции
// if (cat.classList.contains('cat-smile')) {
//     console.log('smile');
// }

// if (!cat.classList.contains('cat-smile')) {
//     console.log('smile');
// }