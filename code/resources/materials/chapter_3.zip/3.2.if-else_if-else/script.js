const input = document.querySelector('input');

document.querySelector('button').addEventListener('click', () => {
    
});



// 'Введите PIN'
// 'PIN должен содержать 4 цифры'
// 'PIN введён верно'
/*
Инструкция if
выполняет часть кода при определённых условиях

Формула:
if (условие) {
    выполнение кода;
}

Если условие в скобках равняется true, код внутри блока выполняется. При false - игнорируется
const city = 'London';
if (city == 'London') {
    console.log('Hello, London!');
}
=> Hello, London!


Необязательные блоки в инструкции if:
A. else if (добавляется после if) - позволяет прописать выполнение кода с определённым условием. Проверка в нём осуществляется, когда условие в if не выполнилось
if (условие) {
    выполнение кода;
} else if (условие) {
    выполнение кода;
}
const city = 'Paris';
if (city == 'London') {
    console.log('Hello, London!');
} else if (city == 'Paris') {
    console.log('Hello, Paris!');
}
=> Hello, Paris!


B. else (добавляется после if/else if) - позволяет прописать выполнение кода, когда ни одно условие выше не было выполнено. Условие в нём не прописывается
if (условие) {
    выполнение кода;
} else {
    выполнение кода;
}
const city = 'Paris';
if (city == 'London') {
    console.log('Hello, London!');
} else {
    console.log('Hello, Paris!');
}
=> Hello, Paris!

Важно: конструкции else if и else используются исключительно вместе с if и всегда идут после него


Свойство length 
возвращает длину строки (количество символов)
let animal = 'dog';
console.log(animal.length);
=> 3


Д.З.
1. Используя константу color, опишите работу светофора, выводя соответствующее сообщение в консоль:
- red:  стой
- yellow: жди
- green: иди
-------------------
2. Напишите код, который будет отображать состояние погоды в консоли на основе значения константы weather. Необходимо использовать следующие условия:
- sun:  солнечно
- rain: дождь
- snow: снег
- Значение по-умолчанию: облачно
-------------------
3. Вам необходимо описать выполнение кода с помощью константы coin, выводя результат в консоль:
- номинал: решка
- любое другое значение: орёл
*/










// Код из лекции
// document.querySelector('button').addEventListener('click', () => {
//     if (input.value.length == 0) {
//         console.log('Введите PIN');
//     } else if (input.value.length < 4) {
//         console.log('PIN должен содержать 4 цифры');
//     } else {
//         console.log('PIN введён верно');
//     }
// });










/*
Решение Д.З. (способы решения могут отличаться)
1. 
const color = 'green';
if (color  == 'red') {
    console.log('стой');
} else if (color  == 'yellow') {
    console.log('жди');
} else if (color  == 'green') {
    console.log('иди');
}
-------------------
2.
const weather = 'sun';
if (weather == 'sun') {
    console.log('солнечно');
} else if (weather == 'rain') {
    console.log('дождь');
} else if (weather == 'snow') {
    console.log('снег');
} else {
    console.log('облачно');
}
-------------------
3.
const coin = 'номинал';
if (coin == 'номинал') {
    console.log('решка');
} else {
    console.log('орёл');
}
*/