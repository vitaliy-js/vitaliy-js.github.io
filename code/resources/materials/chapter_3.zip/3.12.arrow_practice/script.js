const input = document.querySelector('input');
const result = document.querySelector('section>b');
let discount = 0;

document.querySelector('button').addEventListener('click', () => {
   
});










document.querySelectorAll('.age span').forEach((el, index) => {
    el.addEventListener('click', () => {
        document.querySelector('.age-checked').className = '';
        el.classList.add('age-checked');
        (index === 0) ? discount = 0 : discount = 50;
    });
});










// Код из практики
// document.querySelector('button').addEventListener('click', () => {
//     const getPrice = () => +input.value - (discount * +input.value / 100);
//     result.textContent = getPrice();
//  });