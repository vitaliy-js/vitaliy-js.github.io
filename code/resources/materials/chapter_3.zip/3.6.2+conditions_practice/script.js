const inputUser = document.querySelector('#username');
const inputPwd = document.querySelector('#password');
const alert = document.querySelector('.alert');
const alertText = document.querySelector('.alert p');
const user = '1';
const pwd = '1';

document.querySelector('.btn-send').addEventListener('click', () => {
    if (inputUser.value.length === 0 || inputPwd.value.length === 0) {
        showAlert('alert-success', 'alert-err', 'Все поля должны быть заполнены');
    }
    else if (inputUser.value === '1' && inputPwd.value === '1') {
        showAlert('alert-err', 'alert-success', 'Доступ разрешён');
    } 
    else {
        showAlert('alert-success', 'alert-err', 'Доступ запрещён');
    }

});

function showAlert(removeCl, addCl, text) {
    alert.classList.remove(removeCl);
    alert.classList.add(addCl);
    alertText.textContent = text;
}


// 'Все поля должны быть заполнены'
// 'Доступ разрешён'
// 'Доступ запрещён'


document.querySelector('.btn-close').addEventListener('click', () => {
    alert.className = 'alert';
    alertText.textContent = '';
});










// Код из практики
// document.querySelector('.btn-send').addEventListener('click', () => {
//     if (inputUser.value.length === 0 || inputPwd.value.length === 0) {
//         alert.classList.remove('alert-success');
//         alert.classList.add('alert-err');
//         alertText.textContent = 'Все поля должны быть заполнены';
//     }
//     else if (inputUser.value === '1' && inputPwd.value === '1') {
//         alert.classList.remove('alert-err');
//         alert.classList.add('alert-success');
//         alertText.textContent = 'Доступ разрешён';
//     } 
//     else {
//         alert.classList.remove('alert-success');
//         alert.classList.add('alert-err');
//         alertText.textContent = 'Доступ запрещён';
//     }
// });