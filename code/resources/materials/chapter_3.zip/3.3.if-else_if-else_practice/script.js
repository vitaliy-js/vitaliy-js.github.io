const input = document.querySelector('input');
const img = document.querySelector('img');

document.querySelector('button').addEventListener('click', () => {
    

});

/*
tiger
wolf
horse
*/












// Код из практики
// document.querySelector('button').addEventListener('click', () => {
//     if (input.value == 'tiger') {
//         img.src = 'img/tiger.svg';
//     } else if (input.value == 'wolf') {
//         img.src = 'img/wolf.svg';
//     } else if (input.value == 'horse') {
//         img.src = 'img/horse.svg';
//     } else {
//         img.src = 'img/other.svg';
//     }
// });