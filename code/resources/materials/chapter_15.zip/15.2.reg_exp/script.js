//test@test.com, 99.99
const str = 'Hello';



/*
Регулярные выражения (regular expressions)
способ проверки текста на соответствие определённому шаблону
/шаблон/

Регулярные выражения полезны в следующих случаях:
A. проверка корректности данных
B. замена одного текста на другой
C. поиск значений


Метод test
проверяет, есть ли в строке хотя бы одно совпадение с регулярным выражением

Возвращает следующие значения:
true  - есть совпадение
false - нет совпадения
const str = 'Я люблю JavaScript';
console.log(/JavaScript/.test(str)); => true
console.log(/PHP/.test(str)); => false


Метод replace
замена указанного значения в строке
const str = 'Я люблю PHP';
console.log(str.replace(/PHP/, 'JavaScript'));
=> Я люблю JavaScript


Метод match
выполняет поиск с использованием регулярного выражения и возвращает массив результатов
const str = 'Я люблю JavaScript';
console.log(str.match(/JavaScript/));
=> ['JavaScript', index: 8, input: 'Я люблю JavaScript', groups: undefined]

Если результат не найден, возвращается null
console.log(str.match(/PHP/));
=> null


Метод search
возвращает индекс строки при первом соответствии регулярному выражению. В противном случае возвращается -1
const str = 'Я люблю JavaScript';
console.log(str.search(/JavaScript/));
=> 8


Д.З.
Выведите решение в консоль (с помощью регулярных выражений):
1. Проверьте выигрыш в лотерейном билете с номером 58024332531821
Выигрышная комбинация: 58024332521821
---------------
2. Замените слово Абрикосинка на Вишенка во фразе 'Абрикосинка на торте'
*/










// Код из лекции
// const str = 'Hello';
// const regexp = /Hello/;
// console.log(regexp.test(str));

// const regexp = /world/;
// console.log(/Bye/.test(str));

// const str = 'Hello world';
// const regexp = /world/;
// console.log(str.replace(regexp, 'Earth'));

// console.log(str.match(regexp));

// console.log(str.search(regexp));











/*
Решение Д.З. (способы решения могут отличаться)
1. 
const ticket = '58024332531821';
const regexp = /58024332521821/;
console.log(regexp.test(ticket));
=> false
---------------
2.
const phrase = 'Абрикосинка на торте';
console.log(phrase.replace(/Абрикосинка/, 'Вишенка'));
=> Вишенка на торте
*/