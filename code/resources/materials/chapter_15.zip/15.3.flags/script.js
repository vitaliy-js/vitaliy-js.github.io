const agent = 'Bond, James Bond';
const fact = 'Коты спят по 16-18 часов в день';
const phrase = 'Быть или не быть';



/*
Флаги
расширяют функции регулярных выражений

Флаги добавляются после шаблона
/шаблон/флаги

Примеры флагов:
A. g — глобальный поиск (выполняются все совпадения с шаблоном)
const ship = 'Корабли лавировали, лавировали, да не вылавировали';
console.log(ship.replace(/лавировали/g, 'плыли'));
=> Корабли плыли, плыли, да не выплыли

B. i — регистр букв игнорируется
const hero = 'Superman';
console.log(hero.replace(/superman/i, 'Spiderman'));
=> Spiderman


Можно добавлять несколько флагов
const sun = 'Солнце светит, солнце греет';
console.log(sun.replace(/солнце/gi, 'лампа'));
=> лампа светит, лампа греет


Создание регулярного выражения через функцию-конструктор RegExp:
const regexp = new RegExp('Hello', 'i');
console.log(regexp.test('hello'));
=> true
*/










// Код из лекции
// console.log(agent.match(/Bond/g));

// console.log(agent.replace(/Bond/g, 'Cook'));

// console.log(/коты/i.test(fact));

// console.log(phrase.replace(/быть/ig, 'есть'));

// const cats = 'коты';
// const regexp = new RegExp(cats, 'i');
// console.log(regexp.test(fact));


// function sendComment(comment) {
//     if (comment.toLowerCase().includes(badWord)) {
//         const regexp = new RegExp(badWord, 'gi');
//         comment = comment.replace(regexp, '***');
//     }

//     document.querySelector('.chat-wrap').insertAdjacentHTML('beforeend', `
//         <div class="chat">
//             <div class="avatar"></div>
//             <p>${comment}</p>
//         </div>`);
// }










//Привет, редиска, Как дела, редиска, Ты редиска, редиска
const badWord = 'редиска';
document.querySelector('button').addEventListener('click', (e) => {
    e.preventDefault();
    const comment = document.querySelector('textarea');

    if (comment.value.length > 0) {
        sendComment(comment.value.trim());
        comment.value = '';
    }
});

function sendComment(comment) {
    if (comment.toLowerCase().includes(badWord)) {
        comment = comment.replaceAll(badWord, '***');
    }

    document.querySelector('.chat-wrap').insertAdjacentHTML('beforeend', `
        <div class="chat">
            <div class="avatar"></div>
            <p>${comment}</p>
        </div>`);
}