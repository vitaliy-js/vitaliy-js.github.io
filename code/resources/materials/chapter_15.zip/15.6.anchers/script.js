const phrase = 'JavaScript is the best';
const date = '2010-08-10';



/*
Якоря используются для проверки строки в конкретной точке
^ - представляет начало строки
$ - представляет конец строки
const person = 'John Smith';
console.log(/^Smith/.test(person)); => false
console.log(/Smith$/.test(person)); => true

Для полной проверки строки можно использовать ^ и $ вместе
console.log(/^\w\w\w\w\sSmith$/.test(person)); => true


Квантификатор {число}
указывает количество символьных классов в шаблоне
console.log(/^\w{4}\sSmith$/.test(person));  => true


Д.З.
С помощью функции setTraffic() и метода test настройте необходимый цвет на светофоре:
1. Сделайте проверку значения константы time, чтобы время было в формате электронных часов
Например, 23:59 - зелёный свет; 11:59 PM - красный свет
--------------------
2. Сделайте проверку названия игры в константе game, чтобы был следующий формат: NBA-23
Например, NBA-23 - зелёный свет; FIBA-2023 - красный свет
*/










// Код из лекции
// const phrase = 'JavaScript is the best';
// console.log(/^JavaScript/.test(phrase));
// console.log(/best$/.test(phrase));

// const date = '2010-08-10';
// console.log(/^\d\d\d\d-\d\d-\d\d$/.test(date));
// console.log(/^\d{4}-\d{2}-\d{2}$/.test(date));

// const time = '23:59';
// const time = '11:59 PM';
// setTraffic(/^\d\d:\d\d$/.test(time));










/*
Решение Д.З. (способы решения могут отличаться)
1. 
const time = '23:59';
setTraffic(/^\d\d:\d\d$/.test(time));
const time = '11:59 PM';
setTraffic(/^\d\d:\d\d$/.test(time));
--------------------
2.
const game = 'NBA-23';
setTraffic(/^\w{3}-\d{2}$/.test(game));
const game = 'FIBA-2023';
setTraffic(/^\w{3}-\d{2}$/.test(game));
*/










function setTraffic(val) {
    const wrap = document.querySelector('div');
    if (val) {
        wrap.className = 'green';
    } else {
        wrap.className = 'red';
    }
}