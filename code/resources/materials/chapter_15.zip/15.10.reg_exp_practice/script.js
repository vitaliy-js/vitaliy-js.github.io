document.querySelector('form').addEventListener('submit', (e) => {
    e.preventDefault();

    if (document.querySelector('.alert')) {
        document.querySelector('.alert').remove();
    }

    const input = document.querySelectorAll('input');
    const firstName = '';
    const gender = '';
    const dob = '';
    const email = '';
    const currency = '';

    if (!firstName) {
        
    } else {
        showAlert('Данные введены верно', 'success');
    }
});
//showAlert('Ошибка в поле ""');

function showAlert(text, success) {
    document.body.insertAdjacentHTML('beforeend', 
    `<div class="alert alert-err">
        <p>${text}</p>
        <button class="btn-close"></button>
    </div>`);

    const alert = document.querySelector('.alert');
    if (success) {
        alert.classList.remove('alert-err');
    }
    document.querySelector('.btn-close').addEventListener('click', () => alert.remove());
}

document.querySelector('form').addEventListener('input', () => {
    if (document.querySelector('.alert')) {
        document.querySelector('.alert').remove();
    }
});



//Пример с RegExp:
// const checkData = (field, pattern, flag) => {
//     const regexp = new RegExp(pattern, flag);
//     if (!regexp.test(field.value.trim())) {
//         const str = field.previousElementSibling.textContent;
//         showAlert(`Ошибка в поле "${str.slice(0, -1)}"`);
//         return false;
//     } else {
//         return true;
//     }
// }

// if (!checkData(input[0], '^[а-яё-\\s]+$', 'i') ||
//     !checkData(input[1], '^[мж]$', 'i') ||
//     !checkData(input[2], '^(0[1-9]|1[0-9]|2[0-9]|3[0-1])\.(0[1-9]|1[012])\.(19|20)\\d{2}$') ||
//     !checkData(input[3], '^[\\w-.]+@[\\w-]+\.[\\w-]+$', 'i') ||
//     !checkData(input[4], '^(usd|eur)$', 'i')) {
//     return;
// } else {
//     showAlert('Данные введены верно', 'success');
// }










// Код из практики
// const firstName = /^[а-яё-\s]+$/i.test(input[0].value);
// const gender = /^[мж]$/i.test(input[1].value);
// const dob = /^(0[1-9]|1[0-9]|2[0-9]|3[0-1]\.(0[1-9]|1[012])\.(19|20)\d{2})$/.test(input[2].value);
// const email = /^[\w-.]+@[\w-]+\.[\w-]+$/i.test(input[3].value);
// const currency = /^(usd|eur)$/i.test(input[4].value);

// if (!firstName) {
//     showAlert('Ошибка в поле "Имя"');
// } else if (!gender) {
//     showAlert('Ошибка в поле "Пол"');
// } else if (!dob) {
//     showAlert('Ошибка в поле "Д/Р"');
// } else if (!email) {
//     showAlert('Ошибка в поле "Email"');
// } else if (!currency) {
//     showAlert('Ошибка в поле "Валюта"');
// } else {
//     showAlert('Данные введены верно', 'success');
// }