const year = '2023';
const url = 'red-hat';
const version = '1.0';
console.log(/^$/.test(year));



/*
Квантификатор {число}
указывает количество символьных классов в шаблоне
const price = '12.99';
console.log(/^\d{2}.99$/.test(price)); => true


Квантификатор можно указывать в диапазоне. Для этого через запятую добавляется точка старта и точка финиша:
console.log(/^\d{1,3}.99$/.test(price)); => true

Если точку финиша не указать, значение будет без верхней границы
console.log(/^\d{1,}.99$/.test('1212121212.99')); => true


Короткие записи
A. ? - ноль или один (={0,1})

B. * - ноль или более (={0,})

C. + - один или более (={1,})


Экранирование символов
если нужно использовать символ, который совпадает с синтаксисом регулярных выражений, нужно поставить обратный слеш перед ним
const price = '$12.99';
console.log(/^\$\d{1,}\.99$/.test(price)); => true
*/










// Код из лекции
// console.log(/^\d{1,4}$/.test(year));
// console.log(/^\d{1,}$/.test(year));
// console.log(/^red-{0,1}hat$/.test(url));

// console.log(/^red-?hat$/.test(url));
// console.log(/^red[-_]?hat$/.test(url));

// console.log(/^red[-_]*hat$/.test(url));

// console.log(/^\d+\.0$/.test(version));


// document.querySelector('form').addEventListener('submit', (e) => {
//     if (document.querySelector('.alert')) {
//         document.querySelector('.alert').remove();
//     }
//     e.preventDefault();
//     const input = document.querySelectorAll('input');
//     const fullName = /^[a-z-']{1,}\s[a-z-']{1,}$/i.test(input[0].value);
//     const initials = /^[а-яё-]+\s[а-яё]{1}\.[а-яё]{1}\.$/i.test(input[1].value);

//     if (!fullName) {
//         showAlert('Ошибка в "Full name"', 'error');
//     } 
//     else if (!initials) {
//         showAlert('Ошибка в "Инициалы"', 'error');
//     } 
//     else {
//         showAlert('Данные введены верно');
//     }
// });










document.querySelector('form').addEventListener('submit', (e) => {
    if (document.querySelector('.alert')) {
        document.querySelector('.alert').remove();
    }
    e.preventDefault();
    const input = document.querySelectorAll('input');
    const fullName = '';
    const initials = '';

    if (!fullName) {
        showAlert('Ошибка в "Full name"', 'error');
    } 
    // else if (!initials) {
    //     showAlert('Ошибка в "Инициалы"', 'error');
    // } 
    else {
        showAlert('Данные введены верно');
    }
});
//John Smith  Коваленко И.И.
function showAlert(text, err) {
    document.body.insertAdjacentHTML('beforeend', 
    `<div class="alert">
        <p>${text}</p>
        <button class="btn-close"></button>
    </div>`);

    const alert = document.querySelector('.alert');
    if (err) {
        alert.classList.add('alert-err');
    }
    document.querySelector('.btn-close').addEventListener('click', () => alert.remove());
}

document.querySelector('form').addEventListener('input', () => {
    if (document.querySelector('.alert')) {
        document.querySelector('.alert').remove();
    }
});