const training = 'practice';
const hi = 'Hello';
const fw = '700-';
const letter = 'Ф-letter';

console.log(/practice/.test(training));



/*
Набор символов
для поиска совпадений в наборе символов указываются возможные варианты значений в квадратных скобках
console.log(/[оюа]ля/i.test('Оля')); => true
console.log(/[оюа]ля/i.test('Уля')); => false


Диапозон символов
для увеличения выборки поиска можно использовать диапазон данных с помощью дефиса
console.log(/[п-я]ля/i.test('Оля')); => false
console.log(/[о-я]ля/i.test('Оля')); => true


Частые комбинации диапазона
A. Поиск чисел: [0-9]
console.log(/[0-9]/.test('25 лет')); => true

B. Поиск латинских букв: [A-Za-z]
console.log(/[A-Za-z]-буква/.test('J-буква')); => true
console.log(/[A-Za-z]-буква/.test('j-буква')); => true

C. Комбинация символов
[A-Za-z0-9-] - буквы, числа и тире

D. Поиск кириллицы
[А-ЯËа-яё]
console.log(/[А-ЯËа-яё]ля/i.test('Уля')); => true


Если при поиске нужно исключить данные из набора/диапазона, в начале добавляется знак ^ (карет)
console.log(/[^оюа]ля/i.test('Уля')); => true


Д.З.
С помощью функции setTraffic() и метода test, настройте нужный цвет на светофоре:
1. В константе gender допускается только 2 значения: 'м' или 'ж'
Например, 'м' - зелёный свет; 'ф' - красный свет
------------------
2. Первая буква имени человека должна быть в следующем диапазоне: от А до Ж
Например, Гена - зелёный свет; Уля - красный свет
*/










// Код из лекции
// console.log(/practi[cs]e/.test(training));

// console.log(/H[a-e]llo/.test(hi));
// console.log(/[A-Za-z]ello/.test(hi));

// console.log(/[^A-Za-z]ello/.test(hi));

// console.log(/^[7-9][0-9][0-9]-$/.test(fw));
// console.log(/[А-ЯËа-яё]-letter/.test(letter));










/*
Решение Д.З. (способы решения могут отличаться)
1. 
const gender = 'м';
setTraffic(/^[мж]$/.test(gender));
------------------
2.
const firstName = 'Гена';
setTraffic(/^[А-ЖË]/.test(firstName));
*/










function setTraffic(val) {
    const wrap = document.querySelector('div');
    if (val) {
        wrap.className = 'green';
    } else {
        wrap.className = 'red';
    }
}