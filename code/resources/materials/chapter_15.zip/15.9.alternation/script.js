const best = 'JS is the best';
console.log(/^[] is the best$/i.test(best));



/*
Альтернация
позволяет осуществить проверку между вариантами разной длины

Альтернацию можно применить к части шаблона, заключив её в скобки

Пример для метода test:
const time = '12:00 am';
console.log(/^12:00 (pm|am)$/i.test(time)); => true

Пример для метода match:
const time = '12:00 am';
console.log(time.match(/^12:00 (pm|am)$/i));
=> ['12:00 am', 'am', index: 0, input: '12:00 am', groups: undefined]


Д.З.
Выведите решение в консоль:
1. Нужно установить проверку, при которой константа phrase должна возвращать true со следующими именами: Гоша, Гога, Жора
Пример: const phrase = 'Меня зовут Гоша';
--------------------
2. Из 'cat.png' нужно получить строку, которая будет содержать название изображения и один из следующих форматов: png, jpg, svg
Пример: cat.png;
*/










// Код из лекции
// console.log(/^(js|html|css) is the best$/i.test(best));

// console.log(best.match(/^(js|html|css) is the best$/i));










/*
Решение Д.З. (способы решения могут отличаться)
1. 
const phrase = 'Меня зовут Гоша';
console.log(/^Меня зовут (Гоша|Гога|Жора)$/i.test(phrase));
=> true
--------------------
2.
const img = 'cat.png';
console.log(img.match(/cat\.(png|jpg|svg)/)[0]);
=> cat.png
*/