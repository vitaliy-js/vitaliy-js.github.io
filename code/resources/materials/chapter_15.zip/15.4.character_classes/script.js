const fact = 'Elephants can weigh up to 6,800 kilograms';
const capital = `Buenos Aires`;
const cssId = '#fw-700_m';
const agentName = `JS`;



/*
Символьные классы
позволяют установить определенный тип символов для шаблона

A. Цифровой символ (\d) - включает цифры от 0 до 9
B. Пробельный символ (\s) - включает пробелы, таб и перенос строки
C. Буквенный символ (\w) - включает латинские буквы, цифры и нижнее подчёркивание
const temperature = 'Абсолютный температурный минимум составил −93°C';
console.log(temperature.match(/\d/g));
=> ['9', '3']


Обратные символьные классы:
A. Цифровой символ (\D) - соответствует любому нецифровому символу
B. Пробельный символ (\S) - любой символ, кроме пробела, таба и переноса строки
C. Буквенный символ (\W) - не включает латинские буквы, цифры и нижнее подчёркивание
const year = '2023 year';
console.log(year.match(/\W/g));
=> [' ']


Классы можно комбинировать:
const person = 'Teddy';
console.log(person.match(/\w\w\w/g));
=> ['Ted']


Точка
соответствует любому символу, кроме переноса строки
const sign = 'J+M';
console.log(/\w.\w/.test(sign));
=> true
*/










// Код из лекции
// console.log(fact.match(/\d/));
// console.log(fact.match(/\d/g));
// console.log(fact.match(/\d/g).join(''));

// console.log(/\s/.test(capital));

// console.log(cssId.match(/\w/g));

// console.log(fact.match(/\D/g));
// console.log(cssId.match(/\W/g));

// console.log(fact.match(/\d\d\d/));

// console.log(agentName.match(/./g));