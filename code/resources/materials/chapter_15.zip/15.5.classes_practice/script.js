document.querySelector('form').addEventListener('submit', (e) => {
    e.preventDefault();
    const input = document.querySelector('input');
    const banner = document.querySelector('.banner');
    
});
//'Поле не может быть пустым', 'Возраст не содержит цифры', 'Некорректный формат'

function showAlert(text) {
    document.body.insertAdjacentHTML('beforeend', 
    `<div class="alert">
        <p>${text}</p>
        <button class="btn-close"></button>
    </div>`);

    document.querySelector('.btn-close').addEventListener('click', () => document.querySelector('.alert').remove());
}

document.querySelector('input').addEventListener('input', () => {
    if (document.querySelector('.alert')) {
        document.querySelector('.alert').remove();
    }
});










// Код из практики
// if (input.value.length === 0) {
//     showAlert('Поле не может быть пустым');
// } else if (!/\d/.test(input.value)) {
//     showAlert('Возраст не содержит цифры');
// } else if (input.value.match(/\d/g).length > 3) {
//     showAlert('Некорректный формат');
// } else {
//     const age = input.value.match(/\d/g).join('');
//     banner.textContent = age;
// }