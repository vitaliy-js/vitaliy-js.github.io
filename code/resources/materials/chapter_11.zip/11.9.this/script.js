const img = document.querySelector('img');
const scroodge = {
	firstName: 'Скрудж',
	lastName: 'Макдак',
	getFullName() {
		return `${scroodge.firstName} ${scroodge.lastName}`;
	}
};



/*
Метод объекта
свойство объекта, являющееся функцией
const couple = {
	male: 'Ромео',
	female: 'Джульета',
	makeNote() {
		return `${couple.male}+${couple.female}`;
	}
};
console.log(couple.makeNote()); => Ромео+Джульета


Ключевое слово this
позволяет ссылаться на текущий объект
const couple = {
	male: 'Ромео',
	female: 'Джульета',
	makeNote() {
		return `${this.male}+${this.female}`;
	}
};
console.log(couple.makeNote()); => Ромео+Джульета


This в стрелочных функциях
У стрелочных функций нет собственного значения this
const couple = {
	male: 'Ромео',
	female: 'Джульета',
	makeNote: () => {
		return `${this.male}+${this.female}`;
	}
};
console.log(couple.makeNote());
=> undefined+undefined


При попытке использования this в стрелочных функциях, его значение берётся снаружи
document.querySelector('h2').addEventListener('click', () => {
	console.log(this);
});
=> Window

При использовании функций, объявленных через function, значение this в обработчиках событий ссылается на объект, на котором произошло событие
document.querySelector('h2').addEventListener('click', function() {
	console.log(this.textContent);
});
=> Ключевое слово this
*/










// Код из лекции
// const scroodge = {
// 	firstName: 'Скрудж',
// 	lastName: 'Макдак',
// 	getFullName() {
// 		return `${this.firstName} ${this.lastName}`;
// 	}
// };
// console.log(scroodge.getFullName());

// img.addEventListener('click', function() {
// 	console.log(this.src);
// });

// img.addEventListener('click', () => {
// 	console.log(this.src);
// });