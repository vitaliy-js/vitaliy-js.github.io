const carCountry = document.querySelector('i');
const car = {
	brand: 'bmw',
	type: 'sports car'
};
const plant = {
	country: 'uk'
};

document.querySelector('b').textContent = car.brand;
document.querySelector('i').textContent = plant.country;



/*
Копирование объекта
Если в переменную (аргумент) передать объект, будет создана ссылка на переданный объект. И в случае её редактирования, исходный объект будет изменён
const person = {
	firstName: 'Джон',
	img: 'john.svg'
};
showAvatar(person);

function showAvatar(obj) {
	obj.img = 'js.svg';
}
console.log(person); => {firstName: 'Джон', img: 'js.svg'}


Метод Object.assign
позволяет скопировать в один объект все свойства из других объектов

Параметры метода:
А. Целевой объект - принимает свойства других объектов
B. Остальные объекты - копируются в целевой

Формула:
Object.assign(целевой объект, остальные объекты);

const newObj = Object.assign({}, person);
newObj.img = 'js.svg';
console.log(newObj); => {firstName: 'Джон', img: 'js.svg'}
console.log(person); => {firstName: 'Джон', img: 'john.svg'}


Пример с копированием двух объектов
const person = {
	firstName: 'Джон',
	img: 'john.svg'
};
const employee = {
	job: 'manager'
};
const newObj = Object.assign({}, person, employee);
console.log(newObj); => {firstName: 'Джон', img: 'john.svg', job: 'manager'}


Копирование объекта с изменением свойства
const newObj = Object.assign({}, person, {firstName: 'Джеймс'});
console.log(newObj);
=> {firstName: 'Джеймс', img: 'john.svg'}


Если в объекте есть два одинаковых свойства, значение последнего свойства перезапишет предыдущее
const person = {
	firstName: 'Джон',
	img: 'john.svg',
	firstName: 'Джеймс'
};
console.log(person);
=> {firstName: 'Джеймс', img: 'john.svg'}
*/










// Код из лекции
// let myCar = car;
// myCar.brand = 'audi';
// console.log(myCar);
// console.log(car);

// const myCar = Object.assign({}, car);
// myCar.brand = 'audi';
// console.log(myCar);
// console.log(car);

// const myCar = Object.assign({}, car, plant);

// const myCar = {
// 	color: 'blue'
// }
// Object.assign(myCar, car, plant, {country: 'germany'});
// console.log(myCar);

// const myCar = Object.assign({}, car, {brand: 'audi'});
// document.querySelector('b').textContent = myCar.brand;
// document.querySelector('i').textContent = plant.country;