


//London is the capital of Great Britain
/*
Для создания объекта с помощью конструктора используется ключевое слово new и функция-конструктор
const vasya = new People('Вася', 'developer');
function People(name, position) {
	this.name = name;
	this.position = position;
}
console.log(vasya);
=> {name: 'Вася', position: 'developer'}


Данный подход упрощает создание другого объекта с аналогичными свойствами и методами
const lenya = new People('Лёня', 'qa');
console.log(lenya);
 => {name: 'Лёня', position: 'qa'}


В конструктор можно добавить метод:
function People(name, position) {
	this.name = name;
	this.position = position;
	this.motivator = function() {
		return `${this.name} лучший ${this.position} в мире!`;
	}
}
const vasya = new People('Вася', 'developer');
console.log(vasya.motivator());
=> Вася лучший developer в мире!


Д.З.
Создайте функцию-конструктор со следующем товаром на продажу:
1. Название товара: 'слон'
2. Стоимость: 'бесплатно'
3. Текст объявления: 'Продаётся слон за бесплатно'
*/










// Код из лекции
// const france = new Object();
// france.name = 'France';
// france.capital = 'Paris';
// console.log(france);


// const france = new Country('France', 'Paris');
// const greatBritain = new Country('Great Britain', 'London');

// function Country(name, capital) {
// 	this.name = name;
// 	this.capital = capital;

// 	this.phrase = function() {
// 		return `${this.capital} is the capital of ${this.name}`;
// 	}
// }

// console.log(france);
// console.log(greatBritain);
// console.log(france.phrase());










/*
Решение Д.З. (способы решения могут отличаться)
const advertisement = new Sale('слон', 'бесплатно');

function Sale(name, price) {
	this.name = name;
	this.price = price;
	this.text = function() {
		return `Продаётся ${this.name} за ${this.price}`;
	}
}

console.log(advertisement.text());
=> Продаётся слон за бесплатно
*/