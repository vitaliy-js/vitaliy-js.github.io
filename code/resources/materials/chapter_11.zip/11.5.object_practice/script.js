const scrooge = {
	name: 'Макдак',
	img: 'scrooge.png',
	assets: '15.4$',
	bank: '50$',
	traits: 'жадность'
};
const info = {
	city: 'Глазго',
	gender: 'мужской',
	species: 'утка'
};

/*
	1. Удалить свойство traits
	2. Добавить свойство age = 80
	3. Заменить значение в name на Скрудж
	4. Добавить метод для расчёта: assets + bank
	5. Добавить объект info и переименовать Глазго в Дакбург
*/













// Код из практики
// delete scrooge.traits;
// scrooge.age = 80;
// scrooge.name = 'Скрудж';
// scrooge.getTotal = () => {
// 	return parseFloat(scrooge.assets) + parseFloat(scrooge.bank);
// }
// Object.assign(scrooge, info, {city: 'Дакбург'});

// showProfile(scrooge);

// function showProfile(obj) {
// 	document.querySelector('.profile').innerHTML = `
// 	<div class="info">
// 		<img src="img/${obj.img}">
// 		<b>${obj.name}</b>
// 	</div>
// 	<ul>
// 		<li><span>Город: </span>${obj.city}</li>
// 		<li><span>Возраст: </span>${obj.age}</li>
// 		<li><span>Доход: </span>$${obj.getTotal()}млн</li>
// 	</ul>`;
// }