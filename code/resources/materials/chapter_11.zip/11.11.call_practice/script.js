const monuments = [
	{
		name: 'Пирамида Хеопса',
		constructed: '2570 до н.э.',
		img: 'great_pyramid.png'
	},
	{
		name: 'Стоунхендж',
		constructed: '3100 до н.э.',
		img: 'stonehenge.png'
	}
];













// Код из практики
// const year = '2023';
// function getAge() {
// 	return parseInt(this.constructed) + Number(year);
// }

// for (let i = 0; i < monuments.length; i++) {
// 	document.querySelector('.monuments').innerHTML += `
// 	<div>
// 		<img src="img/${monuments[i].img}">
// 		<b>${monuments[i].name}</b>
// 		<i>Возраст: ${getAge.call(monuments[i])}</i>
// 	</div>`;
// }