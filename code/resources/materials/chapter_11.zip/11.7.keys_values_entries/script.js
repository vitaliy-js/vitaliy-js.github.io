const family = {
	wife: 'Linda',
	son: 'Jack',
	daughter: 'Amanda'
};
showFamily();



/*
Метод Object.keys
возвращает массив ключей объекта
const myCity = {
	city: 'London',
	country: 'UK'
};
console.log(Object.keys(myCity));
=> ['city', 'country']


Метод Object.values
возвращает массив значений объекта
console.log(Object.values(myCity));
=> ['London', 'UK']


Метод Object.entries
возвращает массив, элементы которого включают ключи и значения в формате [key, value]
console.log(Object.entries(myCity));
=>
[
	['city', 'London'],
	['country', 'UK']
]


Метод Object.fromEntries
принимает список пар ключ-значение и возвращает новый объект
const countryArr = Object.entries(myCity).find(item => item[1] === 'UK');
const myCountry = Object.fromEntries([countryArr]);
console.log(myCountry);
=> {country: 'UK'}


Метод hasOwnProperty
проверка на наличие свойства в объекте
true - содержится
false - отсутствует
console.log(myCity.hasOwnProperty('city'));
=> true


Д.З.
Создайте новый объект stringMethods, который будет включать в себя только методы строк
const methods = {
	trim: 'string',
	random: 'number',
	toUpperCase: 'string',
	parseInt: 'number',
	forEach: 'array',
	replaceAll: 'string'
};
*/










// Код из лекции
// console.log(Object.keys(family));
// console.log(Object.keys(family).includes('wife'));

// console.log(Object.values(family));
// console.log(Object.values(family).includes('Jack'));

// console.log(family.hasOwnProperty('wife'));

// console.log(Object.entries(family).sort());


// let family = {
// 	wife: 'Linda',
// 	son: 'Jack',
// 	daughter: 'Amanda'
// };
// const familyArr = Object.entries(family).sort();
// family = Object.fromEntries(familyArr);
// showFamily();










/*
Решение Д.З. (способы решения могут отличаться)
const methodsArr = Object.entries(methods).filter(item => item[1] === 'string');
const stringMethods = Object.fromEntries(methodsArr);
console.log(stringMethods);
=> {trim: 'string', toUpperCase: 'string', replaceAll: 'string'}
*/










function showFamily() {
	for (let key in family) {
		document.querySelector('ul').innerHTML += `
		<li>${family[key]} <i>(${key})</i></li>`;
	}
}