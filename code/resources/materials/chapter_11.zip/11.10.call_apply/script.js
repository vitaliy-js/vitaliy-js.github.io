const scrooge = {
	name: 'Скрудж',
	assets: 15.4,
	bank: 50
};
const flintheart = {
	name: 'Флинтхарт',
	assets: 17.1,
	bank: 38
};



/*
Метод call
позволяет вызвать функцию с указанным значением this и передать ей аргументы. Это особенно полезно, когда нужно использовать метод одного объекта для других объектов

Алгоритм
1. Прописываем функцию с использованием this
const js = {
	name: 'JavaScript'
};
function getName(word) {
	return `${word}, ${this.name}!`;
}

2. Используем метод call

Формула:
функция.call(значение this, аргументы)

console.log(getName.call(js, 'Hello'));
=> Hello, JavaScript!


Метод apply
идентичен call, но в аргументах используется не список, а массив

Формула:
функция.apply(значение this, массив из аргументов)

function getName(param1, param2) {
	return `${param1}, ${this.name}! The best ${param2}`;
}
console.log(getName.apply(js, ['Hello', 'forever']));
=> Hello, JavaScript! The best forever
*/










// Код из лекции
// function getTotal() {
// 	return this.assets + this.bank;
// }
// console.log(getTotal.call(scrooge));
// console.log(getTotal.call(flintheart));


// function getTotal(currency) {
// 	return this.assets + this.bank + currency;
// }
// console.log(getTotal.call(scrooge, ' USD'));
// console.log(getTotal.call(flintheart, ' GBP'));
// document.querySelector('tbody').innerHTML = `
// 	<tr>
// 		<td>${scrooge.name}</td>
// 		<td>${getTotal.call(scrooge, ' USD')}</td>
// 	</tr>
// 	<tr>
// 		<td>${flintheart.name}</td>
// 		<td>${getTotal.call(flintheart, ' GBP')}</td>
// 	</tr>`;


// function getTotal(benefit, currency) {
// 	return this.assets + this.bank + benefit + currency;
// }
// console.log(getTotal.apply(scrooge, [5, ' USD']));
// console.log(getTotal.apply(flintheart, [4, ' GBP']));










document.querySelector('tbody').innerHTML = `
	<tr>
		<td>${scrooge.name}</td>
		<td></td>
	</tr>
	<tr>
		<td>${flintheart.name}</td>
		<td></td>
	</tr>`;