


/*
Конструкция class
специальная функция, которая позволяет создать объект и хранить методы, связанные с ним
class Country {
}
const france = new Country();
console.log(france);
=> Country {}


Метод constructor
используется для создания нового объекта в классе
class Country {
	constructor(name, capital) {
		this.name = name;
		this.capital = capital;
	}
}
const france = new Country('France', 'Paris');
console.log(france);
=> {name: 'France', capital: 'Paris'}


Внутри класса можно добавлять собственные методы:
class Country {
	constructor(name, capital) {
		this.name = name;
		this.capital = capital;
	}

	phrase() {
		return `${this.capital} is the capital of ${this.name}`;
	}
}
const france = new Country('France', 'Paris');
console.log(france.phrase());
=> Paris is the capital of France
*/










// Код из лекции
// class Order {
// 	constructor(dish, price) {
// 		this.dish = dish;
// 		this.price = price;
// 	}

// 	getTip = function() {
// 		return Math.ceil(this.price * 0.1);
// 	}
// }

// const table = new Order('borsh', 9.99);
// const table2 = new Order('duck', 19.99);

// console.log(table);
// console.log(table2);
// console.log(table.getTip());
// console.log(table2.getTip());