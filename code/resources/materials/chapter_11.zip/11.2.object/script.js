const person = {
	firstName: 'Джон',
	lastName: 'Смит',
	age: 32,
	job: undefined,
	married: false,
	hobby: ['футбол', 'машины'],
	getFullName: () => {
		return `${person.firstName} ${person.lastName}`
	}
};



/*
Объекты
тип данных для хранения коллекции значений

Объект представлен в виде набора свойств, которые состоят из пары 'ключ-значение'

Пример создания объекта через литеральный синтаксис:
const phone = {
	model: 'Best',
	count: 5,
	price: '100$',
	discount: false,
	color: ['red', 'green', 'blue'],
	discountPrice: () => parseFloat(phone.price) - phone.discount
};


Доступ к значению выполняется следующим образом:
console.log(phone.model);     => Best

Значение может включать любой тип данных
console.log(phone.discount);  => false
console.log(phone.count);     => 5


Обращение к свойству может также выполняться через квадратные скобки
console.log(phone['count']);  => 5


Метод
функция, которая является свойством объекта. Она привязана к объекту, в котором находится, поэтому при её вызове нужно указывать этот объект
console.log(phone.discountPrice());
=> 100
*/










// Код из лекции
// console.log(person.firstName);
// console.log(person.age);

// console.log(person['age']);

// const employee = {
// 	'first-name': 'John'
// };
// console.log(employee['first-name']);

// console.log(person.getFullName());

// const person = {
// 	firstName: 'Джон',
// 	lastName: 'Смит',
// 	getFullName() {
// 		return `${person.firstName} ${person.lastName}`
// 	}
// };
// console.log(person.getFullName());