const data = {
    first_name: 'John',
    last_name: 'Smith',
    age: 25,
    maried: false,
    social_network: null,
    hobby: ['cars', 'food'],
    family: {
        wife: 'Linda'
    }
};



/*
JSON (JavaScript Object Notation)
формат обмена данными, основанный на JavaScript
{
    "model": "audi",
    "age": 2
}


Отличия от объектов:
А. Ключи указаны в двойных кавычках
B. Для строк используются двойные кавычки
C. Содержит только свойства (без методов)
D. Тип данных undefined не используется


Метод JSON.stringify
конвертирует JavaScript-объект в JSON-строку. Используется для отправки данных на сервер
const car = {
    'model': 'audi',
    'age': 2
}
console.log(JSON.stringify(car));
=> {"model":"audi","age":2}


Метод JSON.parse
конвертирует JSON-строку в JavaScript-объект
const jsondata = '{"model": "audi", "age": 2}';
console.log(JSON.parse(jsondata));
=> {model: 'audi', age: 2}
*/










// Код из лекции
// const jsonObj = JSON.stringify(data);
// console.log(jsonObj);

// const obj = JSON.parse(jsonObj);
// console.log(obj.age);