const cars = {
	james: ['bmw', 'developer'],
	john: ['fiat', 'manager'],
	amanda: ['honda', 'manager'],
	tina: ['skoda', 'developer']
};



















// Код из практики
// const carsArr = Object.entries(cars);
// showCars(carsArr);

// document.querySelector('form').addEventListener('change', (e) => {
// 	if (e.target.value === 'all') {
// 		showCars(carsArr);
// 		return;
// 	}

// 	const filterCars = carsArr.filter((item) => {
// 		return e.target.value === item[1][1];
// 	});
// 	showCars(filterCars);
// });

// function showCars(arr) {
// 	const carsWrap = document.querySelector('.cars');
// 	carsWrap.innerHTML = ``;

// 	arr.sort();
// 	arr.forEach((el) => {
// 		carsWrap.innerHTML += `
// 		<div>
//             <img src="img/${el[1][0]}.svg">
//             <b>${el[0]}</b>
//         </div>`; 
// 	});
// }