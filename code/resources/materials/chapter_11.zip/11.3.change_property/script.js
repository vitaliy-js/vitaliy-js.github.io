const person = {
	firstName: 'Джон',
	lastName: 'Смит',
	married: false,
	hobby: ['футбол', 'машины'],
	girlfriend: 'Джейн'
};



//'семейный отдых', 'Джейн', 'Том'
/*
Изменения в объекте
const car = {
	brand: 'bmw',
	color: 'pink',
	age: 30
};

A. Изменение значения
car.color = 'black';
console.log(car);
=> {brand: 'bmw', color: 'black', age: 30}


B. Добавление нового свойства и значения
car.country = 'Germany';
console.log(car);
=> {brand: 'bmw', color: 'pink', age: 30, country: 'Germany'}


C. Удаление свойства (с помощью оператора delete):
delete car.age
console.log(car);
=> {brand: 'bmw', color: 'pink'}


При вызове свойства, которого нет в объекте, возвращается значение undefined
console.log(car.owner);
=> undefined


Д.З.
const film = {
	name: 'Мистер и миссис Браун',
	year: '2005',
	genre: ['боевик', 'мультфильм', 'комедия'],
	resource: 'информации нет'
};

Выполните следующие действия в объекте:
1. Измените имя фильма на 'Мистер и миссис Смит'
2. Замените жанр 'мультфильм' на 'мелодрама'
3. Удалите свойство resource
*/










// Код из лекции
// person.married = true;
// person.hobby.unshift('семейный отдых');

// person.job = 'manager';
// person.family = {
// 	wife: 'Джейн',
// 	son: 'Том'
// };

// delete person.girlfriend;

// console.log(person);










/*
Решение Д.З. (способы решения могут отличаться)
1. film.name = 'Мистер и миссис Смит';
2. film.genre.splice(1, 1, 'мелодрама');
3. delete film.resource;

console.log(film);
 => 
 {
	name: 'Мистер и миссис Смит',
	year: '2005',
	genre: ['боевик', 'мелодрама', 'комедия']
}
*/