const price = {
	id: 1,
	subtotal: '20',
	tax: '5',
	discount: '10',
	total: '15'
};
showInvoice(price);



/*
Цикл for in
осуществляет перебор всех свойств объекта

Формула:
for (ключ in объект) {
	тело цикла
}

A. Ключ (key, prop) - имя свойства прописывается через переменную для каждой итерации цикла
B. Объект - объект, чьи свойства перебираются
const info = {
	city: 'Дакбург',
	species: 'утка'
};
for (let key in info) {
	console.log(key);
}
=> city species


Перебор значений:
for (let key in info) {
	console.log(info[key]);
}
=> Дакбург утка


Внутри цикла часто добавляют инструкцию if
for (let key in info) {
	if (key === 'city') {
		info[key] = 'Глазго';
	}
}
console.log(info);
=> {city: 'Глазго', species: 'утка'}


Операторы break и continue здесь также можно использовать:
for (let key in info) {
	if (key === 'city') {
		continue;
	}
	info[key] = info[key] + ' the best';
}
console.log(info);
=> {city: 'Дакбург', species: 'утка the best'}


Д.З.
С помощью цикла for...in добавьте 'https://' к значениям тех ключей, в названиях которых содержится слово 'Link' (например, 'google.com' => 'https://google.com')
const myLinks = {
	title: 'Мои ссылки',
	searchLink: 'google.com',
	mailLink: 'mail.google.com',
	infoLink: 'wikipedia.org'
};
*/










// Код из лекции
// for (let key in price) {
// 	console.log(key);
// }

// for (let key in price) {
// 	console.log(price[key]);
// }

// for (let key in price) {
// 	if (key === 'tax' || key === 'discount') {
// 		delete price[key];
// 	}
// }
// console.log(price);

// setCurrency('$');
// function setCurrency(val) {
// 	for (let key in price) {
// 		if (key === 'id') {
// 			continue;
// 		}
// 		price[key] += val;
// 	}
// 	showInvoice(price);
// }










/*
Решение Д.З. (способы решения могут отличаться)
for (let key in myLinks) {
	if (!key.includes('Link')) {
		continue;
	}
	myLinks[key] = `https://${myLinks[key]}`;
}
console.log(myLinks);
=>
{
    title: 'Мои ссылки',
    searchLink: 'https://google.com',
    mailLink: 'https://mail.google.com',
    infoLink: 'https://wikipedia.org'
}
*/










function showInvoice(price) {
	document.querySelector('table').innerHTML = `
	<tr>
		<th>Subtotal:</th>
		<td>${price.subtotal}</td>
	</tr>
	<tr>
		<th>Tax:</th>
		<td>${price.tax}</td>
	</tr>
	<tr>
		<th>Discount:</th>
		<td>${price.discount}</td>
	</tr>
	<tr>
		<th>Total:</th>
		<td>${price.total}</td>
	</tr>`;
}