/*

Полезные ресурсы:
1. Learn JavaScript:  learn.javascript.ru
2. MDN Web Docs:      developer.mozilla.org/ru/docs/Web/JavaScript
3. W3Schools:         w3schools.com/js
4. Stack Overflow:    stackoverflow.com
5. ChatGPT:           chatgpt.com

*/