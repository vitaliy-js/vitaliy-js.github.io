//https://petstore.swagger.io/v2/pet
const petId = '4223372036858';
getPets('available');

document.querySelectorAll('li').forEach((el) => {
    el.addEventListener('click', () => {
        document.querySelector('.status-checked').className = '';
        el.className = 'status-checked';
        getPets(el.textContent.toLowerCase());
    });
});

//Get pets
getPets('available');
async function getPets(status) {
    const res = await fetch(`https://petstore.swagger.io/v2/pet/findByStatus?status=${status}`);
    const data = await res.json();
    const filterData = data.filter((item) => String(item.id).includes(petId));
    showPets(filterData);
}

//Add pet
document.querySelector('.toolbar-btn')
.addEventListener('click', () => {
    createModal([petId, '', '', 'available']);

    document.querySelectorAll('.modal-btn button')[0]
    .addEventListener('click', () => {
        const data = createBody();
        addPet(data);
    });
});

async function addPet(data) {
    const res = await fetch('https://petstore.swagger.io/v2/pet', {
        method: 'POST',
        headers: {
            'Content-type': 'application/json'
        },
        body: JSON.stringify(data)
    });

    if (res.status === 200) {
        closeOverlay();
        getPets(data.status);
        setStatus(data.status);
    }
}

function showPets(data) {
    const wrap = document.querySelector('.wrap');
    wrap.innerHTML = '';
    wrap.className = 'wrap';

    if (data.length > 0) {
        for (let i = 0; i < data.length; i++) {
            wrap.insertAdjacentHTML('beforeend', `
            <div class="pet">
                <b>${data[i].name}</b>
                <i>${data[i].category.name}</i>
                <div class="pet-btn">
                    <button></button>
                    <button></button>
                </div>
            </div>`);
        }
    } else {
        wrap.classList.add('wrap-empty');
    }
}

//Modal
function createModal(arr) {
    document.body.insertAdjacentHTML('beforeend', '<div class="overlay"></div>');
    const overlay = document.querySelector('.overlay');
    overlay.innerHTML = `
    <div class="modal">
        <label>Id:<input value="${arr[0]}"></label>
        <label>Name:<input value="${arr[1]}"></label>
        <label>Category:<input value="${arr[2]}"></label>
        <div class="modal-radio">
            <label>
                <input type="radio" name="status" value="available">
                <span></span>Available
            </label>
            <label>
                <input type="radio" name="status" value="pending">
                <span></span>Pending
            </label>
            <label>
                <input type="radio" name="status" value="sold">
                <span></span>Sold
            </label>
        </div>
        <div class="modal-btn">
            <button>Confirm</button>
            <button>Cancel</button>
        </div>
    </div>`;

    document.querySelectorAll('input[type="radio"]').forEach((el => {
        if (el.value === arr[3]) {
            el.checked = true;
        }
    }));

    document.querySelectorAll('.modal-btn button')[1]
    .addEventListener('click', closeOverlay);
}

function closeOverlay() {
    document.querySelector('.overlay').remove();
}

//Other
function createBody() {
    const input = document.querySelectorAll('input');
    const checkedRadio = document.querySelector('input:checked');
    const data = {
        id: input[0].value,
        category: {
            id: 0,
            name: input[2].value
        },
        name: input[1].value,
        photoUrls: ['string'],
        tags: [{id: 0,name: 'string'}],
        status:  checkedRadio.value
    }
    return data;
}

function setStatus(status) {
    document.querySelector('.status-checked').className = '';
    for (let el of document.querySelectorAll('li')) {
        if (el.textContent.toLowerCase() === status) {
            el.className = 'status-checked';
            break;
        }
    }
}










// Код из практики
// Edit pet
// async function editPet(data) {
//     const res = await fetch('https://petstore.swagger.io/v2/pet', {
//         method: 'PUT',
//         headers: {
//             'Content-type': 'application/json'
//         },
//         body: JSON.stringify(data)
//     });

//     if (res.status === 200) {
//         closeOverlay();
//         getPets(data.status);
//         setStatus(data.status);
//     }
// }


// function setPets(data) {
//     document.querySelectorAll('.pet-btn').forEach((el, index) => {
//         el.addEventListener('click', (e) => {
//             if (e.target === el.children[0]) {
//                 const arr = [
//                     data[index].id,
//                     data[index].name,
//                     data[index].category.name,
//                     data[index].status,
//                 ];
//                 createModal(arr);

//                 document.querySelectorAll('.modal-btn button')[0]
//                 .addEventListener('click', () => {
//                     const data = createBody();
//                     editPet(data);
//                 });
//             } else {
//                 //Remove pet
//             }
//         });
//     });
// }