console.log('hello');
console.log('bye');



/*
Выполнение JavaScript-кода по умолчанию происходит синхронно (одновременно может выполняться только одна операция)

Если на выполнение действия требуется время (например, запрос на сервер), можно сделать запуск задачи асинхронно (выполняется в фоновом режиме и не блокирует другой код)


Типы асинхронного кода:
А. Асинхронные колбэки (устаревший способ)
B. Промисы


Промис (Promise)
объект (конструктор), представляет результат успешного или неуспешного выполнения асинхронной операции


Пример возврата данных с сервера:
function getPets() {
    const url = 'https://petstore.swagger.io/v2/pet/findByStatus?status=available';
    return fetch(url).then((res) => res.json());
}
getPets().then((data) => {
    console.log(data);
});


Пример возврата данных с сервера через асинхронную функцию:
getPets();
async function getPets() {
    const url = 'https://petstore.swagger.io/v2/pet/findByStatus?status=available';
    const res = await fetch(url);
    console.log(await res.json());
}
*/










// Код из лекции
// console.log('hello');
// function getPets() {
//     const url = 'https://petstore.swagger.io/v2/pet/findByStatus?status=available';
//     return fetch(url).then((res) => res.json());
// }
// getPets().then((data) => {
//     console.log(data);
// });
// console.log('bye');