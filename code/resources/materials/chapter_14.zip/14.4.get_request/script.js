//http://localhost/country
document.querySelector('form').addEventListener('submit', (e) => {
    e.preventDefault();
    const input = document.querySelector('input');
    if (input.value.length > 0) {
        
    }
});


function showCountry(data) {
    const wrap = document.querySelector('.wrap');
    wrap.innerHTML = '';
    wrap.className = 'wrap';

    if (data.length > 0) {
        for (let i = 0; i < data.length; i++) {
            wrap.insertAdjacentHTML('beforeend', `
            <div class="country">
                <b>${data[i].country}</b>
                <i>${data[i].capital}</i>
            </div>`);
        }
    } else {
        wrap.classList.add('wrap-empty');
    }
}










// Код из лекции
// document.querySelector('form').addEventListener('submit', (e) => {
//     e.preventDefault();
//     const input = document.querySelector('input');
//     if (input.value.length > 0) {
//         getCountry(input.value.trim());
//     }
// });

// async function getCountry(val) {
//     const res = await fetch(`http://localhost/country/api/get_country.php?country=${val}`);
//     const data = await res.json();
//     showCountry(data);
// }