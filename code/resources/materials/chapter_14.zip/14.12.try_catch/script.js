const country = {
    country: 'Spain',
    capital: 'Madrid',
    region: 'Europe'
}

addCountry(country);
async function addCountry(country) {
    const res = await fetch('http://localhost/country/api/add_country.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(country)
    });

    const data = await res.json();

    if (res.status === 201) {
        showAlert(data.message);
    } else {
        showAlert(data.error, 'error');
    }
}



/*
Конструкция try и catch
используется для обработки разных ошибок в коде

A. Если ошибка в try не обнаружена
выполняется весь код в блоке try, при этом catch игнорируется

B. Если ошибка в try обнаружена
выполнение кода в try останавливается и переходит в блок catch
try {
    const data = 'a';
    data = 'b';
} catch {
    console.log('Something went wrong')
}
=> Something went wrong


В блок catch можно добавить переменную, которая будет содержать объект ошибки с информацией о ней
try {
    const data = 'a';
    data = 'b';
} catch(err) {
    console.log(err);
}
=> 
TypeError: Assignment to constant variable.
at script.js:32:10


Блок finally (необязательный)
выполняется после блоков try и catch, независимо от того, возникли ли ошибки
try {
    const data = 'a';
    data = 'b';
} catch {
    console.log('Something went wrong');
} finally {
    console.log('Hello');
}
=> 
Something went wrong
Hello
*/










// Код из лекции
// async function addCountry(country) {
//     try {
//         const res = await fetch('http://localhost/country/api/add_country.php', {
//             method: 'POST',
//             headers: {
//                 'Content-Type': 'application/json'
//             },
//             body: JSON.stringify(country)
//         });

//         const data = await res.json();

//         if (res.status === 201) {
//             showAlert(data.message);
//         } else {
//             showAlert(data.error, 'error');
//         }
//     } catch (err) {
//         showAlert('Something went wrong', 'error');
//     } finally {
//         console.log('Finally');
//     }
//     console.log('Hello');
// }










function showAlert(text, err) {
    document.body.insertAdjacentHTML('beforeend', 
    `<div class="alert">
        <p>${text}</p>
        <button class="btn-close"></button>
    </div>`);

    const alert = document.querySelector('.alert');
    if (err) {
        alert.classList.add('alert-err');
    }
    document.querySelector('.btn-close').addEventListener('click', () => alert.remove());
}