//https://petstore.swagger.io/v2/pet/findByStatus
document.querySelectorAll('li').forEach((el) => {
    el.addEventListener('click', () => {
        document.querySelector('.status-checked').className = '';
        el.className = 'status-checked';
    });
});


function showPets(data) {
    const wrap = document.querySelector('.wrap');
    wrap.innerHTML = '';
    wrap.className = 'wrap';

    if (data.length > 0) {
        for (let i = 0; i < data.length; i++) {
            wrap.insertAdjacentHTML('beforeend', `
            <div class="pet">
                <b>${data[i].name}</b>
                <i>${data[i].category.name}</i>
                <div class="pet-btn">
                    <button></button>
                    <button></button>
                </div>
            </div>`);
        }
    } else {
        wrap.classList.add('wrap-empty');
    }
}










// Код из практики
// getPets('available');
// document.querySelectorAll('li').forEach((el) => {
//     el.addEventListener('click', () => {
//         document.querySelector('.status-checked').className = '';
//         el.className = 'status-checked';
//         getPets(el.textContent.toLowerCase().trim());
//     });
// });

// async function getPets(status) {
//     const res = await fetch(`https://petstore.swagger.io/v2/pet/findByStatus?status=${status}`);
//     const data = await res.json();
//     const filterData = data.filter((item) => String(item.id).includes('4223372036858'));
//     showPets(filterData);
// }