


//https://petstore.swagger.io/v2/pet/findByStatus?status=available
/*
Async/await
синтаксис для более удобного написания асинхронного кода


Ключевое слово async
превращает обычную функцию в асинхронную, которая всегда возвращает промис

Добавляется перед функцией
async function calculateData() {
    return 2 * 2;
}
console.log(calculateData());
=> Promise

Пример со стрелочной функцией:
const calculateData = async () =>  2 * 2;
console.log(calculateData());
=> Promise


Ключевое слово await
приостанавливает выполнение async-функции и ожидает ответа от промиса, после этого возобновляет работу функции

Важно: await работает только в асинхронных функциях


Метод fetch
позволяет получать ресурсы асинхронно и возвращает промис, который содержит Response-объект
const res = await fetch();

Параметры:
url – URL для отправки запроса;
options – объект из дополнительных параметров (метод, заголовки, тело запроса и т.д.);

Примеры свойств объекта Response:
A. status – код статуса (200, 422 и т.д.);
B. ok – если значение true, статус кода относится к группе 200;


Метод json
метод Response-объекта, позволяющий получить промис с телом ответа в JSON-формате, когда данные полностью загружены

getCountry();
async function getCountry() {
    const res = await fetch('http://localhost/all/country/api/get_country.php?region=australia');
    const data = await res.json();
    console.log(data);
}
=> 
[
    {country: 'Australia', capital: 'Kanberra', region: 'Australia
]
*/










// Код из лекции
// async function getPets() {
//     return 2 * 2;
// }
// console.log(getPets());

// getPets();
// async function getPets() {
//     const res = await fetch('https://petstore.swagger.io/v2/pet/findByStatus?status=pending');
//     const data = await res.json();
//     console.log(data);
// }