const country = {
    country: '1',
    capital: '1',
    region: 'Asia'
}

// editCountry(country);
async function editCountry(country) {
    const res = await fetch('http://localhost/country/api/edit_country.php', {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(country)
    });

    const data = await res.json();

    if (res.status === 200) {
        showAlert(data.message);
    } else {
        showAlert(data.error, 'error');
    }
}

// addCountry(country);
async function addCountry(country) {
    const res = await fetch('http://localhost/country/api/add_country.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(country)
    });

    const data = await res.json();

    if (res.status === 201) {
        showAlert(data.message);
    } else {
        showAlert(data.error, 'error');
    }
}

document.querySelector('form').addEventListener('submit', (e) => {
    e.preventDefault();
    const input = document.querySelector('input');
    if (input.value.length > 0) {
        getCountry(input.value.trim());
    }
});

async function getCountry(val) {
    const res = await fetch(`http://localhost/country/api/get_country.php?country=${val}`);
    const data = await res.json();
    showCountry(data);
}

function showCountry(data) {
    const wrap = document.querySelector('.wrap');
    wrap.innerHTML = '';
    wrap.className = 'wrap';

    if (data.length > 0) {
        for (let i = 0; i < data.length; i++) {
            wrap.insertAdjacentHTML('beforeend', `
            <div class="country">
                <b>${data[i].country}</b>
                <i>${data[i].capital}</i>
            </div>`);
        }
    } else {
        wrap.classList.add('wrap-empty');
    }
}

function showAlert(text, err) {
    document.body.insertAdjacentHTML('beforeend', 
    `<div class="alert">
        <p>${text}</p>
        <button class="btn-close"></button>
    </div>`);

    const alert = document.querySelector('.alert');
    if (err) {
        alert.classList.add('alert-err');
    }
    document.querySelector('.btn-close').addEventListener('click', () => alert.remove());
}










// Код из лекции
// removeCountry('1');
// async function removeCountry(country) {
//     const res = await fetch(`http://localhost/country/api/delete_country.php?country=${country}`, {
//         method: 'DELETE'
//     });

//     const data = await res.json();

//     if (res.status === 200) {
//         showAlert(data.message);
//     } else {
//         showAlert(data.error, 'error');
//     }
// }