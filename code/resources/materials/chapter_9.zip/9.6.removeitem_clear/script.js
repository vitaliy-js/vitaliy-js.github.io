const product = document.querySelectorAll('.product');
const btnMain = document.querySelector('.btn-main');
showProducts();

localStorage.setItem('star', 'Солнце');
localStorage.setItem('planet', 'Земля');

document.querySelectorAll('.remove-btn').forEach((el, index) => {
    el.addEventListener('click', () => {
        if (!checkProducts()) {
            removeAll();
        }
    });
});

function removeAll() {
    product.forEach((el) => el.style.display = 'none');
    btnMain.textContent = 'Показать товары';
}



/*
Метод removeItem
удаление данных по ключу в localStorage/sessionStorage

Формула:
localStorage.removeItem(ключ)

localStorage.removeItem('Любимое блюдо');
console.log(localStorage.getItem('Любимое блюдо'));
=> null


Метод clear
удаление всех данных в localStorage/sessionStorage

localStorage.clear();
console.log(localStorage.getItem('Любимое блюдо'));
console.log(localStorage.getItem('Язык программирования'));
=> null null
*/










// Код из лекции
// localStorage.removeItem('planet');
// localStorage.removeItem('star');

// localStorage.clear();

// document.querySelectorAll('.remove-btn').forEach((el, index) => {
//     el.addEventListener('click', () => {
//         product[index].style.display = 'none';

//         if (index === 0) {
//             localStorage.removeItem('tv');
//         } else if (index === 1) {
//             localStorage.removeItem('phone');
//         } else if (index === 2) {
//             localStorage.removeItem('fridge');
//         }

//         if (!checkProducts()) {
//             removeAll();
//         }
//     });
// });

// function removeAll() {
//     product.forEach((el) => el.style.display = 'none');
//     btnMain.textContent = 'Показать товары';
//     localStorage.clear();
// }










btnMain.addEventListener('click', () => {
    if (checkProducts()) {
        removeAll();
    } else {
        restoreAll();
    }
    showProducts();
});

function restoreAll() {
    localStorage.setItem('tv', 'available');
    localStorage.setItem('phone', 'available');
    localStorage.setItem('fridge', 'available');
    btnMain.textContent = 'Очистить всё';
}

function showProducts() {
    if (!checkProducts()) {
        btnMain.textContent = 'Показать товары';
    }

    for(let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key === 'tv') {
            product[0].style.display = 'flex';
        } else if (key === 'phone') {
            product[1].style.display = 'flex';
        } else if (key === 'fridge') {
            product[2].style.display = 'flex';
        }
    }
}

function checkProducts() {
    if (!localStorage.getItem('tv') &&
    !localStorage.getItem('phone') &&
    !localStorage.getItem('fridge')) {
        return false;
    } else {
        return true
    }
}