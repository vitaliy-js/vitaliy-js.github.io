const showName = () => {
    const userName = document.querySelector('b');
}
document.querySelector('form').addEventListener('submit', (e) => {
    e.preventDefault();
    const input = document.querySelector('input');

    if (input.value.length > 0) {

    }
});

showName();



/*
Метод setItem
сохранение/обновление данных в localStorage/sessionStorage

Формула:
localStorage.setItem(ключ, значение)

Создание:
localStorage.setItem('Любимое блюдо', 'Жареная картошка');

Обновление существующего значения:
localStorage.setItem('Любимое блюдо', 'Жареная картошка с луком');


Метод getItem
извлечение данных по ключу в localStorage/sessionStorage

Формула:
localStorage.getItem(ключ)

console.log(localStorage.getItem('Любимое блюдо'));
=> Жареная картошка с луком


Если ключ не найден, возвращается значение null
console.log(localStorage.getItem('Любимый напиток'));
=> null
*/










// Код из лекции
// localStorage.setItem('Язык программирования', 'JavaScript');
// localStorage.setItem('Язык программирования', 'PHP');

// console.log(localStorage.getItem('Язык программирования'));

// const showName = () => {
//     const userName = document.querySelector('b');

//     if (localStorage.getItem('Имя пользователя')) {
//         userName.textContent = `Привет, ${localStorage.getItem('Имя пользователя')}`;
//     } else {
//         userName.textContent = 'Привет!'
//     }
// }
// document.querySelector('form').addEventListener('submit', (e) => {
//     e.preventDefault();
//     const input = document.querySelector('input');

//     if (input.value.length > 0) {
//         localStorage.setItem('Имя пользователя', input.value);
//         showName();
//     }
// });