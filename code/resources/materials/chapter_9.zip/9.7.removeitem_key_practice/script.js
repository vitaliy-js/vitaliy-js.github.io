// Купить корм коту  Полить цветы  Пойти в спортзал
const taskWrap = document.querySelector('.task-wrap');
removeTask();

document.querySelector('form').addEventListener('submit', (e) => {
    e.preventDefault();
    const input = document.querySelector('input');
    if (input.value.length > 0) {
        addTask(input.value);
    }
});

function addTask(text) {
    taskWrap.insertAdjacentHTML('beforeend', `
    <div class="task">
        <p>${text}</p>
        <button class="remove-btn"></button>
    </div>`);
}

function removeTask() {
    taskWrap.addEventListener('click', (e) => {
        if (e.target.classList.contains('remove-btn')) {
            e.target.parentElement.remove();
        }
    });
}

















// Код из практики
// const taskWrap = document.querySelector('.task-wrap');
// removeTask();

// for (let i = 0; i < localStorage.length; i++) {
//     const key = localStorage.key(i);
//     if (key.includes('task-')) {
//         showTasks(key, localStorage.getItem(key));
//     }
// }

// document.querySelector('form').addEventListener('submit', (e) => {
//     e.preventDefault();
//     const input = document.querySelector('input');
//     if (input.value.length > 0) {
//         addTask(input.value);
//     }
// });

// function addTask(text) {
//     const taskId = `task-${Math.floor(Math.random() * 1000 + 1)}`;
//     showTasks(taskId, text);
//     localStorage.setItem(taskId, text);
// }

// function showTasks(taskId, text) {
//     taskWrap.insertAdjacentHTML('beforeend', `
//     <div class="task" id="${taskId}">
//         <p>${text}</p>
//         <button class="remove-btn"></button>
//     </div>`);
// }

// function removeTask() {
//     taskWrap.addEventListener('click', (e) => {
//         if (e.target.classList.contains('remove-btn')) {
//             localStorage.removeItem(e.target.parentElement.id);
//             e.target.parentElement.remove();
//         }
//     });
// }