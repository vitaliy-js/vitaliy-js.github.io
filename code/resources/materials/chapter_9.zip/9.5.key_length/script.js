localStorage.setItem('bond-1999', 'И целого мира мало');
localStorage.setItem('bond-2006', 'Квант милосердия');
localStorage.setItem('bond-2015', 'Спектр');



/*
Метод key
извлечение ключей по индексу (отсчёт идёт с ноля)

localStorage.setItem('planet-1', 'Меркурий');
localStorage.setItem('planet-2', 'Венера');
localStorage.setItem('planet-3', 'Земля');

console.log(localStorage.key(0));    =>  planet-1


Свойство length
возвращает количество элементов в localStorage/sessionStorage
console.log(localStorage.length);    =>  3


Метод key часто используется в связке с циклом
for (let i = 0; i < localStorage.length; i++) {
	const key = localStorage.key(i);
	console.log(key);   
}
=>  planet-1, planet-2, planet-3
*/










// Код из лекции
// console.log(localStorage.key(0));
// console.log(localStorage.length);

// for (let i = 0; i < localStorage.length; i++) {
// 	const key = localStorage.key(i);
	
// 	if (key.includes('2006')) {
// 		console.log(localStorage.getItem(key));
// 	}
// }