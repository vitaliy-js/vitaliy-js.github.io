document.cookie = 'planet=earth; path=/; expires=Fri, 31 Dec 2029 23:59:59 GMT; SameSite=Lax; Secure';



/*
Куки (cookies)
позволяют хранить данные в браузере (формат ключ=значение)


document.cookie
свойство, которое позволяет прочитать и установить cookies

document.cookie = 'lang=eng; path=/; expires=Fri, 31 Dec 2029 23:59:59 GMT; SameSite=Lax; Secure';
console.log(document.cookie);
=> lang=eng


Могут использоваться на серверной и клиентской части, так как являются частью HTTP-протокола


Куки имеют ограниченный срок хранения, который можно задать при их создании. Эта информация хранится в ключе expires

Если в ключе expires указана прошедшая дата, куки будут удалены
*/










// Код из лекции
// console.log(document.cookie);

// console.log(document.cookie.split('='));
// console.log(document.cookie.split('=')[1]);

// document.cookie = 'star=sun; path=/; expires=Fri, 31 Dec 2029 23:59:59 GMT; SameSite=Lax; Secure';
// console.log(document.cookie.split('; ')[1]);

// document.cookie = 'planet=mars; path=/; expires=Fri, 31 Dec 2019 23:59:59 GMT; SameSite=Lax; Secure';