const title = ['Sights', 'Достопримечательности'];
const sights = [
    ['Big Ben', 'Биг-Бен'],
    ['Statue of Liberty', 'Статуя Свободы']
];

document.querySelector('ul').addEventListener('click', (e) => {
	
});
















// Код из практики
// if (localStorage.getItem('lang') === 'ru') {
// 	showContent(1);
// } else {
// 	showContent(0);
// }

// document.querySelector('ul').addEventListener('click', (e) => {
// 	if (e.target.textContent === 'Eng') {
// 		localStorage.setItem('lang', 'eng');
// 		showContent(0);
// 	} else {
// 		localStorage.setItem('lang', 'ru');
// 		showContent(1);
// 	}
// });

// function showContent(index) {
// 	document.querySelector('h2').textContent = title[index];

// 	for (let i = 0; i < sights.length; i++) {
// 		document.querySelectorAll('b')[i].textContent = sights[i][index];
// 	}

// 	document.querySelector('.lang-selected').className = '';
// 	document.querySelectorAll('li')[index].className = 'lang-selected';
// }