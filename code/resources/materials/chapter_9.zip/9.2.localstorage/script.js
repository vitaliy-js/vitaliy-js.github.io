document.querySelector('img').addEventListener('click', () => {
	localStorage.setItem('user', 'Здесь был Вася');
	console.log(localStorage.getItem('user'));
});



/*
localStorage и sessionStorage
возможность хранить данные в формате «ключ-значение» в браузере без отправки их на сервер

Данные хранятся в виде строки и привязаны к домену. Для каждого сайта подтягиваются "свои" ранее сохранённые данные


Свойство localStorage
хранение данных в браузере, которые не имеют ограничений по времени


Свойство sessionStorage
хранение данных в браузере в течение сессии (до закрытия текущей вкладки). При перезагрузке страницы данные сохраняются

Используются те же методы, что и в localStorage, отличие только в названии
localStorage.getItem('user')     => localStorage
sessionStorage.getItem('user')   => sessionStorage
*/










// Код из лекции
// document.querySelector('img').addEventListener('click', () => {
// 	localStorage.setItem('user', 'Здесь был Вася');
// 	console.log(localStorage.getItem('user'));
// });

// document.querySelector('img').addEventListener('click', () => {
// 	sessionStorage.setItem('user', 'Здесь был Вася');
// 	console.log(sessionStorage.getItem('user'));
// });