const foodArr = ['apple', 'pear', 'banana', 'watermelon'];
const fridge = document.querySelector('ul');
const li = document.querySelectorAll('li');

for (let i = 0; i < foodArr.length; i++) {
    console.log(foodArr[i]);
}



/*
Цикл for of
позволяет перебрать все значения в массиве без доступа к индексам

Формула:
for (let value of массив) {
    тело цикла;
}

const color = ['pink', 'red', 'gold'];
for (let value of color) {
    console.log(value);
}
=>   pink, red, gold


В этом цикле также можно использовать операторы break и continue:
for (let value of color) {
    if (value === 'red') {
        continue;
    }
    console.log(value);
}
=>   pink, gold


Д.З.
Используя код из лекции, замените обычный цикл for на for...of и выполните следующие задачи:
1. Показать все продукты из foodArr: 'apple', 'pear', 'banana', 'watermelon';
---------------
2. Показать следующие продуты: 'apple', 'pear', 'watermelon';
---------------
3. Показать следующие продуты: 'apple', 'pear';

Цикл for:
for (let i = 0; i < foodArr.length; i++) {
    const product = 
    `<li style="background-image: url(img/${foodArr[i]}.svg);"></li>`;
    fridge.insertAdjacentHTML('beforeend', product);
}
*/










// Код из лекции
// for (let value of li) {
//     console.log(value);
// }

// for (let value of foodArr) {
//     if (value === 'pear') {
//         break;
//     }
//     console.log(value);
// }

// for (let value of li) {
//     console.log(value);
//     value.style.color = 'blue';
// }










/*
Решение Д.З. (способы решения могут отличаться)
1. 
for (let value of foodArr) {
    const product = 
    `<li style="background-image: url(img/${value}.svg);"></li>`;
    fridge.insertAdjacentHTML('beforeend', product);
}
---------------
2. 
for (let value of foodArr) {
    const product = 
    `<li style="background-image: url(img/${value}.svg);"></li>`;

    if (value === 'banana') {
        continue;
    }
    fridge.insertAdjacentHTML('beforeend', product);
}
---------------
3.
for (let value of foodArr) {
    const product = 
    `<li style="background-image: url(img/${value}.svg);"></li>`;
    fridge.insertAdjacentHTML('beforeend', product);
    
    if (value === 'pear') {
        break;
    }
}
*/