const ul = document.querySelector('ul');
const turtles = [
    ['Леонардо', 'leo.svg'],
    ['Донателло', 'don.svg'],
    ['Микеланджело', 'mikey.svg'],
    ['Рафаэль', 'raph.svg']
];



//`<li>${}<img src="img/${}"></li>`
/*
Многомерный массив
массив, элементы которого являются массивами
const cars = [
    ['BMW', 'Германия'],
    ['Toyota', 'Япония'],
    ['Jaguar', 'Великобритания'],
];
console.log(cars[1]);
=> ['Toyota', 'Япония']


Чтобы получить доступ к элементу массива в массиве, используют 2 индекса:
console.log(cars[1][0]);
=> Toyota


Многомерный массивы также часто используют в циклах
for (let i = 0; i < cars.length; i++) {
    console.log(cars[i][0]);
}
=> BMW, Toyota, Jaguar


Пример трёхмерного массива
const turtles = [
    [['Леонардо', 'Leo'], 'leo.svg'],
    [['Донателло', 'Don'], 'don.svg'],
    [['Микеланджело', 'Mikey'], 'mikey.svg'],
    [['Рафаэль', 'Raph'], 'raph.svg']
];
console.log(turtles[0][0][1]);
=> Leo


Д.З
Используя код из лекции, замените обычный цикл for на for...of:
for (let i = 0; i < turtles.length; i++) {
    ul.innerHTML += `
    <li>${turtles[i][0]}<img src="img/${turtles[i][1]}"></li>`;
}
*/










// Код из лекции
// console.log(turtles[2][0]);

// for (let i = 0; i < turtles.length; i++) {
//     ul.innerHTML += `
//     <li>${turtles[i][0]}<img src="img/${turtles[i][1]}"></li>`;
// }










/*
Решение Д.З. (способы решения могут отличаться)
for (let value of turtles) {
    ul.innerHTML += 
    `<li>${value[0]}<img src="img/${value[1]}"></li>`;
}
*/