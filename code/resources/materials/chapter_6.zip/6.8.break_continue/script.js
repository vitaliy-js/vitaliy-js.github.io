const color = ['pink', 'red', 'orange', 'blue', 'gold', 'purple'];

for (let i = 0; i < color.length; i++) {
    addBox(color[i]);
}

function addBox(bgColor) {
    const colorWrap = document.querySelector('ul');
    const colorBox = `<li style="background-color:${bgColor};"></li>`;
    colorWrap.insertAdjacentHTML('beforeend', colorBox);
}



/*
Оператор break
полностью прерывает выполнение цикла

const fruit = ['апельсин', 'яблоко', 'груша'];
for (let i = 0; i < fruit.length; i++) {
    if (fruit[i] === 'яблоко') {
        break;
    }
    console.log(fruit[i]);
}
=> апельсин


Оператор continue
прерывает выполнение текущей итерации и сразу переходит к следующей

for (let i = 0; i < fruit.length; i++) {
    if (fruit[i] === 'яблоко') {
        continue;
    }
    console.log(fruit[i]);
}
=> апельсин, груша  


Эти операторы обычно используют в условных выражениях (if)


Д.З.
Используя код из лекции, напишите инструкцию if так, чтобы цвета были расположены в следующем порядке:
1. 'pink', 'red', 'orange', 'blue', 'gold'
---------------------
2. 'pink', 'orange', 'blue', 'gold', 'purple'
---------------------
3. 'pink', 'blue', 'gold', 'purple'
*/










// Код из лекции
// for (let i = 0; i < color.length; i++) {
//     // if (color[i] === 'orange') {
//     //     break;
//     // }

//     if (color[i] === 'orange') {
//         continue;
//     }

//     addBox(color[i]);
// }










/*
Решение Д.З. (способы решения могут отличаться)
1.  
    if (color[i] === 'purple') {
        break;
    }
---------------------
2. 
    if (color[i] === 'red') {
        continue;
    }
---------------------
3. 
    if (color[i] === 'red' ||
        color[i] === 'orange') {
        continue;
    }
*/