const toDoList = ['Помыть кота', 'Сделать уборку', 'Купить хлеб', 'Полить цветы', 'Учить JavaScript'];
























// Код из практики
// const listItem = document.querySelectorAll('li');

// for (let i = 0; i < listItem.length; i++) {
//     listItem[i].textContent = toDoList[i];
// }