document.querySelector('form').addEventListener('submit', (e) => {
    e.preventDefault();
    const input = document.querySelector('input');

    if (input.value.length > 0) {
        
    }
});

















// Код из практики
// document.querySelector('form').addEventListener('submit', (e) => {
//     e.preventDefault();
//     const input = document.querySelector('input');

//     if (input.value.length > 0) {
//         addRabbit(+input.value);
//     }
// });

// function addRabbit(counter) {
//     const continent = document.querySelector('.continent');
//     const rabbit = `
//     <div class="rabbit-box">
//         <div class="rabbit"></div>
//     </div>`;

//     for (let i = 0; i < counter; i++) {
//         //continent.insertAdjacentHTML('beforeend', rabbit);
//         continent.innerHTML += rabbit;
//     }
// }