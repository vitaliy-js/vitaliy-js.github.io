const color = ['pink', 'red', 'orange', 'blue', 'gold', 'purple'];



function addBox(bgColor) {
    const colorWrap = document.querySelector('ul');
    const colorBox = `<li style="background-color:${bgColor};"></li>`;
    colorWrap.insertAdjacentHTML('beforeend', colorBox);
}



/*
Цикл for в JavaScript часто используется для работы с массивами

Для того чтобы перебрать все элементы массива с использованием инкремента, нужно выполнить следующее:
- Начальный шаг: i = 0
- Условие: i < массив.length

const fruit = ['апельсин', 'яблоко', 'груша'];
for (let i = 0; i < fruit.length; i++) {
    console.log(fruit[i]);
}
=> апельсин, яблоко, груша


В теле цикла можно добавлять различные конструкции: функции, условные выражения (if), и т.д.
const fruit = ['апельсин', 'яблоко', 'груша'];
for (let i = 0; i < fruit.length; i++) {
    if (fruit[i] === 'апельсин') {
        console.log(fruit[i]);
    }
}
=> апельсин


Д.З.
const planets = ['Венера', 'Земля', 'Марс', 'Юпитер', 'Сатурн', 'Уран', 'Нептун', 'Плутон'];
Выведите в консоль все планеты из константы planets, кроме 'Плутон'
*/










// Код из лекции
// for (let i = 0; i < color.length; i++) {
//     console.log(color[i]);
// }

// for (let i = 0; i < color.length; i++) {
//     //addBox(color[i]);

//     if (color[i] !== 'red') {
//         addBox(color[i]);
//     }
// }










/*
Решение Д.З. (способы решения могут отличаться)
const planets = ['Венера', 'Земля', 'Марс', 'Юпитер', 'Сатурн', 'Уран', 'Нептун', 'Плутон'];
for (let i = 0; i < planets.length; i++) {
    if (planets[i] !== 'Плутон') {
        console.log(planets[i]);
    }
}
=> Венера, Земля, Марс, Юпитер, Сатурн, Уран, Нептун
*/