const foodArr = ['apple', 'pear', 'banana', 'watermelon'];
const fridge = document.querySelector('ul');



// `url(img/${foodArr[i]}.svg)`
/*
Метод querySelectorAll
возвращает все элементы по указанному CSS-селектору
const items = document.querySelectorAll('li');
console.log(items);
=> [li, li, li, li]


querySelector vs querySelectorAll
querySelector - возвращает первый найденный элемент
querySelectorAll - возвращает коллекцию всех найденных элементов


querySelectorAll имеет некоторые общие черты с массивом:
* индекс - предоставляет доступ к любому элементу коллекции
* свойство length - количество элементов внутри коллекции

console.log(items[2]);
=> <li style="background-image: url(img/banana.svg);"></li>

console.log(items.length);
=> 4


Данный метод часто используется в циклах:
const items = document.querySelectorAll('li');
for (let i = 0; i < items.length; i++) {
    items[i].style.display = 'none';
}
*/










// Код из лекции
// const food = document.querySelectorAll('li');
// console.log(food);
// console.log(food[3]);
// console.log(food.length);

// for (let i = 0; i < food.length; i++) {
//     food[i].style.backgroundImage = `url(img/${foodArr[i]}.svg)`;
// }