document.querySelector('form').addEventListener('submit', (e) => {
    e.preventDefault();
    const input = document.querySelector('input');

    if (input.value.length > 0) {

    }
});



// 'tiger', 'wolf', 'horse'
// `img/${}.svg`












// Код из практики
// document.querySelector('form').addEventListener('submit', (e) => {
//     e.preventDefault();
//     const input = document.querySelector('input');

//     if (input.value.length > 0) {
//         searchAnimal(input.value);
//     }
// });

// function searchAnimal(animal) {
//     const animalArr = ['tiger', 'wolf', 'horse'];

//     for (let i = 0; i < animalArr.length; i++) {
//         if (animalArr[i] === animal) {
//             addAnimal(animal);
//             break;
//         }

//         if (animalArr.lenth - 1 !== animal) {
//             addAnimal('other');
//         }
//     }
// }

// function addAnimal(animal) {
//     const animalName = document.querySelector('b');
//     document.querySelector('img').src = `img/${animal}.svg`;

//     if (animal !== 'other') {
//         animalName.textContent = animal;
//     } else {
//         animalName.textContent = 'Нет данных';
//     }
// }