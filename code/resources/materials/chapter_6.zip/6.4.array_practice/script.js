const color = ['pink'];












function changeColorPoster() {
    const hero = document.querySelector('.hero');

    document.querySelectorAll('li').forEach((el, index) => {
        el.addEventListener('click', () => {
            
        });
    });
}



// Код из практики
// const color = ['pink'];

// document.querySelector('form').addEventListener('submit', (e) => {
//     e.preventDefault();
//     const input = document.querySelector('input');

//     if (input.value.length > 0) {
//         addColor(input.value);
//         input.value = '';
//     }
// });

// function addColor(newColor) {
//     const colorWrap = document.querySelector('.color');
//     color[color.length] = newColor;

//     colorWrap.insertAdjacentHTML('beforeend', '<li></li>');
//     colorWrap.lastElementChild.style.backgroundColor = newColor;
//     changeColorPoster();
// }

// function changeColorPoster() {
//     const hero = document.querySelector('.hero');

//     document.querySelectorAll('li').forEach((el, index) => {
//         el.addEventListener('click', () => {
//             hero.style.backgroundColor = color[index];
//         });
//     });
// }