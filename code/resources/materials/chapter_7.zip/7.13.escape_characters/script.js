


//'I don't know'
/*
Экранирование кавычек
Если внутри строки добавить кавычки, которые используются для создания строкового значения, JavaScript выдаст ошибку
const best = 'You're simply the best';
=> Uncaught SyntaxError: Unexpected identifier 're'


Решения:
1. Комбинировать кавычки
const best = "You're simply the best";
const best = `You're simply the best`;
=> You're simply the best

2. Использовать обратный слеш
const best = 'You\'re simply the best';
=> You're simply the best


Обратный слеш может использоваться и для экранирования других символов
const best = 'The\\best';
=> The\best
*/










// Код из лекции
// const english = "I don't know";
// const english = `I don't know`;
// const english = 'I don\'t know';
// const english = 'I don\\t know';
// console.log(english);