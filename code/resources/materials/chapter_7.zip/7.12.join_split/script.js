const trash = ['велосипед', 'непишущая ручка', 'CD-диски'];
const str = 'велосипед,непишущая ручка,CD-диски';
const photo = 'earth.png';
const country = 'ice + land = Iceland';



/*
Метод join
объединяет элементы массива в строку
const fruit = ['апельсин', 'яблоко', 'груша'];
console.log(fruit.join());
=>  апельсин,яблоко,груша


По умолчанию разделение элементов массива происходит через запятую
Но разделитель можно переопределить, указав в виде параметра
const fruit = ['апельсин', 'яблоко', 'груша'];
console.log(fruit.join(' + '));
=>  апельсин + яблоко + груша


Метод split
разбивает строку на массив по указанному разделителю
const fruit = 'апельсин,яблоко,груша';
console.log(fruit.split(','));
=>  ['апельсин', 'яблоко', 'груша']


Для ограничения элементов массива можно добавить второй параметр - limit
console.log(fruit.split(',', 2));
=>  ['апельсин', 'яблоко']


Д.З.
Вернуться к предыдущему Д.З. и найти значение id (в функции getId) с помощью метода split
*/










// Код из лекции
// console.log(trash.join());
// console.log(trash.join('+'));
// console.log(str.split(','));
// console.log(photo.split('.')[1]);
// console.log(country.split('=')[1].trim());
// console.log(str.split(',', 2));










/*
Решение Д.З. (способы решения могут отличаться)
function getId() {
    const url = window.location.href;
    const profileId = url.split('=')[1];
    createCharacter(profileId - 1);
}
*/