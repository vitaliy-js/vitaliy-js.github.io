const hello = 'Привет, JavaScript';
const js = 'JavaScript';



/*
Метод indexOf
возвращает индекс, с которого начинается указанное значение (подстроки) в строке
const hi = 'Привет, JavaScript';
console.log(hi.indexOf('a', 8));
=> 8


В методе indexOf есть второй параметр, который позволяет осуществлять поиск индекса с определённой позиции
console.log(hi.indexOf('a', 10));
=> 11


Метод lastIndexOf
Работает по аналогии с indexOf, только поиск ведётся с конца строки
const hi = 'Привет, JavaScript';
console.log(hi.lastIndexOf('a'));
=> 11


Если искомое значение в строке не найдено, JavaScript возвращает -1
console.log(hi.indexOf('D'));
=> -1
*/










// Код из лекции
// console.log(hello.indexOf('JavaScript'));
// console.log(js.indexOf('a'));
// console.log(js.indexOf('a', 2));

//console.log(js.indexOf('b'));

//console.log(js.lastIndexOf('a'));
//console.log(js.lastIndexOf('a', 2));