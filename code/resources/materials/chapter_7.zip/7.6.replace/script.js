const upperCaseVal = val => val.toUpperCase();
const banner = document.querySelector('p');
const phrase = 'Каждый охотник желает знать, где сидит фазан';



/*
Метод replace
замена одного указанного значения (подстроки) в строке

Формула:
строка.replace(старое, новое);

const poem = 'Солнце светит';
console.log(poem.replace('Солнце', 'Луна'));
=> Луна светит


В новом значении можно использовать константу/переменную, функцию и т.д.
const getLight = (text) => text; 
const poem = 'Солнце светит';
console.log(poem.replace('Солнце', getLight('Лампа')));
=> Лампа светит


Метод replaceAll
замена всех указанных значений в строке
const poem = 'Солнце светит, Солнце греет';
console.log(poem.replaceAll('Солнце', 'лампа'));
=> лампа светит, лампа греет


Д.З.
1. Сделайте так, чтобы часы (let clock = '23-59') показывали '23:59'
--------------
2. Измените формат телефона с 555 55 55 на 5555555
--------------
3. Сделайте замену гусей на индюков в песне
let song = `
Жили у бабуси два веселых гуся,
Один - серый, другой - белый,
Два веселых гуся`;
*/










// Код из лекции
// banner.textContent = phrase.replace('охотник', 'койот');
// banner.textContent = phrase.replace(',', ' - ');

// banner.textContent = phrase.replace('охотник', upperCaseVal('охотник'));

// banner.textContent = phrase.replace(' ', '');
// banner.textContent = phrase.replaceAll(' ', '');










/*
Решение Д.З. (способы решения могут отличаться)
1. 
let clock = '23-59';
clock = clock.replace('-', ':');
console.log(clock);
--------------
2. 
let tel = '555 55 55';
tel = tel.replaceAll(' ', '');
console.log(tel);
--------------
3.
let song = `
Жили у бабуси два веселых гуся,
Один - серый, другой - белый,
Два веселых гуся`;
song = song.replaceAll('гуся', 'индюка');
console.log(song);
*/