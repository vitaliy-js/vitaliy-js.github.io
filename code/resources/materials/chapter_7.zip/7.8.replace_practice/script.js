const badWord = 'редиска';

document.querySelector('button').addEventListener('click', (e) => {
    e.preventDefault();
    const comment = document.querySelector('textarea');

    if (comment.value.length > 0) {

    }
});



//Привет, редиска, Как дела, редиска, Ты редиска, редиска

// if (comment.toLowerCase().includes(badWord)) {
//     const regEx = new RegExp(badWord, 'ig');
//     comment = comment.replaceAll(regEx, '***');
// }






// Код из практики
// document.querySelector('button').addEventListener('click', (e) => {
//     e.preventDefault();
//     const comment = document.querySelector('textarea');

//     if (comment.value.length > 0) {
//         sendComment(comment.value.trim());
//         comment.value = '';
//     }
// });

// function sendComment(comment) {
//     const chatWrap = document.querySelector('.chat-wrap');

//     if (comment.includes(badWord)) {
//         comment = comment.replaceAll(badWord, '***');
//     }

//     chatWrap.insertAdjacentHTML('beforeend', `
//         <div class="chat">
//             <div class="avatar"></div>
//             <p>${comment}</p>
//         </div>`);
// }