const str = 'JavaScript';
let num = 18;



/*
Работа со строками (string)
текстовые данные, которые могут содержать буквы, цифры, символы


Строковые данные прописываются внутри кавычек:
1. Одинарные: 'hello'
2. Двойные: "hello"
3. Обратные: `hello`


Оператор typeof
позволяет определять тип данных
console.log(typeof 'Hello');  =>  string


Функция String
преобразование значения в строку
let val = true;
console.log(typeof val);     => boolean

val = String(val);
console.log(typeof val);     => string


Свойство length
позволяет посчитать количество символов внутри строки
const person = 'John';
console.log(person.length);   => 4


Доступ к отдельным символам
1. Используются квадратные скобки (как в массивах)
2. Отсчёт идёт с 0-го индекса
const person = 'John';
console.log(person[0]);       => J
console.log(person[3]);       => n


Д.З.
Выполните следующие задания:
1. Преобразуйте в строку: const val = undefined;
-----------------
2. Посчитайте количество символов в фразе "You are the best"
-----------------
3. Какому символу принадлежит индекс 8 в фразе "I love JavaScript"
*/










// Код из лекции
// console.log(typeof 18);
// console.log(typeof str);
// console.log(typeof true);

// console.log(typeof String(num));
// console.log(str.length);
// console.log(str[0]);










/*
Решение Д.З. (способы решения могут отличаться)
1. 
const val = undefined;
console.log(typeof String(val));
=>  string
-----------------
2. 
const text = 'You are the best';
console.log(text.length);
=>  16
-----------------
3.
const text = 'I love JavaScript';
console.log(text[8]);
=>  a
*/