const words = [
    ['lamp', 'лампа'],
    ['table', 'стол'],
    ['chair', 'стул']
];
let counter = 0;
let correct = 0;


















// Код из практики
// createWord();

// function createWord() {
//     const wordWrap = document.querySelector('div');
//     wordWrap.innerHTML = `
//         <i>${counter + 1} / ${words.length}</i>
//         <img src="img/${words[counter][0]}.svg">
//         <b>${words[counter][1]}</b>`;
//     wordWrap.className = '';
// }

// document.querySelector('form').addEventListener('submit', (e) => {
//     const input = document.querySelector('input');
//     const btn = document.querySelector('button');
//     e.preventDefault();

//     if (counter === words.length) {
//         alert(`Количество правильных слов: ${correct}`);
//         return;
//     }
    
//     if (btn.classList.contains('check-btn')) {
//         checkWord(input.value.toLowerCase().trim());
//         btn.textContent = 'Далее';
//         btn.classList.remove('check-btn');
//         counter++;
//     } else {
//         btn.textContent = 'Проверить';
//         btn.classList.add('check-btn');
//         input.value = '';
//         createWord();
//     }
// });

// function checkWord(word) {
//     const wordWrap = document.querySelector('div');

//     if (words[counter][0] === word) {
//         wordWrap.classList.add('correct');
//         correct++;
//     } else {
//         wordWrap.classList.add('incorrect');
//     }
// }