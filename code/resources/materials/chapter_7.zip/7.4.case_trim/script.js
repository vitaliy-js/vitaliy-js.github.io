const backDefault = banner => {
    banner.textContent = 'Здесь может быть Ваше слово';
}

document.querySelector('input').addEventListener('input', (e) => {
    const banner = document.querySelector('b');

    
    if (e.target.value.length === 0) {
        backDefault(banner);
    }
});



/*
Методы по смене регистра
toLowerCase() - преобразование в нижний регистр
toUpperCase() - преобразование в верхний регистр

Формула для метода строк:
строка.метод();

const str = 'Hello';
console.log(str.toLowerCase());   => hello
console.log(str.toUpperCase());   => HELLO


Метод trim
удаление пробельных символов с начала и конца строки
const email = ' test@test.com ';
console.log(email.trim());        => test@test.com


Д.З.
1. Напишите фразу 'Меня зовут Вася' в верхнем регистре
----------------
2. Преобразуйте в нижний регистр и удалите лишние пробелы для ' js@test.com '
*/










// Код из лекции
// banner.textContent = e.target.value.toLowerCase();
// banner.textContent = e.target.value.toUpperCase();
// banner.textContent = e.target.value.trim();
// banner.textContent = e.target.value.trim().toLowerCase();










/*
Решение Д.З. (способы решения могут отличаться)
1. 
console.log('Меня зовут Вася'.toUpperCase());
=>  МЕНЯ ЗОВУТ ВАСЯ
----------------
2. 
console.log(' js@test.com '.toLowerCase().trim());
=>  js@test.com
*/