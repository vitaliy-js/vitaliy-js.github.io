const btn = document.querySelector('button');

document.querySelector('form').addEventListener('input', () => {
    const banner = document.querySelector('p');
    const text = document.querySelector('textarea');
    const input = document.querySelectorAll('input');

});

const phrase = 'JavaScript';



/*
Метод substring
позволяет получить часть строки между указанными индексами

Нужно указать индекс, с которого начинается искомая подстрока
(если второй параметр не указан, возвращается значение до конца строки)
const phrase = 'My name is Vasya';
console.log(phrase.substring(3));
=> name is Vasya


Можно использовать второй (необязательный) параметр, который извлекает подстроку до данного индекса (не включая его)
console.log(phrase.substring(3, 5));
=> na     (получили символы 3 и 4 индекса)

Индексы можно указывать в разном порядке
console.log(phrase.substring(5, 3));
=> na    


Метод slice
работает также, как и метод substring
const phrase = 'My name is Vasya';
console.log(phrase.slice(3));
=> name is Vasya
console.log(phrase.slice(3, 5));
=> na  


В slice недоступен обратный порядок индексов (когда первый индекс больше второго)
console.log(phrase.slice(5, 3));
=>    пустая строка  


В параметрах могут использоваться отрицательные значения, которые рассчитываются по формуле:
index = str.length - index

console.log(phrase.slice(-5));
=>    Vasya


Д.З.
1. С помощью метода substring выведете в консоль 'хорошо жить — ещё лучше' из фразы 'Жить хорошо, а хорошо жить — ещё лучше'
---------------
2. Используя метод substring/slice, создайте строку со значением 'Дейл' в фразе 'Чип и Дейл спешат на помощь'
---------------
3. С помощью метода slice покажите в консоли расширение файла style.css
*/

btn.addEventListener('click', () => {
    if (btn.className === 'toggle-right') {
        btn.nextElementSibling.disabled = true;
        btn.className = 'toggle-left';
    } else {
        btn.nextElementSibling.disabled = false;
        btn.className = 'toggle-right';
    }
});










// Код из лекции
// console.log(phrase.substring(4));
// console.log(phrase.substring(0, 4));

// if (btn.className !== 'toggle-right') {
//     banner.textContent = text.value.substring(input[0].value);
// } else {
//     banner.textContent = text.value
//         .substring(input[0].value, input[1].value);
// }

// if (btn.className !== 'toggle-right') {
//     banner.textContent = text.value.slice(input[0].value);
// } else {
//     banner.textContent = text.value
//         .slice(input[0].value, input[1].value);
// }










/*
Решение Д.З. (способы решения могут отличаться)
1. 
const phrase = 'Жить хорошо, а хорошо жить — ещё лучше';
console.log(phrase.substring(15));
=> хорошо жить — ещё лучше
---------------
2. 
const phrase = 'Чип и Дейл спешат на помощь';
const character = phrase.slice(6, 10);
console.log(character);
=> Дейл
---------------
3.
console.log('style.css'.slice(-3));
=> css
*/