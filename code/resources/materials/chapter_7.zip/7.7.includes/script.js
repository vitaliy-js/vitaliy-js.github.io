const banner = document.querySelector('p');
const img = document.querySelectorAll('img');
const phrase = 'Каждый охотник желает знать, где сидит фазан';


document.querySelector('form').addEventListener('change', (e) => {
    
});



//banner.textContent = phrase.replace('койот', 'охотник');
// 'img/hunter.png'  'img/cayote.png'
/*
Метод includes
используется для поиска значения (подстроки) в строке
Возвращаются следующие значения:
* true  - значение найдено в строке
* false - значение не найдено в строке

const hello = 'Hello world!';
console.log(hello.includes('world'));  => true
console.log(hello.includes('people')); => false


Часто используется в инструкции if:
if ('Hello JS'.includes('JS')) {
    console.log('Hello developer');
} else {
    console.log('I do not know you');
}
=> Hello developer


В методе includes есть второй аргумент (по умолчанию равен 0), который позволяет осуществлять поиск с определённой позиции (индекса строки)
if ('Hello JS'.includes('JS', 7)) {
    console.log('Hello developer');
} else {
    console.log('I do not know you');
}
=> I do not know you


Методы startsWith и endsWith
позволяют сделать проверку:
* startsWith - начинается ли строка с указанного значения
* endsWith - заканчивается ли строка указанным значением

const phone = 'IPhone 13 Pro';
console.log(phone.startsWith('IPhone')); => true
console.log(phone.endsWith('13'));       => false


Д.З.
1. Есть ли Вилли в строке 'Билли, Вилли и Дилли'? Ответ вывести в консоль (true/false)
----------------
2. Сделайте проверку в 'https://www.google.com/':
* https  - вывести в консоль 'SSL-сертификат подключён'
* http - вывести в консоль 'SSL-сертификат не подключён'
*/










// Код из лекции
//console.log(phrase.includes('охотник'));
//console.log(phrase.includes('охотникааа'));

// document.querySelector('form').addEventListener('change', (e) => {
//     if (phrase.includes(e.target.value)) {
//         img[1].src = 'img/hunter.png';
//         banner.textContent = phrase.replace('койот', 'охотник');
//     } else {
//         img[1].src = 'img/cayote.png';
//         banner.textContent = phrase.replace('охотник', 'койот');
//     }
// });

// console.log(img[1].src);
// console.log(img[1].src.includes('http', 0));
// console.log(img[1].src.includes('http', 5));

// console.log(img[1].src.startsWith('img'));
// console.log(img[1].src.endsWith('png'));










/*
Решение Д.З. (способы решения могут отличаться)
1. 
console.log('Билли, Вилли и Дилли'.includes('Вилли'));
----------------
2.
const url = 'https://www.google.com/';
if (url.startsWith('https')) {
    console.log('SSL-сертификат подключён');
} else {
    console.log('SSL-сертификат не подключён');
}
*/