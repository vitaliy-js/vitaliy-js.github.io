const ducks = [
    ['Скрудж', 80, 'деньги', '1.png'],
    ['Зигзаг', 22, 'самолёты', '2.png']
];





















// Код из практики
// getId();

// function getId() {
//     const url = window.location.href;
//     const profileIndex = url.indexOf('=');
//     const profileId = url.slice(profileIndex + 1);
//     createCharacter(profileId - 1);
// }

// function createCharacter(profileId) {
//     document.querySelector('div').innerHTML = `
//         <img src="img/${ducks[profileId][3]}">
//         <ul>
//             <li>${ducks[profileId][0]}</li>
//             <li>${ducks[profileId][1]}</li>
//             <li>${ducks[profileId][2]}</li>
//         </ul>`;
// }