const alt = () => 'Подкова';
const div = document.querySelector('div');
const img = document.querySelectorAll('img');
let distance = -10;



/*
Строковые данные можно объединять следующим образом:
1. Оператор +
const str = 'Hello';
console.log(str + ' world');     => Hello world

2. Шаблонные строки
строки с использованием выражений
* строка должна быть внутри обратных кавычек
* выражение добавляется во внутрь ${}
const str = 'Hello';
console.log(`${str} world`);
=> Hello world


При помощи ${} можно в строку добавлять как значение констант/переменных, так и более сложные выражения: вызов функции, тернарный оператор и т.п.
const hello = () => 'Hello';
console.log(`${hello()} world!`);
=> Hello world
*/










// Код из лекции
// console.log('Java' + 'Script' + ' is the best');
// img[1].style.left = distance + 'px';

// div.innerHTML = `
// <img src="img/magnet.png">
// <img src="img/horseshoe.svg" style="left:${distance}px" alt="${alt()}">`;