const title = document.querySelector('h1');
const input = document.querySelector('input');
const button = document.querySelector('button');



/*
С помощью JavaScript можно добавлять и изменять значения HTML-атрибутов через свойства DOM
Формула:
элемент.атрибут = 'значение';
input.value = 'Hello world!';


Работа с атрибутом style
Формула:
элемент.style.свойство = 'значение';
title.style.color = 'orange';
<h1 style="color: orange;">Атрибуты</h1>


CSS-свойства, написанные через тире, прописываются в JavaScript с помощью Camel case
title.style.fontSize = '23px';
title.style.borderBottomColor = 'red';


Булевый тип данных (Boolean) 
принимает два возможных значения: истина (true) или ложь (false)
const result = true;
Важно: кавычки для true и false не добавляются


Работа с пустыми (логическими) атрибутами
button.disabled = true;  
=> кнопка находится в disabled состоянии

button.disabled = false;
=> кнопка НЕ находится в disabled состоянии


Д.З.
1. Раскомментировать код в файле "index.html"
2. В файле "script.js" изменить текст для элементов <b> в следующем порядке: 'blue', 'purple', 'grey'
3. Добавить для всех элементов <b> сплошную границу толщиной 1px цвета #3e3e3e
4. Изменить для элементов <b> цвет фона (background-color) в следующем порядке: #4084eb, #b550da, #818282
*/










// Код из лекции
// input.value = 'Bye';
// input.type = 'password';
// input.placeholder = 'Put some text';

// title.style = 'color: red;background: yellow;';
// title.style.color = 'green';
// title.style.border = '1px solid brown';
// title.style.fontSize = '45px';
// title.style.backgroundColor = 'pink';

// button.disabled = false;










/*
Пример решения Д.З.
const blueBox = document.querySelector('b:first-child');
const purpleBox = document.querySelector('.purple');
const greyBox = document.querySelector('#grey');

blueBox.textContent = 'Blue';
purpleBox.textContent = 'Purple';
greyBox.textContent = 'Grey';

blueBox.style.border = '1px solid #3e3e3e';
purpleBox.style.border = '1px solid #3e3e3e';
greyBox.style.border = '1px solid #3e3e3e';

blueBox.style.backgroundColor = '#4084eb';
purpleBox.style.backgroundColor = '#b550da';
greyBox.style.backgroundColor = '#818282';
*/