const cat = document.querySelector('.cat');

document.querySelector('.cat').addEventListener('click', () => {

});



/*
Свойство className
отвечает за значение HTML-атрибута class
cat.className = 'cat-smile';
=> <div class="cat-smile"></div>

Данное свойство можно использовать для добавления 2+ класса
cat.className = 'cat black-cat cat-smile';
=> <div class="cat black-cat cat-smile"></div>


Методы classList
A. add
classList.add() - добавление класса
cat.classList.add('cat-smile');

B. remove
classList.remove() - удаление класса
cat.classList.remove('cat-smile');

C. toggle
classList.toggle() - переключение класса
Если указанный класс отсутствует, он будет добавлен. Если класс уже присутствует, он будет удалён
cat.classList.toggle('cat-smile');


Д.З.
1. Раскомментировать код в файле "index.html"
2. В файле "script.js" с помощью методов add и remove установить цвета в следующем порядке для заранее подготовленных классов: blue, purple, green
*/










// Код из лекции
//cat.className = 'hello';
//cat.classList.add('cat-smile');
//cat.classList.remove('cat-smile');
//cat.classList.toggle('cat-smile');










/*
Пример решения Д.З.
const blueBox = document.querySelector('#blue');
const purpleBox = document.querySelector('#purple');
const greenBox = document.querySelector('#green');

blueBox.classList.remove('purple');
blueBox.classList.add('blue');

purpleBox.classList.remove('green');
purpleBox.classList.add('purple');

greenBox.classList.remove('blue');
greenBox.classList.add('green');
*/