const home = document.querySelector('.home');
const btnDay = document.querySelector('.btn-day');
const btnNight = document.querySelector('.btn-night');

btnDay.addEventListener('click', () => {

});

btnNight.addEventListener('click', () => {

});














// Код из практики
// btnDay.addEventListener('click', () => {
//     btnDay.disabled = true;
//     btnNight.disabled = false;

//     home.classList.add('day');
//     home.classList.remove('night');
// });

// btnNight.addEventListener('click', () => {
//     btnNight.disabled = true;
//     btnDay.disabled = false;

//     home.classList.add('night');
//     home.classList.remove('day');
// });