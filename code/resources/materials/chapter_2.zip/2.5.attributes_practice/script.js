


document.querySelector('.character').addEventListener('click', () => {


});


















// Код из практики
// const coins = document.querySelector('.coins');
// const tree = document.querySelector('.tree');
// let countCoins = 1;
// let countTree = 80;

// document.querySelector('.character').addEventListener('click', () => {
//   countCoins++;
//   coins.textContent = countCoins;

//   countTree = countTree + 50;
//   tree.style.height = countTree + 'px';
// });