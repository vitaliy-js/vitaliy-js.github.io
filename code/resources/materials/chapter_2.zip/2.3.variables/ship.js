const ship = document.querySelector('.ship img');
const btn = document.querySelector('.ship button');
// const countdown = document.querySelector('b');
// let count = 3;

if (typeof countdown !== 'undefined' && 
    typeof count !== 'undefined') {
    btn.addEventListener('click', () => {
        btn.disabled = true;
        countdown.textContent = count;
        const timer = setInterval(() => {
            if (count < 2) {
                clearInterval(timer);
                countdown.textContent = 'Пуск';
                ship.style.animationName = 'start';
            } else {
                count--;
                countdown.textContent = count;
            }
        }, 1000);
    });
}