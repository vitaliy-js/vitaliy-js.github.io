


/*
Константа (const)
переменная, значение которой НЕ может быть изменено после её создания

Объявляется с помощью ключевого слова const
const button = document.querySelector('button');


Переменная (let)
переменная, значение которой может быть изменено после её создания

Объявляется с помощью ключевого слова let
let word = 'Hello';
word = 'Bye';


Преимущества констант и переменных:
1. Хранение значения и многократное его использование
2. Аккуратность кода


Правила объявления переменной/константы, присвоение значения:
1. Имя
	A. В основном используется camelCase (myNameIs)
	B. Цифры можно использовать, но первый символ не может с неё начинаться
	C. Из символов можно использовать только $ и _ (пробелы не допускаются)

2. Значения
	A. Буквы, символы, цифры (как текст) должны быть в кавычках (const email = '1@t.com';) 
	B. Цифры прописываются без кавычек (let age = 18;)
	C. Значения других типов данных мы рассмотрим по мере изучения JavaScript
	D. Зарезервированные слова также прописываются без кавычек (const box = document.querySelector('b');)

3. Популярные ошибки
	А. Одинаковая переменная не может объявляться дважды
		неверно: 
		let name = 'vasya';
		let name = 'misha';
		верно:
		let name = 'vasya';
		name = 'misha';
	B. Вначале объявляем, потом используем
		неверно:
		title.textContent = 'Hello';
		const title = document.querySelector('h1');
		верно:
		const title = document.querySelector('h1');
		title.textContent = 'Hello';
*/










// Код из лекции
// const title = document.querySelector('h1');
// title.textContent = 'Hello';

// let text = 'Старт';
// text = 'Пуск';
// title.textContent = text;

// const button = document.querySelector('button');
// button.textContent = text;

// const countdown = document.querySelector('b');
// let count = 5;
// countdown.textContent = count;