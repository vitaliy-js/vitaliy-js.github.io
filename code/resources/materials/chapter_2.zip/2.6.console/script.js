const coins = document.querySelector('.coins');
const tree = document.querySelector('.tree');
let countCoins = 1;
let countTree = 80;

document.querySelector('.character').addEventListener('click', () => {
  countCoins++;
  coins.textContent = countCoins;

  countTree = countTree + 50;
  tree.style.height = countTree px;

});



/*
Метод console.log
выводит сообщения в консоль браузера. Используется для отладки JS-кода
const hi = 'Hello';
console.log(hi);
=> Hello

console.log(document.querySelector('input').type);
=> text


Д.З.
1. Выведите в консоль размер шрифта элемента h1
---------------------
2. Сегодня Буратино 7 лет и завтра у него День рождения. Посчитайте возраст Буратино на завтра, и выведите его в консоль  
*/










// Код из лекции
// console.log(countTree);
// console.log(tree.style.height);










/*
Решение Д.З. (способы решения могут отличаться)
1. 
const title = document.querySelector('h1');
console.log(title.style.fontSize);
=> 28px
-------------------
2.
let age = 7;
age++;
console.log(age);
=> 8
*/