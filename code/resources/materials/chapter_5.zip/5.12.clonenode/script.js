const continent = document.querySelector('.continent');

continent.addEventListener('click', (e) => {
    if (e.target.classList.contains('rabbit-box')) {

    }
});



/*
Метод cloneNode
позволяет полностью клонировать элемент (в т.ч. с потомками внутри)

Формула:
элемент.cloneNode(параметр)

Параметр:
true - копирование элемента с его потомками
false - копирование элемента без потомков

<h1>Hello <span>world</span></h1>
console.log(document.querySelector('h1').cloneNode(true));
=> <h1>Hello <span>world</span></h1>

console.log(document.querySelector('h1').cloneNode(false));
=> <h1></h1>


Способы решения:
I. Свойство outerHTML
const rabbit = document.createElement('div');
continent.append(rabbit);
rabbit.outerHTML = `
<div class="rabbit-box">
    <div class="rabbit"></div>
</div>`;

II. Метод insertAdjacentHTML
const rabbit = `
<div class="rabbit-box">
    <div class="rabbit"></div>
</div>`;
continent.insertAdjacentHTML('beforeend', rabbit);

III. Метод cloneNode
const rabbit = e.target.cloneNode(true);
continent.append(rabbit);
*/










//Код из лекции
// continent.addEventListener('click', (e) => {
//     if (e.target.classList.contains('rabbit-box')) {
//         const rabbit = e.target.cloneNode(true);
//         continent.append(rabbit);
//     }
// });