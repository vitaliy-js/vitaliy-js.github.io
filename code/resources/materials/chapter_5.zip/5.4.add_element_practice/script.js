







/*  
'father', 'mother', 'daughter', 'son'
*/














// Код из практики
// document.querySelector('.list').addEventListener('click', (e) => {
//     if (!e.target.classList.contains('list')) {
//         e.target.style.display = 'none';
//         addMember(e.target);
//     }
// });

// function addMember(person) {
//     const parents = document.querySelector('.parents');
//     const children = document.querySelector('.children');

//     const member = document.createElement('span');
//     member.className = person.className;

//     if (member.className === 'father') {
//         parents.prepend(member);
//     } else if (member.className === 'mother') {
//         parents.append(member);
//     } else if (member.className === 'daughter') {
//         children.prepend(member);
//     } else if (member.className === 'son') {
//         children.append(member);
//     }
// }