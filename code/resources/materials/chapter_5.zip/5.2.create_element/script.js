const beach = document.querySelector('.beach');



/*
'img/sun.png'

Метод createElement
позволяет создать HTML-элемент c заданным тегом
const mainText = document.createElement('p');


После создания элемента его можно добавить в HTML-разметку, а также задать атрибуты, текст и т.д.
mainText.className = 'main-text';
mainText.textContent = 'Hello people';


Алгоритм действий
1. Создать элемент
2. Добавить в разметку
3. Добавить нужные атрибуты, текст и т.п.


Д.З.
1. Создайте поле для ввода пароля с id "input-pwd" 
----------------------------------
2. Создайте кнопку с классом "btn-main" и текстом "Отправить", которая будет отключена (состояние disabled)

Для добавления элементов в родительский элемент form можно использовать следующий код: 
document.querySelector('form').append(NEW);
(NEW - созданный вами элемент)
*/










// Код из лекции
// const sun = document.createElement('img');
// beach.append(sun);
// sun.src = 'img/sun.png';
// sun.className = 'sun';










/*
Решение Д.З. (способы решения могут отличаться)
1.
const input = document.createElement('input');
document.querySelector('form').append(input);
input.type = 'password';
input.id = 'input-pwd';
----------------------------------
2.
const btn = document.createElement('button');
document.querySelector('form').append(btn);
btn.classList.add('btn-main');
btn.disabled = 'password';
btn.textContent = 'Отправить';
*/