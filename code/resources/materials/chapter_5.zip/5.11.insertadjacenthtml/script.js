const div = document.querySelector('div');
const p = document.querySelector('p');
const block = '<b>NEW</b>';



/*
Метод insertAdjacentHTML
позволяет сразу добавить блок HTML-кода в нужное место разметки

Формула:
элемент.insertAdjacentHTML(параметр вставки, HTML-код)

Включает 2 параметра:
- место в разметке относительно выбранного элемента
- HTML-код

Параметры вставки:
'beforeend' – добавляется в конец выбранного элемента
'afterbegin' – добавляется в начало выбранного элемента
'beforebegin' – добавляется перед выбранным элементом
'afterend' – добавляется после выбранного элемента

document.body.insertAdjacentHTML('afterbegin', `<h1>Hello</h1>`);


Сравнение innerHTML и insertAdjacentHTML
- innerHTML чаще используется для полной замены содержимого элементов, когда нужно очистить или обновить весь внутренний контент
- insertAdjacentHTML используется для добавления контента в конкретную позицию без перезаписи существующего


Д.З.
Используя метод insertAdjacentHTML, вернитесь к лекции "5.7 Свойство innerHTML и outerHTML" и перепишите код создания overlay и его содержимого
*/










// Код лекции
// div.insertAdjacentHTML('beforeend', '<b>NEW</b>');
// div.insertAdjacentHTML('afterbegin', '<b>NEW</b>');
// div.insertAdjacentHTML('afterbegin', block);
// p.insertAdjacentHTML('beforebegin', block);
// p.insertAdjacentHTML('afterend', block);










/*
Решение Д.З. (способы решения могут отличаться)
document.querySelector('#main-btn').addEventListener('click', () => {
    const overlay = `
    <div class="overlay">
        <div class="modal">
            <p>Хорошего дня!<br>Спасибо</p>
            <button class="btn-modal">Закрыть</button>
        </div>
    </div>`;
    document.body.insertAdjacentHTML('beforeend', overlay);
    
    closeModal(document.querySelector('.overlay'));
});
*/