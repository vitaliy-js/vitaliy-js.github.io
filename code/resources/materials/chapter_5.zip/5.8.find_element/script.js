const div = document.querySelector('div');
const h2 = document.querySelector('h2');
const p = document.querySelector('p');
const span = document.querySelector('span');
const h1 = document.querySelector('h1');

div.addEventListener('click', () => {
    div.lastElementChild.remove();
});



/*
Свойства для поиска элементов
позволяют перемещаться по DOM и находить нужные элементы

Формула:
стартовыйЭлемент.свойство

parentElement - родитель-элемент
children - коллекция дочерних элементов
firstElementChild - первый дочерний элемент
lastElementChild - последний дочерний элемент
previousElementSibling - предыдущий сестринский элемент
nextElementSibling - следующий сестринский элемент

document.querySelector('h1').parentElement;
=> body


Свойства можно соединять между собой
const h2 = document.querySelector('h2');
h2.parentElement.parentElement;
=>  body


Д.З.
Используя различные свойства и код из index.html, пропишите путь от одного элемента к другому в консоли:
1. Старт: h1; Финиш: div;
2. Старт: h2; Финиш: div;
3. Старт: div; Финиш: p;
3. Старт: span; Финиш: h1;
4. Старт: body; Финиш: span;
*/










// Код из лекции
// console.log(p.parentElement);
// console.log(h1.parentElement);
// console.log(div.children);
// console.log(div.children[0]);
// console.log(div.firstElementChild);
// console.log(div.lastElementChild);
// console.log(p.nextElementSibling);
// console.log(p.previousElementSibling);
// console.log(p.parentElement.previousElementSibling);










/*
Решение Д.З. (способы решения могут отличаться)
1. console.log(h1.nextElementSibling);
2. console.log(h2.parentElement);
3. console.log(div.children[1]);
3. console.log(span.parentElement.previousElementSibling);
4. console.log(document.body.children[1].lastElementChild);
*/