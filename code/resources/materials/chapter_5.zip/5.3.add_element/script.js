const div = document.querySelector('div');



/*
Методы вставки элемента в разметку
append – добавляется в конец выбранного элемента (контейнера)
prepend – добавляется в начало выбранного элемента (контейнера)
before – добавляется перед выбранным элементом
after – добавляется после выбранного элемента

Формула:
выбранныйЭлемент.метод(новыйЭлемент);

Для append и prepend выбранным элементом является родительский элемент
Для before и after выбранным элементом является соседний (сестринский) элемент

const btn = document.createElement('button');
document.querySelector('form').before(btn);


Можно добавлять сразу несколько элементов (они перечисляются в скобках через запятую):
document.querySelector('form').before(input, btn);


Эти методы также используются для перемещения существующих элементов:
document.querySelector('button').before(document.querySelector('textarea'));


Устаревшие методы (как правило, не используются в новых приложениях):
1. appendChild() - добавляется в конец выбранного родительского элемента (=append)
div.appendChild(newEl);

2. insertBefore() - добавляется перед сестринским элементом (=before)
В методе указываются 2 аргумента: новый элемент и его сестринский элемент, перед которым он будет добавлен
div.insertBefore(newEl, document.querySelector('span'));


Д.З.
1. Добавьте элемент li с текстом "Солнце" в конец следующего списка:
<ul>
    <li>Море</li>
</ul>
---------------------------
2. Добавьте после изображения элемент strong с текстом "Лето!!!"
*/










// Код из лекции
// const newEl = document.createElement('b');
// newEl.textContent = 'NEW';

//div.append(newEl);
//div.prepend(newEl);

//document.querySelector('p').before(newEl);
//document.querySelector('p').after(newEl);
//div.before(newEl);

// const newEl2 = document.createElement('b');
// newEl2.textContent = 'NEW2';

//div.before(newEl, newEl2);

// document.querySelector('p').before(document.querySelector('span'));










/*
Решение Д.З. (способы решения могут отличаться)
1.
const li = document.createElement('li');
document.querySelector('ul').append(li);
li.textContent = 'Солнце';
------------------------------
2.
const strong = document.createElement('strong');
document.querySelector('img').after(strong);
strong.textContent = 'Лето!!!';
*/