document.querySelector('.btn-remove').addEventListener('click', (e) => {
     
});

function removePerson(person) {
    person.remove();
}



/*
Метод closest
возвращает ближайший элемент среди предков по указанному CSS селектору

Формула:
элемент.closest(CSS-селектор)

document.querySelector('button').closest('body');
=> body


Поиск начинается с указанного элемента
document.querySelector('button').closest('button');
=> button


Если элемент не найден, возвращается значение null
document.querySelector('button').closest('#some-id');
null


Значение null - отсутствие какого-либо значения
console.log(document.querySelector('#some-id'));
=> null


Д.З
Используя метод closest, вернитесь к уроку "5.9 Практика. Свойства для поиска элементов" и перепишите функцию удаления задачи (removeTask)
*/










// Код из лекции
// document.querySelector('.btn-remove').addEventListener('click', (e) => {
//     console.log(e.target.closest('h1'));

//     // if (e.target.closest('h1') === null) {
//     //     console.log('NULL');
//     // }

//     removePerson(e.target.closest('.person'));
// });
// function removePerson(person) {
//     person.remove();
// }










/*
Решение Д.З. (способы решения могут отличаться)
function removeTask(taskWrap) {
    taskWrap.addEventListener('click', (e) => {
        if (e.target.classList.contains('remove-btn')) {
            e.target.closest('.task').remove();
        }
    });
}
*/