









// Купить корм коту  Полить цветы  Пойти в спортзал














// Код из практики
// document.querySelector('form').addEventListener('submit', (e) => {
//     e.preventDefault();
//     const input = document.querySelector('input');

//     if (input.value.length > 0) {
//         addTask(input.value);
//     }
// });

// function addTask(text) {
//     const taskWrap = document.querySelector('.task-wrap');

//     const task = document.createElement('div');
//     task.className = 'task';
//     taskWrap.prepend(task);
//     task.innerHTML = `
//         <p></p>
//         <button class="remove-btn"></button>`;
//     document.querySelector('p').textContent = text;

//     removeTask(taskWrap);
// }

// function removeTask(taskWrap) {
//     taskWrap.addEventListener('click', (e) => {
//         if (e.target.classList.contains('remove-btn')) {
//             e.target.parentElement.remove();
//         }
//     });
// }