document.querySelector('ul').addEventListener('click', (e) => {
    
});



/*
Метод remove
позволяет удалить элемент из HTML-разметки

Формула:
элемент.remove();

document.querySelector('h1').remove();


Метод replaceWith
позволяет заменить один элемент другим (старый элемент автоматически удаляется)

Формула:
старыйЭлемент.replaceWith(новыйЭлемент);

const text = document.createElement('p');
text.textContent = 'Hello text!';
document.querySelector('h1').replaceWith(text);


Устаревшие методы (как правило, не используются в новых приложениях):
1. removeChild() - удаление элемента внутри контейнера
родитель.removeChild(удалемыйЭлемент);
document.querySelector('body').removeChild(document.querySelector('h1'));

2. replaceChild() - замена элемента внутри контейнера
родитель.replaceChild(новыйЭлемент, удалемыйЭлемент);
const header = document.querySelector('h1');
const text = document.createElement('p');
text.textContent = 'Hello text!';
document.querySelector('body').replaceChild(text, header);


Д.З.
Открыть предыдущее задание с практикой. Выполнить следующие шаги:
1. При клике на дерево ('.tree') нужно заменить h1-элемент на h2. Для нового элемента добавить текст 'Новый заголовок'
2. Удалить h2-элемент при клике на него
*/










// Код из лекции
// document.querySelector('ul').addEventListener('click', (e) => {
//     //e.target.remove();
//     replaceEl(e.target);
// });

// function replaceEl(mosquito) {
//     const bee = document.createElement('li');
//     bee.className = 'bee';
//     bee.id = mosquito.id;
//     mosquito.replaceWith(bee);
// }










/*
Решение Д.З. (способы решения могут отличаться)
document.querySelector('.tree').addEventListener('click', () => {
    const header = document.querySelector('h1');
    const newHeader = document.createElement('h2');
    header.replaceWith(newHeader);
    newHeader.textContent = 'Новый заголовок';

    newHeader.addEventListener('click', () => {
        newHeader.remove();
    });
});
*/