const userEmail = 'test@test.com';



/*
'Поле не может быть пустым'
'Email незарегистрированный'
*/

















// Код из практики
// const userEmail = 'test@test.com';

// document.querySelector('form').addEventListener('submit', (e) => {
//     e.preventDefault();
//     const email = document.querySelector('input');
//     const alert = document.querySelector('.alert');

//     if (email.value.length === 0) {
//         showErr(email, 'Поле не может быть пустым');
//     } else if (email.value !== userEmail) {
//         showErr(email, 'Email незарегистрированный');
//     } else {
//         alert.style.display = 'flex';
//         closeAlert(alert);
//     }
// });

// function showErr(email, errText) {
//     const err = document.createElement('span');
//     err.className = 'err-message';
//     err.textContent = errText;
//     email.after(err);
//     removeErr(email, err);
// }

// function removeErr(email, err) {
//     email.addEventListener('input', () => err.remove());
// }

// function closeAlert(alert) {
//     document.querySelector('.btn-close').addEventListener('click', () => {
//         alert.style.display = 'none';
//     });
// }