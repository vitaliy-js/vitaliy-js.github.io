document.querySelector('#main-btn').addEventListener('click', () => {

});



/*
Свойство innerHTML
позволяет установить (получить) HTML-содержимое внутри элемента
<div></div>
document.querySelector('div).innerHTML = `<p>Hello World!</p>`;
<div>
    <p>Hello World!</p>
</div>


Свойство outerHTML
позволяет установить (получить) HTML-содержимое внутри элемента + сам элемент
<div></div>
document.querySelector('div).outerHTML = `<div class="wrap"><p>Hello World!</p></div>`;
<div class="wrap">
    <p>Hello World!</p>
</div>

Важно: при замене элемента с помощью outerHTML оригинальный элемент удаляется из DOM, поэтому нужно к нему обращаться, как к новому элементу
const div = document.querySelector('div');
div.outerHTML = `<div><p>Hello World!</p></div>`;
console.log(div); => <div></div>
console.log(document.querySelector('div')); => <div><p>Hello World!</p></div>


innerHTML и outerHTML позволяют получить HTML-код в виде строки
<div><p>Hello World!</p></div>

console.log(document.querySelector('div').innerHTML); => <p>Hello World!</p>

console.log(document.querySelector('div').outerHTML); => <div><p>Hello World!</p></div>


Д.З. Используя innerHTML или outerHTML, вернитесь к уроку "5.6 Практика. Удаление элемента" и выполните следующее:
1. Удалить div с классом alert в HTML-файле
2. В CSS-файле для класса alert заменить display: none; на display: flex;
3. С помощью innerHTML/outerHTML создать элемент в body и добавить содержимое во внутрь него
4. При нажатии на кнопку с классом btn-close, удалить alert-блок из разметки

<div class="alert">
    <p>Запрос отправлен</p>
    <button class="btn-close"></button>
</div>
*/










// Код из лекции
// document.querySelector('#main-btn').addEventListener('click', () => {
//     // const overlay = document.createElement('div');
//     // overlay.className = 'overlay';
//     // document.body.append(overlay);
//     // overlay.innerHTML = `
//     // <div class="modal">
//     //     <p>Хорошего дня!<br>Спасибо</p>
//     //     <button class="btn-modal">Закрыть</button>
//     // </div>`;

//     const overlay = document.createElement('div');
//     document.body.append(overlay);
//     overlay.outerHTML = `
//     <div class="overlay">
//         <div class="modal">
//             <p>Хорошего дня!<br>Спасибо</p>
//             <button class="btn-modal">Закрыть</button>
//         </div>
//     </div>`;
//     console.log(overlay);
//     closeModal(document.querySelector('.overlay'));
// });

// function closeModal(overlay) {
//     document.querySelector('.btn-modal').addEventListener('click', () => {
//         overlay.remove();
//     });
// }










/*
Решение Д.З. (способы решения могут отличаться)
if (email.value.length === 0) {
    showErr(email, 'Поле не может быть пустым');
} else if (email.value !== userEmail) {
    showErr(email, 'Email незарегистрированный');
} else {
    showAlert();
}

I. innerHTML
function showAlert() {
    const alert = document.createElement('div');
    alert.className = 'alert';
    document.body.append(alert);
    alert.innerHTML = `
    <p>Запрос отправлен</p>
    <button class="btn-close"></button>`;
    closeAlert(alert);
}

function closeAlert(alert) {
    document.querySelector('.btn-close').addEventListener('click', () => {
        alert.remove();
    });
}

II. outerHTML
function showAlert() {
    const alert = document.createElement('div');
    document.body.append(alert);
    alert.innerHTML = `
    <div class="alert">
        <p>Запрос отправлен</p>
        <button class="btn-close"></button>
    </div>`;
    closeAlert(document.querySelector('.alert'));
}

function closeAlert(alert) {
    document.querySelector('.btn-close').addEventListener('click', () => {
        alert.remove();
    });
}
*/