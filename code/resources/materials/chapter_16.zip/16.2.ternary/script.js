const img = document.querySelector('img');
const div = document.querySelector('div');
let item = 'js';

if (item === 'js') {
    img.src = 'img/js.png';
} else {
    img.src = 'img/html.png';
}



/*
Тернарный оператор
краткая форма условного выражения, которая часто заменяет инструкцию if...else

Формула:
(условие) ? выполнение кода_1 : выполнение кода_2;

const animal = 'кот';
(animal === 'кот') ? console.log('мяу') : console.log('гав');
=> мяу


Часто его можно встретить в связке с шаблонными строками:
word.innerHTML = `<p>${(animal === 'кот') ? 'мяу' : 'гав'}</p>`;
=> <p>мяу</p>
*/










// Код из лекции
// (item === 'js') ? img.src = 'img/js.png' : img.src = 'img/html.png';

// div.innerHTML = `<b>${(item === 'js') ? 'JS' : 'HTML'}</b>`;