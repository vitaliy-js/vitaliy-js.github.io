const img = document.querySelector('img');
let item = 'js';

if (item === 'html') {
    img.src = 'img/html.png';
} else if (item === 'css') {
    img.src = 'img/css.png';
} else {
    img.src = 'img/js.png';
}



/*
Инструкция switch
альтернатива для инструкции if...else if...else

Если условие выполняется, запускается код в блоке case до ближайшей инструкции break или до конца switch

Важно: если break не указан, выполнение кода пойдёт ниже по следующим case, при этом проверки будут игнорироваться
const item = 'суп';

A. Без break:
switch (item) {
    case 'суп':
        console.log('еда');
    case 'дуб':
        console.log('дерево');
}
=> еда дерево

B. С break:
switch (item) {
    case 'суп':
        console.log('еда');
        break;
    case 'дуб':
        console.log('дерево');
        break;
}
=> еда


В инструкции switch используется только строгая проверка на равенство (===)


Блок default (необязательный)
Если ни один case не выполнился, запускается код в инструкции default (подобен else)
const item = 'что-то';
switch (item) {
    case 'суп':
        console.log('еда');
        break;
    case 'дуб':
        console.log('дерево');
        break;
    default:
        console.log('неизвестно');
}
=> неизвестно
*/










// Код из лекции
// switch (item) {
//     case 'html':
//         img.src = 'img/html.png';
//         break;
//     case 'css':
//         img.src = 'img/css.png';
//         break;
// }

// switch (item) {
//     case 'html':
//         img.src = 'img/html.png';
//         break;
//     case 'css':
//         img.src = 'img/css.png';
//         break;
//     default:
//         img.src = 'img/js.png';
// }