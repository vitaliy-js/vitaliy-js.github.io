const arr = [
    {name: 'кот', kingdom: 'животные'},
    {name: 'дуб', kingdom: 'растения'},
    {name: 'собака', kingdom: 'животные'},
    {name: 'клён', kingdom: 'растения'}
];

const result = arr.find((item, index, array) => {
    return item.kingdom === 'растения';
});
console.log(result);



/*
Метод findIndex
возвращает индекс первого элемента, где условие выполнилось (true)
const age = [5, 12, 25, 18];
const result = age.findIndex((item) => item >= 18);
console.log(result); => 2


Данный метод отлично подходит для поиска индекса элемента-объекта в массиве
const friends = [{id: 1, name: 'Росс'}, {id: 2, name: 'Рейчел'}];
const person = friends.findIndex(item => item.name === 'Рейчел');
console.log(person); 
=> 1


Метод findLastIndex
выполняется аналогично findIndex, только поиск ведётся с конца массива (справа налево, подобно lastIndexOf)
const age = [5, 12, 25, 18];
const result = age.findLastIndex((item) => item >= 18);
console.log(result); => 3


Если ни одно условие не выполнилось, возвращается значение -1
const result = age.findLastIndex((item) => item >= 50);
console.log(result); => -1
*/










// Код из лекции
// const result = arr.findIndex((item, index, array) => {
//     return item.kingdom === 'растения';
// });
// console.log(result);

// const result = arr.findLastIndex((item, index, array) => {
//     return item.kingdom === 'животные';
// });
// console.log(result);

// const result = arr.findLastIndex((item, index, array) => {
//     return item.kingdom === 'рыбы';
// });
// console.log(result);