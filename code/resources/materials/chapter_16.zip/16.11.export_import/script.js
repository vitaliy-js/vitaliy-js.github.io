


/*
Модули
позволяют организовать код в отдельные блоки (js-файлы)

Чтобы браузер мог использовать модули, в тег script добавляется атрибут type="module"
<script src="script.js" type="module"></script>


Инструкция export
используется для экспорта функций, переменных из данного модуля
const lion = 'Лев';
const sayHello = () => 'Hello';
export {lion, sayHello};


Инструкция import
позволяет импортировать функции, переменные из других модулей в текущий
import {lion, sayHello} from './other.js';
console.log(lion); => Лев
console.log(sayHello()); => Hello


Импорт всех функций (переменных)
если нужно импортировать все функции (переменные) из модуля, можно собрать их в один объект
import * as all from './other.js';
console.log(all.lion); => Лев
console.log(all.sayHello()); => Hello


Экспорт по умолчанию
позволяет экспортировать одну функцию (переменную)
export default function sayBye() {
    return 'Bye';
}
import sayBye from './other.js';
console.log(sayBye()); => Bye

Важно: export default можно использовать только один раз в файле
*/










// Код из лекции
// I. script.js:
// import {lion, sayHello} from './other.js';
// import * as all from './other.js';
// import sayBye2 from './other.js';

// console.log(lion);
// console.log(sayHello());
// console.log(all.lion);
// console.log(all.sayHello());
// console.log(sayBye2());


// II. other.js:
// const lion = 'Лев';

// function sayHello() {
//     return 'Hello';
// }

// export default function() {
//     return 'Bye';
// }

// export {lion, sayHello};