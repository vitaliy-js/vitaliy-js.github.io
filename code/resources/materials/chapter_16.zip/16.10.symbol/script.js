const coworkers = {
    john: 'boss',
    monica: 'qa',
    john: 'dev'
}
const john = 'john';
const john2 = 'john';
console.log(john === john2);



/*
Symbol
тип данных, который представляет уникальное значение

Создаётся путём вызова функции Symbol
const id = Symbol();

Можно добавить необязательный параметр для описания символа
const id = Symbol('id');


Его можно использовать, как идентификатор для свойств объектов
const animals = {
    'tom': 'cat',
    [Symbol('tom')]: 'cat',
    [Symbol('tom')]: 'rabbit'
}
console.log(animals);
=> {tom: 'cat', Symbol(tom): 'cat', Symbol(tom): 'rabbit'}


Символы часто используют для создания скрытых свойств объектов, чтобы случайно не перезаписать их другим кодом
for (let key in animals) {
    animals[key] = 'dog';
}
console.log(animals);
=> {tom: 'dog', Symbol(tom): 'cat', [Symbol('tom')]: 'rabbit'}


Метод Object.getOwnPropertySymbols
возвращает массив всех символьных свойств, найденных в объекте
const animalSymbol = Object.getOwnPropertySymbols(animals);
console.log(animalSymbol);
=> [Symbol(tom), Symbol(tom)]


Метод Reflect.ownKeys
возвращает массив всех свойств объекта, включая символы
const animalAll = Reflect.ownKeys(animals);
console.log(animalAll);
=> ['tom', Symbol(tom), Symbol(tom)]
*/










// Код из лекции
// const john = Symbol('john');
// const john2 = Symbol('john');
// console.log(john === john2);

// const coworkers = {
//     [Symbol('john')]: 'boss',
//     [Symbol('monica')]: 'qa',
//     [Symbol('john')]: 'dev'
// }
// console.log(coworkers);

// coworkers[Symbol('matt')] = 'manager';
// coworkers.john = 'cleaner';
// console.log(coworkers);

// for (let key in coworkers) {
//     console.log(key);
// }