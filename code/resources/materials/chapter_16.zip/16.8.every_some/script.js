const arr = [
    {name: 'кот', kingdom: 'животные'},
    {name: 'дуб', kingdom: 'растения'},
    {name: 'собака', kingdom: 'животные'}
];



/*
Метод every
возвращает true, если условие выполняется для каждого элемента массива. В противном случае - false
const age = [12, 18, 30];
const result = age.every((item, index, array) => {
    return item >= 18;
});
console.log(result); => false


Метод some
возвращает true, если хотя бы одно условие выполнилось. В противном случае - false
const result = age.some((item, index, array) => {
    return item >= 18;
});
console.log(result); => true
*/










// Код из лекции
// const result = arr.every((item, index, array) => {
//     console.log(index);
//     return item.kingdom === 'животные';
// });
// console.log(result);

// const result = arr.some((item, index, array) => {
//     console.log(index);
//     return item.kingdom === 'растения';
// });
// console.log(result);