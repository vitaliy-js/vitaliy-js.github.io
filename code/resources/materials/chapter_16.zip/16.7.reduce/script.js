const food = ['apple', 'pear', 'banana'];



/*
Метод reduce
используется для вычисления единого значения при переборе массива

Формула:
const val = arr.reduce((accumulator, item, index, array) => {
    return значение
}, initialValue);

Параметры метода: функция и initialValue
I. Параметры функции:
A. Аккумулятор (accumulator) - результат предыдущего вызова функции
B. Элемент (item) - текущий элемент в массиве
C. Индекс (index) - индекс текущего элемента
D. Массив (array) - массив, где выполняется действие

II. initialValue - позволяет установить начальное значение для аккумулятора 
const arr = [1, 2, 3];
const sum = arr.reduce((accumulator, item) => {
    return accumulator + item;
}, 0);
console.log(sum);
=> 6


Если initialValue не задан, значение accumulator будет равным первому элементу в массиве, при этом значение item будет равным второму элементу в массиве (соответственно перебор стартует со второго элемента)
const sum = arr.reduce((accumulator, item) => {
    console.log(accumulator, item)
    return accumulator + item;
});
console.log(sum);
=>
1 2
3 3
6
*/










// Код из лекции
// const val = food.reduce((accumulator, item) => {
//     return `${accumulator}, ${item}`;
// }, 'Hello');

// const val = food.reduce((accumulator, item, index) => {
//     console.log(index);
//     return `${accumulator}, ${item}`;
// });

// console.log(val);