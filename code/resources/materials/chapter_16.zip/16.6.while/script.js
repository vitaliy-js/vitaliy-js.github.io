const food = ['apple', 'pear', 'banana'];
for (let i = 0; i < food.length; i++) {
    console.log(food[i]);
}



/*
Цикл while
если условие выполняется (true), запускается код в теле цикла. Если нет (false), цикл останавливается

Формула:
while (условие) {
  тело цикла
}

const animals = ['cat', 'dog'];
let i = 0;
while (i < animals.length) {
    console.log(animals[i]);
    i++;
}
=> cat dog


Цикл do...while
сначала выполняется код в теле цикла, а затем происходит проверка условия. Таким образом, код в теле цикла выполнится как минимум один раз

Формула:
do {
  тело цикла
} while (условие);

do {
    console.log(animals[i]);
    i++;
} while (i < 0);
=> cat


Операторы break и continue здесь также можно использовать:
while (i < animals.length) {
    if (animals[i] === 'cat') {
        i++;
        continue;
    }
    console.log(animals[i]);
    i++;
}
=> dog
*/










// Код из лекции
// let i = 0;

// while (i < food.length) {
//     console.log(food[i]);
//     i++;
// }

// do {
//     console.log(food[i]);
//     i++;
// } while (i < food.length);

// do {
//     console.log(food[i]);
//     i++;
// } while (i < 0);