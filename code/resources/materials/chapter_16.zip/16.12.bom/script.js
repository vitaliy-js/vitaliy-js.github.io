


// setTimeout(() => {
// }, 2000);

// http://127.0.0.1:5500/
/*
BOM (Browser Object Model - объектная модель браузера)
набор объектов, которые позволяют управлять поведением браузера

A. Объект navigator
содержит информацию о браузере: версию, имя, локаль и др.
console.log(navigator.language); => en-GB


B. Объект screen
предоставляет информацию об экране пользователя: ширина и высота экрана в пикселях, ориентация экрана и др.
console.log(screen.width); => 1680


C. Объект history
предоставляет историю переходов в браузере в пределах сессии
console.log(history.length); => 2


D. Объект location
отображает текущий URL документа, позволяя нам получать, просматривать и изменять его части

- получить текущий URL
console.log(location.href);
=> http://127.0.0.1:5500

- переадресация на новую страницу
location.href = 'https://www.wikipedia.org/';

- перезагрузка текущей страницы
location.reload(true);

- доступ к значению query-параметра
http://127.0.0.1:5500/index.html?id=5
const param = new URLSearchParams(location.search);
console.log(param.get('id')); => 5
*/










// Код из лекции
// console.log(window.navigator);
// console.log(navigator);

// console.log(screen);

// console.log(history);
// setTimeout(() => {
//     history.back();
// }, 2000);

// console.log(location.href);
// setTimeout(() => {
//     location.href = 'https://www.wikipedia.org/';
// }, 2000);

// setTimeout(() => {
//     location.reload(true);
// }, 2000);