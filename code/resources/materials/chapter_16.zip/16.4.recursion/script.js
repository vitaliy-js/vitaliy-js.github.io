let num = 1;
getNumber();

function getNumber() {
    
}
console.log(num);



/*
Рекурсия
поведение функции, при котором она вызывает саму себя

Важно: внутри рекурсивной функции должно быть условие выхода из рекурсии. Иначе функция будет вызываться бесконечно

const arr = [1, 3, 5, 8, 10];
let random;
getRandom();
function getRandom() {
    random = Math.floor(Math.random() * 10) + 1;
    
    if (arr.includes(random)) {
        getRandom();
    }
}
console.log(random);
=> 9
*/










// Код из лекции
// function getNumber() {
//     if (num < 10) {
//         num++;
//         console.log(num);
//         getNumber();
//     }
// }