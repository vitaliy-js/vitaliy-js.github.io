


/*
Метод setTimeout
выполнение кода через определённый период времени один раз

Формула:
setTimeout(функция, задержка);

Задержка представлена в миллисекундах (1000 = 1с)

setTimeout(() => {
    console.log('Hello');
}, 1000);
=> Hello (выполнение кода через секунду)


Метод setInterval
циклическое выполнение кода через указанный интервал времени
setInterval(() => {
    console.log('hello');
}, 1000);
=> Hello (повторное выполнение кода каждую секунду)


Метод clearTimeout/clearInterval
отмена выполнения кода в setTimeout/setInterval

В виде параметра выступает timerId/intervalId, который возвращает setTimeout/setInterval метод
let counter = 0;
const timer = setInterval(() => {
    counter++;
    console.log(counter);
    if (counter === 3) {
        clearInterval(timer);
    }
}, 1000);
=> 1 2 3
*/










// Код из лекции
// setTimeout(() => {
//     console.log('Hello');
// }, 2000);

// setInterval(() => {
//     console.log('Hello');
// }, 2000);

// let counter = 5;
// const timer = setInterval(() => {
//     counter--;
//     console.log(counter);
// }, 1000);

// let counter = 5;
// const timer = setInterval(() => {
//     counter--;
//     console.log(counter);
//     if (counter === 0) {
//         clearInterval(timer);
//     }
// }, 1000);

// setTimeout(sayHi, 2000);
// function sayHi() {
//     console.log('Hello');
// }

// setTimeout(() => sayHi('Hello'), 2000);
// function sayHi(text) {
//     console.log(text);
// }