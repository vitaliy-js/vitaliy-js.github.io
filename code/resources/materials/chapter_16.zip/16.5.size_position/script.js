const i = document.querySelector('i');
const div = document.querySelector('div');



/*
Свойства для вычисления размера и расположения элемента:
A. clientWidth/clientHeight
ширина/высота блока, не включая границу и скроллбар (width/height + padding)
width: 400px;
height: 230px;
border: 1px solid #eb582c;
console.log(div.clientWidth, div.clientHeight);
=> 398 228


B. offsetWidth/offsetHeight
ширина/высота блока, включая границу и скроллбар (width/height + padding + border)
width: 400px;
height: 230px;
border: 1px solid #eb582c;
console.log(div.offsetWidth, div.offsetHeight);
=> 400 230


C. scrollWidth/scrollHeight
равно значению clientWidth/clientHeight + содержимое, невидимое из-за прокрутки скроллбара
overflow-y: scroll;
height: 230px;
border: 1px solid #eb582c;
console.log(div.scrollHeight);
=> 232 (228px (clientHeight) + 4px (невидимое содержимое))


D. offsetTop/offsetLeft
позиция блока относительно верхнего/левого угла позиционированного родителя/body
top: 5px;
left: 5px;
console.log(div.offsetTop, div.offsetLeft);
=> 5 5
*/










// Код из лекции
// console.log(div.clientWidth, div.clientHeight);
// console.log(div.offsetWidth, div.offsetHeight);
// console.log(div.scrollWidth, div.scrollHeight);
// console.log(i.offsetTop, i.offsetLeft);