const field = document.querySelector('textarea');
const action = document.querySelector('i');


// 'Вася печатает сообщение'
/*
Событие focus
выполняется, когда элемент получает фокус
document.querySelector('textarea').addEventListener('focus', (e) => {
    e.target.style.borderWidth = '2px';
});


Событие blur
выполняется, когда элемент теряет фокус
document.querySelector('textarea').addEventListener('blur', (e) => {
    e.target.style.borderWidth = '1px';
});
*/










// Код из лекции
// field.addEventListener('focus', () => {
//     action.textContent = 'Вася печатает сообщение';
//     action.style.visibility = 'visible';
// });

// field.addEventListener('blur', () => {
//     action.style.visibility = 'hidden';
// });