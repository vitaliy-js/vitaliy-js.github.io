


/*
'img/male.svg', 'img/female.svg'
'Поле не может быть пустым'
*/


















// Код из практики
// document.querySelector('.radio-male').addEventListener('change', () => {
//     changeGender('img/male.svg');
// });

// document.querySelector('.radio-female').addEventListener('change', () => {
//     changeGender('img/female.svg');
// });

// function changeGender(image) {
//     const img = document.querySelector('img');
//     img.src = image;
// }

// document.querySelector('.field-name').addEventListener('blur', (e) => {
//     const fieldName = document.querySelector('b');
//     const err = document.querySelector('.err-message');

//     if (e.target.value.length === 0) {
//         err.style.visibility = 'visible';
//         err.textContent = 'Поле не может быть пустым';
//         hideErr(err);
//     } else {
//         fieldName.textContent = e.target.value;
//     }
// });

// function hideErr(err) {
//     document.querySelector('.field-name').addEventListener('input', () => {
//         err.style.visibility = 'hidden';
//     });
// }