


/*
Событие submit
используется для отправки формы: 
a. При клике на кнопку внутри формы
b. При нажатии на клавишу Enter (элемент формы должен быть в фокусе)

Важно: для запуска события используется элемент form
document.querySelector('form').addEventListener('submit', (e) => {
    console.log('Thank you');
});


Метод preventDefault()
метод объекта event, который позволяет отменить стандартное поведение браузера при отправке формы
(например, перезагрузка страницы)
document.querySelector('form').addEventListener('submit', (e) => {
    e.preventDefault();
    console.log('Thank you');
});
*/
function showAlert() {
    const alert = document.querySelector('.alert');
    alert.classList.add('alert-success');
    alert.children[0].textContent = 'Доступ разрешён';

    document.querySelector('.btn-close').addEventListener('click', () => {
        alert.className = 'alert';
        alert.children[0].textContent = '';
    });
}










// Код из лекции
// document.querySelector('form').addEventListener('submit', (e) => {
//     e.preventDefault();
//     console.log('hello submit');
// });

// document.querySelector('form').addEventListener('submit', (e) => {
//     e.preventDefault();
//     showAlert();
// });