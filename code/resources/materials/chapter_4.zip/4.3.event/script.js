


/*
Объект события (event или e)
позволяет получить детальную информацию о событии

Добавляется в виде параметра в функцию, которая вызывается при возникновении события
элемент.addEventListener(событие, функция(e));

document.querySelector('h1').addEventListener('click', (e) => {
    console.log(e);
});


Свойство target
позволяет получить информацию об элементе, который был инициатором события
document.querySelector('h1').addEventListener('click', (e) => {
    console.log(e.target);
});
=> <h1>Объект event</h1>


Свойство type
предоставляет информацию о типе (имени) события (click, mouseover, mouseout и т.д.)
document.querySelector('h1').addEventListener('dblclick', (e) => {
    console.log(e.type);
});
=> dblclick
*/










// Код из лекции
// document.querySelector('.home').addEventListener('click', (e) => {
//     console.log(e);
// });

// document.querySelector('.home').addEventListener('click', (e) => {
//     console.log(e.target);
// });

// document.querySelector('.home').addEventListener('click', (e) => {
//     e.target.classList.remove('day');
//     e.target.classList.add('night');
// });


// document.querySelector('.home').addEventListener('click', (e) => {
//     changeDay(e);
// });

// document.querySelector('.home').addEventListener('contextmenu', (e) => {
//     changeDay(e);
// });

// function changeDay(e) {
//     if (e.type === 'click') {
//         e.target.classList.remove('day');
//         e.target.classList.add('night');
//     } else if (e.type === 'contextmenu') {
//         e.target.classList.remove('night');
//         e.target.classList.add('day');
//     }
// }