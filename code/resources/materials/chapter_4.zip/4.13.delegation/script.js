document.querySelector('#pwd1').addEventListener('input', (e) => {
    if (e.target.value.length === 0) {
        console.log('Поле не может быть пустым');
    }
});



/*
Делегирование
позволяет обработать похожие события разных элементов в одном блоке кода

Для этого добавляется обработчик события на общего предка элементов
document.querySelector('form').addEventListener('input', () => {
    console.log('Кто-то что-то печатает');
});
=> Кто-то что-то печатает


Отловить элемент, на котором произошло событие, можно через e.target
<input type="radio" name="drinks" value="кофе">
<input type="radio" name="drinks" value="чай">
document.querySelector('form').addEventListener('change', (e) => {
    if (e.target.value === 'кофе') {
        console.log('Посетитель заказал ' + e.target.value);
    } else if (e.target.value === 'чай') {
        console.log('Посетитель заказал ' + e.target.value);
    }
});
=> Посетитель заказал кофе


Важно: делегирование недоступно для focus и blur событий, так как они не всплывают


Д.З.
Настройте переключение радиокнопок с помощью делегирования в 4.12. Практика. События формы

Подсказка: проверку (в условии if) на нужный e.target можно выполнить через classList.contains()
*/










// Код из лекции
// document.querySelector('form').addEventListener('input', (e) => {
//     if (e.target.value.length === 0) {
//         console.log('Поле не может быть пустым');
//     }
// });

// document.querySelector('form').addEventListener('input', (e) => {
//     if (e.target.value.length === 0) {
//         console.log(e.target.id + ' не может быть пустым');
//     }
// });










/*
Решение Д.З. (способы решения могут отличаться)
document.querySelector('.gender-wrap').addEventListener('change', (e) => {
    if (e.target.classList.contains('radio-male')) {
        changeGender('img/male.svg');
    } else {
        changeGender('img/female.svg');
    }
});

function changeGender(image) {
    const img = document.querySelector('img');
    img.src = image;
}
*/