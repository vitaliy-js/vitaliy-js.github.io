const img = document.querySelector('img');



/*
const startAction = () => {
    console.log('hello');
}

function startAction() {
    console.log('hello');
}

Метод addEventListener
обработчик, который запускает выполнение кода, как только событие произошло


Формула
элемент.addEventListener(событие, функция);


Параметры:
1. Тип события (click, mousemove и т.д.)
2. Функция, которая вызывается при возникновении события
3. Options - объект с дополнительными свойствами (необязательный)


События мыши:
1. click – клик левой кнопкой мыши/тап на девайсе
2. contextmenu – клик правой кнопкой мыши
3. dblclick – двойной клик левой кнопки мыши
4. mousedown - нажатие левой кнопки мыши (кнопку ещё не отпустили) 
5. mouseup – выполняется, когда отпустили левую кнопку мыши  (похожее на click)
6. mouseover – курсор находится в пределах элемента
7. mouseout – курсор находится за пределами элемента
8. mousemove – выполняется при движении мыши на элементе


Событие через стрелочную функцию:
document.querySelector('h1').addEventListener('click', () => {
    console.log('Hello arrow');
});

Событие через function:
document.querySelector('h1').addEventListener('click', function() {
    console.log('Hello function');
});


Д.З.
1. В консоли должна появиться ошибка 'Поле не может быть пустым', если при клике на элемент button поле input не содержит значения
-------------------
2. Выведите в консоль сообщение 'Загрузка файла', если пользователь сделал двойной клик на элементе span
*/










// Код из лекции
// img.addEventListener('click', () => {
//     console.log('hello');
// });

// img.addEventListener('click', function() {
//     console.log('hello');
// });










/*
Решение Д.З. (способы решения могут отличаться)
1. 
document.querySelector('button').addEventListener('click', () => {
    const input = document.querySelector('input');
    if (input.value.length === 0) {
        console.log('Поле не может быть пустым');
    }
});
-------------------
2.
document.querySelector('span').addEventListener('dblclick', () => {
    console.log('Загрузка файла');
});
*/