
























// Код из практики
// document.querySelector('.cat').addEventListener('mouseover', (e) => {
//     e.target.classList.add('cat-smile');
// });

// document.querySelector('.cat').addEventListener('mouseout', (e) => {
//     e.target.classList.remove('cat-smile');
// });