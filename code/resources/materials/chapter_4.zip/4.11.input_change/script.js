const fieldName = document.querySelector('input[type="text"]');
const fieldBirthday = document.querySelector('input[type="date"]');



// 'Имя изменено' 'Пол изменён на ' 'Дата изменена на '
/*
Событие input
выполняется сразу после того, как значение в поле формы изменилось
document.querySelector('input').addEventListener('input', () => {
    console.log('Кто-то что-то печатает');
});

Событие input обычно используется при работе с текстовыми полями формы: 
input[type="text"], input[type="password"], textarea и др.


Событие change
выполняется при изменении значения элемента формы
document.querySelector('input[type="radio"]').addEventListener('change', () => {
    console.log('Кто-то переключил радиокнопку');
});

Событие change чаще всего применяется для следующих элементов:
input[type="radio"], input[type="checkbox"], input[type="file"], select и др.

Если добавить событие change для текстовых полей формы, оно будет срабатывать при изменении содержимого после потери фокуса
*/


function showAlert(text) {
    const alert = document.querySelector('.alert');
    const alertText = document.querySelector('.alert>p');
    alert.classList.add('alert-success');
    alertText.textContent = text;

    document.querySelector('.btn-close').addEventListener('click', () => {
        alert.className = 'alert';
        alertText.textContent = '';
    });
}










// Код из лекции
// fieldName.addEventListener('input', () => {
//     showAlert('Имя изменено');
// });

// document.querySelector('.radio-male').addEventListener('change', (e) => {
//     showAlert('Пол изменён на ' + e.target.value);
// });

// document.querySelector('.radio-female').addEventListener('change', (e) => {
//     showAlert('Пол изменён на ' + e.target.value);
// });

// fieldBirthday.addEventListener('change', (e) => {
//     showAlert('Дата изменена на ' + e.target.value);
// });