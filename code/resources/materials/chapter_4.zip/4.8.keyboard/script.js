


/*
Событие keydown 
происходит при нажатии на клавишу (кнопку ещё не отпустили) 
document.addEventListener('keydown', () => {
    console.log('Hello');
});


Событие keyup
происходит при отпускании клавиши (нажали и отпустили)
document.addEventListener('keyup', () => {
    console.log('Hello');
});


Свойства code и key
вызываются через объект event и позволяют получить значение клавиши, нажатой пользователем


* code – код клавиши, привязанный к физическому расположению клавиши на клавиатуре (KeyQ, ShiftRight, Digit1, Escape, Enter)
document.addEventListener('keyup', (e) => {
    console.log(e.code);
});
=> KeyA


* key – символьное значение клавиши (Q, q, Shift, 1, Escape, Enter)
document.addEventListener('keyup', (e) => {
    console.log(e.code);
});
=> a

key чувствителен к регистру
document.addEventListener('keyup', (e) => {
    console.log(e.code);
});
=> A


Объект document 
позволяет получить доступ ко всей HTML-разметке. Для этого используются различные его методы: getElementById(), querySelector() и другие
document.querySelector('h1');


Д.З.
Добавить событие keydown для модального окна в практике по Submit (4.6. Практика. Событие submit). Модальное окно должно закрываться после нажатия на клавишу Escape
*/

window.addEventListener('blur', () => {
    document.querySelector('.screen').classList.remove('unlocked');
});










// Код из лекции
// document.querySelector('input').addEventListener('keyup', () => {
//     console.log('hello keyboard');
// });

// document.addEventListener('keyup', (e) => {
//     console.log(e);
//     if (e.key === '1') {
//         document.querySelector('.screen').classList.add('unlocked');
//     }
// });










/*
Пример решения Д.З.
document.querySelector('form').addEventListener('submit', (e) => {
    e.preventDefault();
    const overlay = document.querySelector('.overlay');
    overlay.style.display = 'block';
    document.querySelector('input').value = '';
    document.querySelector('textarea').value = '';

    document.querySelector('.btn-modal').addEventListener('click', () => {
        closeModal(overlay);
    });

    document.querySelector('.modal').addEventListener('click', (e) => {
        e.stopPropagation();
    });

    overlay.addEventListener('click', () => {
        closeModal(overlay);
    });

    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            closeModal(overlay);
        }
    });
});

function closeModal(overlay) {
    overlay.style.display = 'none';
}
*/