


/*
'img/microphone.svg'
'img/guitar.svg'
'img/drums.svg'
'img/piano.svg'
*/
















// Код из практики
// document.addEventListener('keydown', (e) => {
//     const img = document.querySelector('img');

//     if (e.key === '1') {
//         img.src = 'img/microphone.svg';
//     } else if (e.key === '2') {
//         img.src = 'img/guitar.svg';
//     } else if (e.key === '3') {
//         img.src = 'img/drums.svg';
//     } else if (e.key === '4') {
//         img.src = 'img/piano.svg';
//     }
// });