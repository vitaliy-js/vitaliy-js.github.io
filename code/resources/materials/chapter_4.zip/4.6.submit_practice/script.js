
























// Код из практики
// document.querySelector('form').addEventListener('submit', (e) => {
//     e.preventDefault();
//     const overlay = document.querySelector('.overlay');
//     overlay.style.display = 'block';
//     document.querySelector('input').value = '';
//     document.querySelector('textarea').value = '';

//     document.querySelector('.btn-modal').addEventListener('click', () => {
//         closeModal(overlay);
//     });

//     overlay.addEventListener('click', () => {
//         closeModal(overlay);
//     });
// });

// function closeModal(overlay) {
//     overlay.style.display = 'none';
// }