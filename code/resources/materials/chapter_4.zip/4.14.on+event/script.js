const attr = document.querySelector('#onclick');
const listener = document.querySelector('#listener');

listener.addEventListener('click', () => {
    console.log(1);
});



/*
Свойство on+событие
обработчик, который запускает выполнение кода, как только событие произошло (альтернатива для addEventListener)

При его использовании нужно добавлять on перед названием события:
onsubmit, onkeydown, onblur, oninput и т.д.

Формула
элемент.on+событие = функция;

document.querySelector('button').onclick = () => {
    console.log('Hello world!');
}


В случае on+событие, если назначить два одинаковых события на один и тот же элемент, последнее событие перезапишет предыдущее
document.querySelector('h1').onclick = (e) => console.log('Привет!');
document.querySelector('h1').onclick = (e) => console.log('Привет ещё раз!');
=> Привет ещё раз!

В addEventListener можно назначать неограниченное количество обработчиков событий на одном элементе
document.querySelector('h1').addEventListener('click', (e) => console.log('Привет!'));
document.querySelector('h1').addEventListener('click', (e) => console.log('Привет ещё раз!'));
=>
Привет!
Привет ещё раз!


Д.З.
Перепишите событие клавиатуры keydown в 4.9. Практика. События клавиатуры, чтобы там использовался обработчик on+событие
*/










// Код из лекции
// listener.addEventListener('click', () => console.log(1));
// listener.addEventListener('click', () => console.log(2));

// attr.onclick = () => console.log(1);
// attr.onclick = () => console.log(2);










/*
Решение Д.З. (способы решения могут отличаться)
document.onkeydown = (e) => {
    const img = document.querySelector('img');

    if (e.key === '1') {
        img.src = 'img/microphone.svg';
    } else if (e.key === '2') {
        img.src = 'img/guitar.svg';
    } else if (e.key === '3') {
        img.src = 'img/drums.svg';
    } else if (e.key === '4') {
        img.src = 'img/piano.svg';
    }
}
*/