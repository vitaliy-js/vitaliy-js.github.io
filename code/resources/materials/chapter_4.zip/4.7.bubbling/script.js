document.querySelector('form').addEventListener('submit', (e) => {
    e.preventDefault();
    const overlay = document.querySelector('.overlay');
    overlay.style.display = 'block';
    document.querySelector('input').value = '';
    document.querySelector('textarea').value = '';

    document.querySelector('.btn-modal').addEventListener('click', () => {
        closeModal(overlay);
    });

    overlay.addEventListener('click', (e) => {
        closeModal(overlay);
    });
});

function closeModal(overlay) {
    overlay.style.display = 'none';
}



/*
Погружение
выполнение событий от корневого элемента (document) к целевому элементу (e.target) по дереву DOM
(по умолчанию, погружение отключено)


Всплытие
выполнение событий с e.target до начала DOM
button - modal - overlay - body - html ...


Метод stopPropagation()
останавливает дальнейшее распространение события при всплытии и погружении

Метод принадлежит объекту event, поэтому должен прописываться в связке с ним:
e.stopPropagation()

document.querySelector('.btn-modal').addEventListener('click', (e) => {
    e.stopPropagation();
    console.log('hello');
});
*/










// Код из лекции
// document.querySelector('form').addEventListener('submit', (e) => {
//     e.preventDefault();
//     const overlay = document.querySelector('.overlay');
//     overlay.style.display = 'block';
//     document.querySelector('input').value = '';
//     document.querySelector('textarea').value = '';

//     document.querySelector('.btn-modal').addEventListener('click', () => {
//         closeModal(overlay);
//     });

//     document.querySelector('.modal').addEventListener('click', (e) => {
//         e.stopPropagation();
//     });

//     overlay.addEventListener('click', (e) => {
//         closeModal(overlay);
//         // if (e.target === overlay) {
//         //     closeModal(overlay);
//         //     console.log('overlay');
//         // }
//     });
// });

// function closeModal(overlay) {
//     overlay.style.display = 'none';
// }