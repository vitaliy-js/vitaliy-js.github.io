const fruit = ['apple', 'pear'];
const drinks = ['juice', 'smoothie'];

const main = ['паста', 'соус'];
const spices = ['соль', 'перец'];
const plant = ['лук', 'петрушка'];



/*
Метод concat
возвращает новый массив, который включает в себя другие массивы (значения)

Формула:
новый массив = массив1.concat(массив2, массив3);

const engClubs = ['manchester', 'liverpool'];
const espClubs = ['real', 'barcelona'];
const clubs = engClubs.concat(espClubs);
console.log(clubs);
=> ['manchester', 'liverpool', 'real', 'barcelona']


С помощью этого метода можно соединять массив и с другими значениями
const clubs = engClubs.concat(espClubs, 'bayern');
console.log(clubs);
=> ['manchester', 'liverpool', 'real', 'barcelona', 'bayern']


Метод concat не изменяет исходные массивы
console.log(engClubs);
=> ['manchester', 'liverpool']
*/










// Код из лекции
// const pasta = main.concat(spices);
// const pasta = main.concat(spices, plant);
// const pasta = main.concat(spices, plant, 1, 'базилик');
// console.log(pasta);

// const all = fruit.concat(drinks);
// console.log(all);
// showProducts(all, 2);










showProducts(fruit, 0);
showProducts(drinks, 1);
function showProducts(arr, index) {
    for (let el of arr) {
        document.querySelectorAll('.food-wrap div')[index].innerHTML += `
        <img src="img/${el}.svg">`;
    }
}