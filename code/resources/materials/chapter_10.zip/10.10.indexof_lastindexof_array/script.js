const tools = ['hammer', 'cat', 'saw'];
showTools(tools);

const bigBang = ['Шелдон', 'Говард', 'Эми'];



/*
Метод indexOf
ищет в массиве указанный элемент и возвращает его индекс
const interests = ['рисование', 'книги', 'музыка'];
console.log(interests.indexOf('книги'));
=> 1


Если искомое значение не найдено, возвращается -1
console.log(interests.indexOf('ботаника'));
=> -1


В методе indexOf есть второй параметр, который позволяет осуществлять поиск с определённой позиции
console.log(interests.indexOf('книги', 2));
=> -1


Метод lastIndexOf
выполняется аналогично indexOf, только поиск ведётся с конца массива (справа налево)
console.log(interests.lastIndexOf('рисование'));
=> 0
*/










// Код из лекции
// console.log(bigBang.indexOf('Шелдон'));
// console.log(bigBang.indexOf('Росс'));

// console.log(bigBang.indexOf('Шелдон', 1));

// const bigBang = ['Шелдон', 'Говард', 'Эми', 'Шелдон'];
// console.log(bigBang.indexOf('Шелдон', 2));

// console.log(bigBang.lastIndexOf('Шелдон'));
// console.log(bigBang.lastIndexOf('Шелдон', 3));
// console.log(bigBang.lastIndexOf('Шелдон', -2));

// const index = tools.indexOf('cat');
// if (index !== -1) {
//     tools.splice(index, 1, 'perforator');
//     showTools(tools);
// }










function showTools(arr) {
    const toolsWrap = document.querySelector('div');
    toolsWrap.innerHTML = '';

    for (let el of arr) {
        toolsWrap.insertAdjacentHTML('beforeend', 
        `<img src="img/${el}.svg">`);
    }
}