const menu = ['cake', 'soup', 'milk'];
// ['salad', 'soup', 'pasta', 'tea']























// Код из практики
// menu.shift();
// menu.unshift('salad');
// menu.push('tea');
// menu.splice(2, 1, 'pasta');

// for (let el of menu) {
//     document.querySelector('div').innerHTML += `
//     <img src="img/${el}.png">`;
// }