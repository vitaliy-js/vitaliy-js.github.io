const menu = ['apple', 'juice', 'smoothie', 'pear'];
showProducts(menu, 0);



/*
Метод slice
возвращает новый массив, который содержит отдельные элементы другого массива

A. Первый параметр - индекс, с которого нужно начинать копирование элементов массива
const clubs = ['manchester united', 'manchester city',  'arsenal', 'chelsea'];
console.log(clubs.slice(2));
=> ['arsenal', 'chelsea']


B. Второй параметр (необязательный) - индекс, до которого нужно выполнить копирование элементов массива (не включая его)
console.log(clubs.slice(0, 2));
=> ['manchester united', 'manchester city']


В параметрах могут использоваться отрицательные значения, которые рассчитываются по формуле:
index = arr.length - index
console.log(clubs.slice(-1));
=> ['chelsea']
console.log(clubs.slice(-3, -1));
=> ['manchester city', 'arsenal']


В отличие от метода splice, метод slice не изменяет порядок элементов в исходном массиве
const londonClubs = clubs.slice(2);
console.log(londonClubs);
=> ['arsenal', 'chelsea']
console.log(clubs);
=> ['manchester united', 'manchester city', 'arsenal', 'chelsea']


Д.З.
const arr = ['пляж', 'пальма', 'арбузы', 'снег', 'комары'];
Выведите решение в консоль, где должен быть новый массив summer, состоящий из следующих элементов:
1. 'пляж', 'пальма', 'арбузы'
-------------------
2. 'пальма', 'арбузы'
-------------------
3. 'комары'
*/










// Код из лекции
// const drinks = menu.slice(1);
// const drinks = menu.slice(1, 3);
// const drinks = menu.slice(-2);
// const drinks = menu.slice(-4, -2);
// console.log(drinks);

// const drinks = menu.slice(1, 3);
// showProducts(drinks, 1);

// const drinks = menu.splice(1, 2);
// console.log(drinks);
// showProducts(drinks, 1);
// console.log(menu);










/*
Решение Д.З. (способы решения могут отличаться)
1. 
const summer = arr.slice(0, 3);
console.log(summer);     =>  ['пляж', 'пальма', 'арбузы']
-------------------
2. 
const summer = arr.slice(1, 3);
console.log(summer);     =>  ['пальма', 'арбузы']
-------------------
3. 
const summer = arr.slice(-1);
console.log(summer);     =>  ['комары']
*/










function showProducts(arr, index){
    for (let el of arr) {
        document.querySelectorAll('div')[index].innerHTML += `
        <img src="img/${el}.svg">`;
    }
}