const arr = [0, 2, 3, 4, 18];
//1, 2, 3, 4, 5
updateTrain();



// const clubs = ['manchester', 'arsenal', 'liverpool'];
// 'leicester' 'newcastle'
/*
A. Добавление элементов в массив
Метод push 
добавляет элементы в конец массива
const fruit = ['апельсин', 'яблоко', 'груша'];
fruit.push('виноград'); 
console.log(fruit);
=> ['апельсин', 'яблоко', 'груша', 'виноград']


Метод unshift
добавляет элементы в начало массива
fruit.unshift('виноград'); 
console.log(fruit);
=> ['виноград', 'апельсин', 'яблоко', 'груша']


Добавляться может 1 и более элемент
fruit.push('виноград', 'киви'); 
console.log(fruit);
=> ['апельсин', 'яблоко', 'груша', 'виноград', 'киви']


B. Удаление элементов из массива
Метод pop
удаляет последний элемент массива
const fruit = ['апельсин', 'яблоко', 'груша'];
fruit.pop(); 
console.log(fruit);
=> ['апельсин', 'яблоко']


Метод shift
удаляет первый элемент массива
fruit.shift(); 
console.log(fruit);
=> ['яблоко', 'груша']


Важно: данные методы изменяют первоначальный массив


Д.З.
const planets = ['Венера', 'Земля', 'Марс', 'Юпитер', 'Сатурн', 'Уран', 'Нептун', 'Плутон'];
Выведите решение в консоль после выполнения 2-х пунктов:
1. Удалить 'Плутон' из массива
2. Добавить 'Меркурий' в начало массива
*/










// Код из лекции
// clubs.push('leicester');
// clubs.unshift('leicester');
// clubs.unshift('leicester', 'newcastle');

// const clubs = ['manchester', 'arsenal', 'liverpool', 'leicester'];
// clubs.pop();
// clubs.shift();
// console.log(clubs);

// arr.shift();
// arr.unshift(1);
// arr.pop();
// arr.push(5);
// updateTrain();










/*
Решение Д.З. (способы решения могут отличаться)
1. 
planets.pop();
--------------------
2.
planets.unshift('Меркурий');
console.log(planets);
=> ['Меркурий', 'Венера', 'Земля', 'Марс', 'Юпитер', 'Сатурн', 'Уран', 'Нептун']
*/










function updateTrain() {
    for (let i = 0; i < arr.length; i++) {
        document.querySelector('.train-wrap').insertAdjacentHTML('beforeend',
        `<div class="carriage">
            <img src="img/carriage.png">
            <span>${arr[i]}</span>
        </div>`);
    }
}