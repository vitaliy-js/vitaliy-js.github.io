const arr = [1, 2, 4, 8];
//1, 2, 3, 4, 5, 6, 7, 8
updateTrain();

const food = ['apple', 'cakes', 'chips', 'pizza', 'banana'];



//'pear', 'mango', 'orange'
/*
Метод splice
удаляет существующие элементы или добавляет новые, в т.ч. внутри массива


A. Удаление элементов

Формула:
масссив.splice(старт, количество удаляемых элементов);

const drinks = ['молоко', 'кефир', 'энергетик', 'сок'];
drinks.splice(2, 1);
console.log(drinks);
=> ['молоко', 'кефир', 'сок']


B. Добавление элементов

Формула:
масссив.splice(старт, 0, новые значения);

const drinks = ['молоко', 'кефир', 'энергетик', 'сок'];
drinks.splice(2, 0, 'чай');
console.log(drinks);
=> ['молоко', 'кефир', 'чай', 'энергетик', 'сок']


C. Замена данных

Формула:
масссив.splice(старт, количество удаляемых элементов, новые значения);

const drinks = ['молоко', 'кефир', 'энергетик', 'сок'];
drinks.splice(2, 1, 'чай', 'компот');
console.log(drinks);
=>  ['молоко', 'кефир', 'чай', 'компот', 'сок']



Д.З.
const rainbow = ['каждый', 'хочет', 'знать', 'где', 'сидит', 'спит', 'фазан'];

Перестройте массив rainbow таким образом, чтобы в консоли были выведены элементы в следующем порядке:
['каждый', 'охотник', 'желает', 'знать', 'где', 'сидит', 'фазан']
*/










// Код из лекции
// food.splice(1, 1);

// food.splice(1, 0, 'pear');
// food.splice(1, 0, 'pear', 'mango', 'orange');

// food.splice(1, 3, 'pear', 'mango', 'orange');

// const removeProducts = food.splice(1, 3, 'pear', 'mango', 'orange');
// console.log(removeProducts);
// console.log(food);

// arr.splice(2, 0, 3);
// arr.splice(4, 0, 5, 6, 7);
// updateTrain();










/*
Решение Д.З. (способы решения могут отличаться)
const rainbow = ['каждый', 'хочет', 'знать', 'где', 'сидит', 'спит', 'фазан'];

rainbow.splice(5, 1);
rainbow.splice(1, 1, 'охотник', 'желает');
console.log(rainbow);
=> ['каждый', 'охотник', 'желает', 'знать', 'где', 'сидит', 'фазан']
*/











function updateTrain() {
    for (let i = 0; i < arr.length; i++) {
        document.querySelector('.train-wrap').insertAdjacentHTML('beforeend',
        `<div class="carriage">
            <img src="img/carriage.png">
            <span>${arr[i]}</span>
        </div>`);
    }
}