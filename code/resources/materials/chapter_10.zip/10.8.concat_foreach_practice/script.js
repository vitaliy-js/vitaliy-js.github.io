const america = ['usa', 'mexico'];
const europe = ['spain', 'france'];























// Код из практики
// const all = america.concat(europe);
// showFlags(all);

// document.querySelectorAll('li').forEach((el, index) => {
//     el.addEventListener('click', () => {
//         document.querySelector('.item-selected').className = '';
//         el.className = 'item-selected';

//         if (index === 1) {
//             showFlags(europe);
//         } else if (index === 2) {
//             showFlags(america);
//         } else {
//             showFlags(all);
//         }
//     });
// });

// function showFlags(arr) {
//     const flagWrap = document.querySelector('div');
//     flagWrap.innerHTML = '';

//     for (let el of arr) {
//         flagWrap.innerHTML += `<img src="img/${el}.svg" title="${el.toUpperCase()}">`;
//     }
// }