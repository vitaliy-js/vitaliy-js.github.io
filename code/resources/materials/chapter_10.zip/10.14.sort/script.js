const people = [
    ['Зина', 98],
    ['Сеня', 58],
    ['Люся', 79],
    ['Вася', 80]
];
createTable(people);

const age = [2, 12, 49, 5, 25, 18];
const all = ['Яна', 'Сеня', 'Аня', 'Люся'];



/*
Метод sort
сортирует элементы в массиве, меняя их порядок
const peopleArr = ['Mary', 'Steve', 'Adam'];
peopleArr.sort();
console.log(peopleArr);
=> ['Adam', 'Mary', 'Steve']


Элементы в методе сортируются по правилам строк
const uk = ['автобус', 'Лондон', 'метро'];
console.log(uk.sort());
=> ['Лондон', 'автобус', 'метро']


Для сортировки чисел часто используется параметр внутри метода - функция, которая может определять порядок сортировки:
const num = [25, 2, 89, 12];
num.sort((a, b) =>  a - b);
console.log(num);
=> [2, 12, 25, 89]


Для сортировки с убыванием в числах нужно поменять местами параметры функции:
const num = [25, 2, 89, 12];
num.sort((a, b) =>  b - a);
console.log(num);
=> [89, 25, 12, 2]


Для обратного порядка в строках можно использовать связку двух методов: sort и reverse
const peopleArr = ['Mary', 'Steve', 'Adam'];
peopleArr.sort().reverse();
console.log(peopleArr);
=> ['Steve', 'Mary', 'Adam']


Метод reverse
меняет порядок элементов в массиве в обратную сторону
const clubs = ['manchester', 'arsenal', 'leicester'];
clubs.reverse()
console.log(clubs);
=> ['leicester', 'arsenal', 'manchester']
*/










// Код из лекции
// all.sort();
// console.log(all);

// age.sort((a, b) => a - b);
// age.sort((a, b) => b - a);
// console.log(age);

// all.sort().reverse();
// console.log(all);


// people.sort();
// createTable(people);

// document.querySelector('th:last-child').addEventListener('click', (e) => {
//     if (e.target.className !== 'asc') {
//         e.target.className = 'asc';
//         people.sort((a, b) => a[1] - b[1]);
//     } else {
//         e.target.className = 'desc';
//         people.sort((a, b) => b[1] - a[1]);
//     }
//     createTable(people);
// });










function createTable(arr) {
    document.querySelector('tbody').innerHTML = '';
    for (let i = 0; i < arr.length; i++) {
        document.querySelector('tbody').insertAdjacentHTML('beforeend', `
        <tr>
            <td>${arr[i][0]}</td>
            <td>${arr[i][1]}%</td>
        </tr>`);
    }
}