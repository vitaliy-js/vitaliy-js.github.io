const people = ['Леонард', 'Пенни', 'Шелдон'];
const all = [];



//'Говард'
/*
Метод forEach
позволяет перебрать все элементы массива и выполнить определённые действия


Аргументом выступает функция, которая может включать от 1 до 3 параметров:
A. Элемент (element, item, value) - текущий элемент в массиве (обязательный параметр)

B. Индекс (index) - индекс текущего элемента

C. Массив (array) - массив, где выполняется действие

const characters = ['Чип', 'Дейл'];
characters.forEach((element, index, array) => {
    console.log(element);
    => Чип
    => Дейл

    console.log(index);
    => 0
    => 1

    console.log(array);
    => ['Чип', 'Дейл']
    => ['Чип', 'Дейл']
});


Метод forEach часто используется для перебора коллекции HTML-элементов:
document.querySelectorAll('div').forEach((element) => {
    element.style.display = 'none';
});
*/










// Код из лекции
// people.forEach((element, index, array) => {
//     all.push(element);
//     console.log(array);

//     if (index === 0) {
//         people[index] = 'Говард';
//     }

//     if (index === 0) {
//         array[index] = 'Говард';
//     }
// });
// console.log(all);
// console.log(people);

// document.querySelectorAll('a').forEach((el, index) => {
//     el.style.display = 'none';
// });

// document.querySelectorAll('a').forEach((el, index) => {
//     // el.style.display = 'none';
//     if (index === 1) {
//         el.style.backgroundColor = 'orangered';
//     } else if (index === 2) {
//         el.style.backgroundColor = 'pink';
//     }
// });