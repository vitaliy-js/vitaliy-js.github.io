const people = [
    ['Грегори', 'greg.svg', 'друг'],
    ['Гантер', 'gunther.svg', 'коллега'],
    ['Аманда', 'amanda.svg', 'коллега'],
    ['Энджи', 'angie.svg', 'друг'],
    ['Эллисон', 'allison.svg', 'неизвестно']
];
//аманда грегори эллисон

















// Код из практики
// showContacts(people);

// document.querySelector('input').addEventListener('input', (e) => {
//     const val = e.target.value.toLowerCase().trim();
    
//     if (val.length === 0) {
//         showContacts(people);
//         return;
//     }

//     const contact = people.filter((item) => {
//         return item[0].toLowerCase().includes(val);
//     });

//     if (contact.length > 0) {
//         showContacts(contact);
//     } else {
//         document.querySelector('.contact-wrap').innerHTML = `
//         <p>Контакт не найден</p>`;
//     }
// });

// function showContacts(arr) {
//     const contactWrap = document.querySelector('.contact-wrap');
//     contactWrap.innerHTML = '';

//     arr.sort();

//     arr.forEach((el) => {
//         contactWrap.insertAdjacentHTML('beforeend', `
//         <div class="contact">
//             <img src="img/${el[1]}">
//             <div>
//                 <b>${el[0]}</b>
//                 <i>${el[2]}</i>
//             </div>
//         </div>`);
//     });
// }