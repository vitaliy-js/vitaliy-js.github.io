const people = [
    ['Зина', '98%'],
    ['Сеня', '58%'],
    ['Люся', '79%'],
    ['Вася', '80%']
];
const age = [5, 18, 30];



/*
Метод filter
возвращает массив из значений элементов, которые соответствуют указанному условию в другом массиве

A. Элемент (element, item) - текущий элемент в массиве
B. Индекс (index) - индекс текущего элемента
C. Массив (array) - массив, где выполняется действие

const tools = ['hammer', 'cat', 'saw'];
const tool = tools.filter((item, index, array) => {
    return item !== 'cat';
});
console.log(tool); 
=> ['hammer', 'saw']


Если указанное условие не выполнилось, возвращается пустой массив
const all = ['hammer', 'cat', 'saw'];
const tool = all.filter((item, index, array) => {
    return item === 'axe';
});
console.log(tool);
=> []


Пример использования filter с объектом
const friends = [
    {
        id: 1, 
        name: 'Росс'
    },
    {
        id: 2, 
        name: 'Чендлер'
    },
    {
        id: 3, 
        name: 'Рейчел'
    }
];
const couple = friends.filter(item => item.id === 1 || item.id === 3);
console.log(couple);    
=> [{id: 1, name: 'Росс'}, {id: 3, name: 'Рейчел'}]
*/










// Код из лекции
// const adult = age.filter((item, index, array) => {
//     return item >= 18;
// });
// const adult = age.filter((item) => item >= 18);

// const adult = age.filter((item, index, array) => {
//     return item >= 18000;
// });

// const adult = age.filter((item, index, array) => {
//     console.log(array[2]);
//     return item >= 18 && index !== 1;
// });
// console.log(adult);


// const students = people.filter((item) => parseFloat(item[1]) >= 80);
// students.forEach((el) => {
//     document.querySelector('ul').innerHTML += `
//     <li>${el[0]} (${el[1]})</li>`;
// });










createTable(people);
function createTable(arr) {
    for (let i = 0; i < arr.length; i++) {
        document.querySelector('tbody').insertAdjacentHTML('beforeend', `
        <tr>
            <td>${arr[i][0]}</td>
            <td>${arr[i][1]}</td>
        </tr>`);
    }
}