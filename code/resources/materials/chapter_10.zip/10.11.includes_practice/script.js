const winners = [
    ['Loreen', 'Швеция', '2023'],
    ['Kalush Orchestra', 'Украина', '2022'],
    ['Maneskin', 'Италия', '2021'],
    ['Duncan Laurence', 'Нидерланды', '2019'],
    ['Netta', 'Израиль', '2018']
];


















// Код из практики
document.querySelector('select').addEventListener('change', (e) => {
    winners.forEach((el, index) => {
        if (el.includes(e.target.value)) {
            showWinner(winners[index]);
        }
    });
});

function showWinner(arr) {
    document.querySelector('.winner').innerHTML = `
    <div class="cup"></div>
    <b>${arr[0]}</b>
    <i>${arr[1]}</i>`;
}