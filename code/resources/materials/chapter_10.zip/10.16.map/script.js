const people = [
    ['Грегори Хаус', 'инфекционист'],
    ['Лиза Кадди', 'эндокринолог'],
    ['Эрик Форман', 'невролог']
];
const exam = ['89%', '51%', '91%'];



/*
Метод map
возвращает массив с результатом вызова функции для каждого элемента массива
(метод map не изменяет исходный массив)

A. Элемент (element, item) - текущий элемент в массиве
B. Индекс (index) - индекс текущего элемента
C. Массив (array) - массив, где выполняется действие

const students = [
    ['Зина', 100],
    ['Сеня', 95]
];
const studentsName = students.map((item, index, array) => item[0]);
console.log(studentsName);
=> ['Зина', 'Сеня']


Можно изменить значения элементов перед их добавлением в массив 
const studentsName = students.map((item, index, array) => {
    return `${item[0]} (абитуриент)`;
});
console.log(studentsName);
=> ['Зина (абитуриент)', 'Сеня (абитуриент)']


Пример использования map с объектом
const people = [
    {
        id: 1, 
        name: 'Росс'
    },
    {
        id: 2, 
        name: 'Чендлер'
    },
    {
        id: 3, 
        name: 'Рейчел'
    }
];
const friends = people.map(item => item.name);
console.log(friends);
=> ['Росс', 'Чендлер', 'Рейчел']
*/










// Код из лекции
// const doctors = people.map((item, index, array) => {
//     return item[0];
// });
// console.log(doctors);

// const results = exam.map((item) => parseInt(item));
// console.log(results);

// const results = exam.map((item) => parseInt(item) + 2);
// console.log(results);
// console.log(exam);