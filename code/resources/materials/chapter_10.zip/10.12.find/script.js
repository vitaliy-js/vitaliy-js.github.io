const cityArr = [
    ['лондон', 'london.png'],
    ['нью йорк', 'new_york.png'],
    ['рим', 'rome.png'],
];
const age = [5, 18, 30];
const drinks = ['чай', 'кофе', 'чай'];



//['Город не найден', 'other.svg']
/*
Метод find
возвращает первое найденное значение элемента в массиве, которое соответствует указанному условию

A. Элемент (element, item) - текущий элемент в массиве
B. Индекс (index) - индекс текущего элемента
C. Массив (array) - массив, где выполняется действие

const friends = ['Росс', 'Рейчел'];
const person = friends.find((item, index, array) => {
    return item === 'Росс';
});
console.log(person);     => Росс


Короткая форма
const person = friends.find((item) => item === 'Рейчел');
console.log(person);     => Рейчел


Если условие выполнилось, поиск по массиву сразу же прекращается
const person = friends.find((item) => {
    return item === 'Росс' || item === 'Рейчел'
});
console.log(person);     => Росс


Если указанное условие не выполнилось в массиве, возвращается undefined
const person = friends.find((item) => item === 'Эмили');
console.log(person);     => undefined


Пример использования find с объектом
const friends = [
    {
        id: 1, 
        name: 'Росс'
    },
    {
        id: 2, 
        name: 'Рейчел'
    }
];
const person = friends.find(item => item.id === 2);
console.log(person)   
=> {id: 2, name: 'Рейчел'}
*/










// Код из лекции
// const drink = drinks.find((item, index, array) => {
//     return item === 'кофе';
// });

// const drink = drinks.find((item) => item === 'кофе');

// const drink = drinks.find((item, index, array) => {
//     console.log(index);
//     return item === 'чай'
// });
// const drink = drinks.find((item, index, array) => {
//     console.log(index);
//     return item === 'чай' && index === 2;
// });
// console.log(drink);

// const adult = age.find((item) => {
//     return item >= 18;
// });
// console.log(adult);


// document.querySelector('form').addEventListener('submit', (e) => {
//     e.preventDefault();
//     const input = document.querySelector('input');
//     findCity(input.value.toLowerCase());
// });

// function findCity(cityVal) {
//     const city = cityArr.find((item) => {
//         return item[0] === cityVal;
//     });
    
//     if (city) {
//         createCity(city);
//     } else {
//         createCity(['Город не найден', 'other.svg']);
//     }
// }

// function createCity(arr) {
//     document.querySelector('.city').innerHTML = `
//     <img src="img/${arr[1]}">
//     <b>${arr[0]}</b>`;
// }