const interests = ['рисование', 'книги', 'цветы', 'музыка'];
const tools = ['молоток', 'перфоратор', 'пила'];



/*
Метод includes
позволяет проверить содержит ли массив элемент с указанным значением

Возвращаются следующие значения:
* true  - значение найдено в массиве
* false - значение не найдено в массиве

const bigBang = ['Шелдон', 'Рэйчел', 'Раджеш', 'Эми'];
console.log(bigBang.includes('Раджеш')); => true
console.log(bigBang.includes('Росс'));   => false


Этот метод часто используется в инструкции if:
if (bigBang.includes('Эми')) {
    console.log('Привет, Эми');
}
=> Привет, Эми

if (!bigBang.includes('Гомер')) {
    console.log('Привет всем');
} 
=> Привет всем


В методе includes есть второй необязательный параметр, который позволяет осуществлять поиск с определённого индекса массива
console.log(bigBang.includes('Шелдон', 1));  => false
*/










// Код из лекции
// console.log(tools.includes('кот'));
// console.log(tools.includes('перфоратор'));
// console.log(tools.includes('перфоратор', 1));
// console.log(tools.includes('перфоратор', -2));

// document.querySelectorAll('li').forEach((el) => {
//     if (interests.includes(el.textContent.toLowerCase())) {
//         el.classList.add('matched');
//     } else {
//         el.classList.add('not-matched');
//     }
// });