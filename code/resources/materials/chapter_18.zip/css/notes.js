/*
Конспект "Базовый CSS"

CSS
cascading stylesheets
каскадная таблица стилей


Подключение CSS-файла в html (link)
Добавляется через элемент link, как правило, внутри head 
<link rel="stylesheet" href="style.css">


Синтаксис CSS
селектор {
    свойство: значение;
}
p {
    color: red;
}


Семейство шрифта (font-family)
A. Без засечек (sans-serif): Arial, Helvetica, Verdana, Roboto
B. С засечками (serif): Times New Roman, Times, Georgia
font-family: Lora, serif;


Размер шрифта (font-size)
font-size: 30px;


Жирность шрифта (font-weight)
100 - самый тонкий
400 - обычный шрифт
900 - самый жирный


Межстрочный интервал (line-height)
line-height: 50px;


Цвет текста (color)
4 варианта отображения цвета:
1. Стандартный цвет (red, green, blue, black)
color: red;

2. rgb
0 - отсутствие цвета
255 - максимальная насыщенность цвета
color: rgb(255, 120, 200);
color: rgb(255 120 200);

3. rgba
0 - полностью прозрачный
0.5 - полупрозрачный
1 - полностью непрозрачный
color: rgba(255, 120, 200, 0.5);
color: rgb(255 120 200 / 50%);

4. hex
#5634ad
color: #5634ad;


Ширина и высота
width  - ширина
height - высота
img {
    width: 400px;
    height: 500px;
}


Идентификатор
html: прописать атрибут id с определённым значением
css:  #значение атрибута id
<p id="text-red">Some text</p>
 #text-red {
    color: red;
 }

Класс
html: прописать атрибут class с определённым значением
css:  .значение атрибута class
<p class="text-red">Some text</p>
 .text-red {
    color: red;
 }

Применение id и class
id - значение должно быть уникальным и не использоваться больше одного раза
class - значение используется многократно для разных элементов


Граница (border)
border: 1px solid brown;

Скругление границы (border-radius)
border-radius: 4px;


Внутренний отступ (padding)
отступ от контента до границы
padding: 25px 50px 10px 40px;


Внешний отступ  (margin)
отступ от границы до другого элемента / края браузера
margin: 25px 50px 10px 40px;


Работа с фоном
background-color - цвет фона
background-image - путь к файлу с изображением
background-position - положение по горизонтали и вертикали относительно родителя
background-size - ширина и высота фонового изображения
background-repeat - повторение фонового изображения
background - позволяет установить сразу несколько стилей фона
background: pink url(img/html.png) 50% 50%/125px 125px no-repeat;


Свойство display
block - элемент отображается как блочный
inline - элемент отображается как строчный
inline-block - способ сделать элемент строчным, но сохранить его "блочные" возможности: ширина, высота и отступы
none - позволяет скрыть элемент в разметке
display: none;


Выравнивание текста (text-align)
left - выравнивание текста по левому краю
right - выравнивание текста по правому краю
center - выравнивание по центру
justify - выравнивание по ширине
text-align: center;


Выравнивание блока (margin)
Нужно выполнить следующие шаги:
1. Уменьшить ширину, если она равна 100%;
2. margin должен содержать значение auto;
ul {
 width: 100px;
 margin: 0 auto 0 auto;
}

Выравнивание текста и блока доступно только для блочных элементов. Если строчный элемент нужно выровнять, можно его преобразовать в блочный элемент через свойство display
span {
    display: block;
    width: 200px;
    margin: 0 auto 0 auto;
    text-align: center;
}


Флексбокс
инструмент для размещения элементов на странице

Для контейнера с элементами добавляется display: flex;

Для выравнивания элементов используется свойство justify-content со следующими значениями:
flex-start - прижаты к началу контейнера
flex-end - прижаты к концу контейнера
center - выравнивание элементов происходит по центру
space-around - распределяются по всей строке с отступами справа и слева
space-between - распределяются по всей ширине контейнера

Свойство gap устанавливает размер отступов между элементами

Свойство flex-wrap разрешает/запрещает перенос флекс-элементов

Свойство align-items выравнивает элементы вдоль поперечной оси
div {
    display: flex;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 20px;
    align-items: center;
}


Позиционирование (position)
static - стандартное расположение элемента
relative - позволяет сместить элемент относительно первоначального расположения (не удаляется из обычного потока)
absolute - расположение относительно своего ближайшего спозиционированного контейнера (удаляется из обычного потока)
fixed - фиксируется в пределах области просмотра страницы

Смещение элемента выполняется через следующие свойства:
top - расстояние от верхней границы
left - расстояние от левой границы
bottom - расстояние от нижней границы
right - расстояние от правой границы
img {
    position: absolute;
    top: 10px;
    left: 10px;
    height: 100px;
}


Псевдоэлементы (::before, ::after)
добавляют контент для определённого элемента
::before - добавление контента перед элементом
::after - добавление контента после элемента
span::before {
    content: 'Hello';
}


Псевдоклассы
позволяют задавать отдельные стили для HTML-элементов
first-child - стилизация первого элемента в контейнере
last-child - стилизация последнего элемента в контейнере
nth-child - стилизация элемента в контейнере исходя из его позиции
hover - переопределение свойств при наведении курсора мыши
p:hover {
    background-color: yellow;
}


Код из лекций:
А. Шрифт
p {
    color: red;
    font-family: Roboto, Arial, Tahoma, sans-serif;
    font-size: 40px;
    font-weight: 700;
    line-height: 80px;
}

B. Цвет
p {
    font-size: 40px;
    color: purple;
    color: rgb(255, 100, 200);
    color: rgba(255, 100, 200, 0.5);
    color: #5634ad;
}

C. Ширина и высота
img {
    width: 500px;
    height: 250px;
    width: 25%;
}

D. Классы и идентификаторы
<h1 class="text-green">Header</h1>
<p>Some text</p>
<p id="text-blue">Some text 2</p>
<p class="text-green">Some text 3</p>
p {
    font-size: 50px;
    color: red;
}
#text-blue {
    color: blue;
    font-weight: 700;
}
.text-green {
    color: green;
}

E. Граница и отступы
p {
    width: 250px;
    height: 250px;
    border: 4px solid red;
    border-radius: 4px;
}
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}
p {
    border: 2px solid red;
    padding: 20px 50px 10px 30px;
    margin: 10px 20px 30px 50px;
}

F. Фон
div {
    height: 150px;
    border: 2px solid #ff6200;
    background-color: pink;
    background-image: url(img/html.png);
    background-size: 125px 125px;
    background-position: 50% 50%;
    background-repeat: no-repeat;
    background: pink url(img/html.png) 50% 50%/125px 125px no-repeat;
}

G. Свойство display
li {
    display: inline;
    margin: 10px 5px 10px 5px;
    list-style-type: none;
    border: 1px solid brown;
    background-color: gold;
}
span {
    display: none;
    display: block;
    border: 1px solid brown;
    background-color: pink;
}

H. Выравнивание текста и блоков
p {
    width: 250px;
    margin: 0 auto 25px auto;
    border: 2px solid brown;
    background-color: gold;
    text-align: center;
}
img {
    display: block;
    width: 150px;
    margin: 0 auto;
}

I. Флексбокс
div {
    display: flex;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 20px;
    align-items: center;
    background-color: pink;
}

J. Позиционирование
img {
    position: relative;
    top: 10px;
    left: 10px;
    height: 100px;
}
img {
    position: absolute;
    top: 10px;
    left: 10px;
    height: 100px;
}
img {
    position: fixed;
    bottom: 10px;
    left: 10px;
    height: 100px;
}

K. Псевдоэлементы
span::before {
    position: absolute;
    content: '';
    top: 1px;
    left: 15px;
    width: 20px;
    height: 20px;
    background: url(img/html.png) 50% 50%/cover no-repeat;
}

L. Псевдоклассы
li:first-child {
    background-color: yellow;
}
li:last-child {
    background-color: yellow;
}
li:nth-child(4) {
    background-color: yellow;
}
li:hover {
    color: blue;
    background-color: yellow;
}
*/